
package com.pos.ui.dialog;

import com.pos.model.CartItem;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class ReceiptDialog extends JDialog {

    private final String invoiceNumber;
    private final String cashierName;
    private final List<CartItem> items;

    private final double subtotal;
    private final double vatableSales;
    private final double discountAmount;
    private final double vat;
    private final double vatExemption;
    private final double total;

    private final String paymentMethod;
    private final String bank;
    private final String referenceNumber;
    private final double cashReceived;
    private final double change;
    private final String transactionDate;

    private JComboBox<String> cmbFormat;
    private JTextArea txtReceipt;
    private JPanel paperPanel;
    private JPanel previewPanel;
    private JScrollPane previewScrollPane;

    public ReceiptDialog(
            java.awt.Frame parent,
            String invoiceNumber,
            String cashierName,
            Collection<CartItem> items,
            double subtotal,
            double vatableSales,
            double discountAmount,
            double vat,
            double vatExemption,
            double total,
            String paymentMethod,
            String bank,
            String referenceNumber,
            double cashReceived,
            double change) {

        super(parent, "Receipt Preview", true);

        this.invoiceNumber = invoiceNumber;
        this.cashierName = cashierName;
        this.items = new ArrayList<>(items);

        this.subtotal = subtotal;
        this.vatableSales = vatableSales;
        this.discountAmount = discountAmount;
        this.vat = vat;
        this.vatExemption = vatExemption;
        this.total = total;

        this.paymentMethod = paymentMethod;
        this.bank = bank;
        this.referenceNumber = referenceNumber;
        this.cashReceived = cashReceived;
        this.change = change;

        this.transactionDate = new SimpleDateFormat(
                "MMM dd, yyyy hh:mm:ss a",
                Locale.US
        ).format(new Date());

        initializeUI();
    }

    private void initializeUI() {

        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(0, 10));
        setSize(650, 760);
        setMinimumSize(new Dimension(480, 560));
        setLocationRelativeTo(getParent());

        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setBorder(
                BorderFactory.createEmptyBorder(12, 12, 0, 12)
        );

        JLabel lblFormat = new JLabel("Receipt format:");

        cmbFormat = new JComboBox<>(new String[]{
            "Thermal - 58 mm",
            "Thermal - 80 mm",
            "A4"
        });

        JButton btnPrint = new JButton("Print Receipt");
        JButton btnClose = new JButton("Close");

        topPanel.add(lblFormat, BorderLayout.WEST);
        topPanel.add(cmbFormat, BorderLayout.CENTER);
        topPanel.add(btnPrint, BorderLayout.EAST);

        previewPanel = new JPanel(new GridBagLayout());
        previewPanel.setBackground(new Color(226, 229, 234));
        previewPanel.setBorder(
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        txtReceipt = new JTextArea();
        txtReceipt.setEditable(false);
        txtReceipt.setFocusable(false);
        txtReceipt.setLineWrap(false);
        txtReceipt.setWrapStyleWord(false);
        txtReceipt.setBackground(Color.WHITE);
        txtReceipt.setForeground(Color.BLACK);
        txtReceipt.setMargin(new Insets(20, 15, 20, 15));

        paperPanel = new JPanel(new BorderLayout());
        paperPanel.setBackground(Color.WHITE);
        paperPanel.setBorder(
                BorderFactory.createLineBorder(
                        new Color(210, 210, 210)
                )
        );
        paperPanel.add(txtReceipt, BorderLayout.NORTH);

        previewScrollPane = new JScrollPane(
                previewPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );
        previewScrollPane.setBorder(BorderFactory.createEmptyBorder());
        previewScrollPane.getViewport().setBackground(
                new Color(226, 229, 234)
        );

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBorder(
                BorderFactory.createEmptyBorder(0, 0, 10, 0)
        );
        bottomPanel.add(btnClose);

        add(topPanel, BorderLayout.NORTH);
        add(previewScrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        cmbFormat.addActionListener(e -> refreshPreview());
        btnPrint.addActionListener(e -> printReceipt());
        btnClose.addActionListener(e -> dispose());

        refreshPreview();
    }

    private int getReceiptWidth() {

        String format = (String) cmbFormat.getSelectedItem();

        if ("Thermal - 58 mm".equals(format)) {
            return 32;
        }

        if ("Thermal - 80 mm".equals(format)) {
            return 42;
        }

        return 80;
    }

    private int getPaperPreviewWidth() {

        String format = (String) cmbFormat.getSelectedItem();

        if ("Thermal - 58 mm".equals(format)) {
            return 270;
        }

        if ("Thermal - 80 mm".equals(format)) {
            return 350;
        }

        return 520;
    }

    private void refreshPreview() {

        String format = (String) cmbFormat.getSelectedItem();
        boolean isA4 = "A4".equals(format);

        txtReceipt.setFont(
                isA4
                        ? new Font("Monospaced", Font.PLAIN, 12)
                        : new Font("Monospaced", Font.PLAIN, 10)
        );

        txtReceipt.setText(buildReceipt(getReceiptWidth(), format));
        txtReceipt.setCaretPosition(0);

        int paperWidth = getPaperPreviewWidth();

        FontMetrics metrics = txtReceipt.getFontMetrics(
                txtReceipt.getFont()
        );

        int longestLine = 0;

        for (String line : txtReceipt.getText().split("\n", -1)) {
            longestLine = Math.max(
                    longestLine,
                    metrics.stringWidth(line)
            );
        }

        int paperHeight = Math.max(
                200,
                txtReceipt.getLineCount() * metrics.getHeight() + 45
        );

        int actualWidth = Math.max(
                paperWidth,
                Math.min(longestLine + 35, paperWidth)
        );

        txtReceipt.setPreferredSize(
                new Dimension(actualWidth, paperHeight)
        );

        paperPanel.setPreferredSize(
                new Dimension(paperWidth, paperHeight)
        );

        paperPanel.removeAll();
        paperPanel.add(txtReceipt, BorderLayout.NORTH);
        paperPanel.revalidate();
        paperPanel.repaint();

        previewPanel.removeAll();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        previewPanel.add(paperPanel, gbc);

        previewPanel.revalidate();
        previewPanel.repaint();
    }

    private String buildReceipt(int width, String format) {

        StringBuilder out = new StringBuilder();
        String line = repeat("-", width);

        appendCentered(out, "POS AND INVENTORY SYSTEM", width);
        appendCentered(out, "SALES RECEIPT", width);

        out.append(line).append("\n");
        out.append("Invoice: ").append(invoiceNumber).append("\n");
        out.append("Date: ").append(transactionDate).append("\n");
        out.append("Cashier: ").append(cashierName).append("\n");
        out.append(line).append("\n");

        for (CartItem item : items) {

            List<String> nameLines = wrapText(
                    item.getDisplayName(),
                    width
            );

            for (String nameLine : nameLines) {
                out.append(nameLine).append("\n");
            }

            String qtyPrice = item.getQuantity()
                    + " x " + money(item.getUnitPrice());

            String amount = money(item.getSubtotal());

            if ("A4".equals(format)) {

                int spaces = Math.max(
                        1,
                        width - qtyPrice.length() - amount.length()
                );

                out.append(qtyPrice)
                   .append(repeat(" ", spaces))
                   .append(amount)
                   .append("\n");

            } else {

                out.append(qtyPrice).append("\n");
                out.append(amount).append("\n");
            }
        }

        out.append(line).append("\n");

        appendAmount(out, "Subtotal", subtotal, width);
        appendAmount(out, "Vatable Sales", vatableSales, width);

        if (vatExemption > 0) {
            appendAmount(out, "VAT Exemption", vatExemption, width);
        }

        appendAmount(out, "Discount", discountAmount, width);
        appendAmount(out, "VAT", vat, width);

        out.append(line).append("\n");
        appendAmount(out, "TOTAL", total, width);
        out.append(line).append("\n");

        out.append("Payment: ").append(paymentMethod).append("\n");

        if ("Cash".equalsIgnoreCase(paymentMethod)) {

            appendAmount(out, "Cash Received", cashReceived, width);
            appendAmount(out, "Change", change, width);

        } else {

            if ("Bank Transfer".equalsIgnoreCase(paymentMethod)
                    && bank != null
                    && !bank.trim().isEmpty()) {

                out.append("Bank: ")
                   .append(bank.trim())
                   .append("\n");
            }

            if (referenceNumber != null
                    && !referenceNumber.trim().isEmpty()) {

                out.append("Reference: ")
                   .append(referenceNumber.trim())
                   .append("\n");
            }
        }

        out.append(line).append("\n");

        appendCentered(out, "Thank you for shopping!", width);
        appendCentered(out, "Please keep your receipt.", width);

        return out.toString();
    }

    private void printReceipt() {

        String format = (String) cmbFormat.getSelectedItem();

        PrinterJob job = PrinterJob.getPrinterJob();
        PageFormat pageFormat = job.defaultPage();
        Paper paper = new Paper();

        if ("A4".equals(format)) {

            double paperWidth = 595.28;
            double paperHeight = 841.89;

            paper.setSize(paperWidth, paperHeight);
            paper.setImageableArea(
                    36,
                    36,
                    paperWidth - 72,
                    paperHeight - 72
            );

        } else {

            double paperWidth =
                    "Thermal - 58 mm".equals(format)
                            ? 164.41
                            : 226.77;

            FontMetrics metrics = txtReceipt.getFontMetrics(
                    new Font("Monospaced", Font.PLAIN, 8)
            );

            double paperHeight = Math.max(
                    300,
                    txtReceipt.getLineCount()
                            * metrics.getHeight() + 40
            );

            paper.setSize(paperWidth, paperHeight);
            paper.setImageableArea(
                    3,
                    5,
                    paperWidth - 6,
                    paperHeight - 10
            );
        }

        pageFormat.setPaper(paper);
        pageFormat.setOrientation(PageFormat.PORTRAIT);

        job.setJobName("Receipt - " + invoiceNumber);
        job.setPrintable(new ReceiptPrintable(format), pageFormat);

        if (!job.printDialog()) {
            return;
        }

        try {

            job.print();

        } catch (PrinterException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to print receipt:\n" + ex.getMessage(),
                    "Print Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private class ReceiptPrintable implements Printable {

        private final String format;

        ReceiptPrintable(String format) {
            this.format = format;
        }

        @Override
        public int print(
                Graphics graphics,
                PageFormat pageFormat,
                int pageIndex) throws PrinterException {

            String[] lines = txtReceipt.getText().split("\n", -1);

            Graphics2D g2 = (Graphics2D) graphics.create();

            try {

                g2.translate(
                        pageFormat.getImageableX(),
                        pageFormat.getImageableY()
                );

                boolean isA4 = "A4".equals(format);

                g2.setFont(
                        isA4
                                ? new Font("Monospaced", Font.PLAIN, 9)
                                : new Font("Monospaced", Font.PLAIN, 8)
                );

                FontMetrics metrics = g2.getFontMetrics();
                int lineHeight = metrics.getHeight();

                int linesPerPage = Math.max(
                        1,
                        (int) (
                                pageFormat.getImageableHeight()
                                        / lineHeight
                        )
                );

                int start = pageIndex * linesPerPage;

                if (start >= lines.length) {
                    return NO_SUCH_PAGE;
                }

                int end = Math.min(
                        lines.length,
                        start + linesPerPage
                );

                double printableWidth =
                        pageFormat.getImageableWidth();

                float y;

                if (isA4
                        && pageIndex == 0
                        && lines.length <= linesPerPage) {

                    double receiptHeight =
                            lines.length * (double) lineHeight;

                    y = (float) Math.max(
                            metrics.getAscent(),
                            (pageFormat.getImageableHeight()
                                    - receiptHeight) / 2.0
                                    + metrics.getAscent()
                    );

                } else {

                    y = metrics.getAscent();
                }

                for (int i = start; i < end; i++) {

                    String text = lines[i];

                    int textWidth = metrics.stringWidth(text);

                    float x = (float) Math.max(
                            0,
                            (printableWidth - textWidth) / 2.0
                    );

                    g2.drawString(text, x, y);
                    y += lineHeight;
                }

                return PAGE_EXISTS;

            } finally {
                g2.dispose();
            }
        }
    }

    private static void appendAmount(
            StringBuilder out,
            String label,
            double amount,
            int width) {

        String value = money(amount);
        int spaces = width - label.length() - value.length();

        if (spaces >= 1) {

            out.append(label)
               .append(repeat(" ", spaces))
               .append(value)
               .append("\n");

        } else {

            out.append(label).append("\n");
            out.append(value).append("\n");
        }
    }

    private static void appendCentered(
            StringBuilder out,
            String value,
            int width) {

        if (value.length() >= width) {
            out.append(value).append("\n");
            return;
        }

        int left = (width - value.length()) / 2;

        out.append(repeat(" ", left))
           .append(value)
           .append("\n");
    }

    private static List<String> wrapText(
            String text,
            int width) {

        List<String> result = new ArrayList<>();

        if (text == null || text.trim().isEmpty()) {
            result.add("");
            return result;
        }

        String remaining = text.trim();

        while (!remaining.isEmpty()) {

            if (remaining.length() <= width) {
                result.add(remaining);
                break;
            }

            int breakAt = remaining.lastIndexOf(' ', width);

            if (breakAt <= 0) {
                breakAt = width;
            }

            result.add(
                    remaining.substring(0, breakAt).trim()
            );

            remaining = remaining.substring(breakAt).trim();
        }

        return result;
    }

    private static String money(double value) {

        return String.format(
                Locale.US,
                "\u20B1%,.2f",
                value
        );
    }

    private static String repeat(String value, int count) {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < count; i++) {
            result.append(value);
        }

        return result.toString();
    }
}
