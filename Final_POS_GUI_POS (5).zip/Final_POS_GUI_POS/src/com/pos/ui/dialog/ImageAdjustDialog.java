package com.pos.ui.dialog;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class ImageAdjustDialog extends JDialog {

    // Same ratio as the product card picture box (202 x 130), drawn at 2x for sharpness
    private static final int BOX_W = 404;
    private static final int BOX_H = 260;
    private static final int MAX_SOURCE = 1600;

    private final BufferedImage source;
    private final double minScale;    // whole picture visible
    private final double coverScale;  // picture fills the whole box
    private final double maxScale;    // 4x zoom past "fill"

    private double scale;
    private double offX;
    private double offY;
    private boolean updatingSlider = false;
    private BufferedImage result;

    private final JSlider zoomSlider = new JSlider(0, 100, 0);
    private final PreviewPanel preview = new PreviewPanel();

    private ImageAdjustDialog(Window owner, BufferedImage src) {
        super(owner, "Adjust Product Image", ModalityType.APPLICATION_MODAL);
        this.source = limitSize(src);

        double sx = (double) BOX_W / source.getWidth();
        double sy = (double) BOX_H / source.getHeight();
        minScale = Math.min(sx, sy);
        coverScale = Math.max(sx, sy);
        maxScale = coverScale * 4;

        // start with the picture filling the box, centered
        scale = coverScale;
        offX = (BOX_W - source.getWidth() * scale) / 2;
        offY = (BOX_H - source.getHeight() * scale) / 2;

        updatingSlider = true;
        zoomSlider.setValue(sliderFromScale(coverScale));
        updatingSlider = false;
        zoomSlider.addChangeListener(e -> {
            if (!updatingSlider) {
                applyZoom(scaleFromSlider(zoomSlider.getValue()));
            }
        });

        // ---------- preview ----------
        JPanel frame = new JPanel(new BorderLayout());
        frame.setBorder(new LineBorder(new Color(160, 160, 160)));
        frame.add(preview);

        JPanel previewWrap = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        previewWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 6, 14));
        previewWrap.add(frame);

        // ---------- controls ----------
        JPanel zoomRow = new JPanel(new BorderLayout(8, 0));
        zoomRow.add(new JLabel("Zoom:"), BorderLayout.WEST);
        zoomRow.add(zoomSlider, BorderLayout.CENTER);

        JLabel hint = new JLabel("Drag the picture to move it. Use the mouse wheel or the slider to zoom.");
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint.setForeground(new Color(110, 110, 110));

        JButton btnFit = new JButton("Fit whole picture");
        btnFit.addActionListener(e -> setZoom(minScale));
        JButton btnFill = new JButton("Fill box");
        btnFill.addActionListener(e -> setZoom(coverScale));
        JButton btnCancel = new JButton("Cancel");
        btnCancel.addActionListener(e -> dispose());
        JButton btnUse = new JButton("Use This Image");
        btnUse.addActionListener(e -> {
            result = render();
            dispose();
        });

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.add(btnFit);
        buttons.add(btnFill);
        buttons.add(btnCancel);
        buttons.add(btnUse);

        JPanel south = new JPanel();
        south.setLayout(new BoxLayout(south, BoxLayout.Y_AXIS));
        south.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        zoomRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttons.setAlignmentX(Component.LEFT_ALIGNMENT);
        south.add(zoomRow);
        south.add(Box.createVerticalStrut(4));
        south.add(hint);
        south.add(Box.createVerticalStrut(10));
        south.add(buttons);

        setLayout(new BorderLayout());
        add(previewWrap, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);

        getRootPane().setDefaultButton(btnUse);
        setResizable(false);
        pack();
        setLocationRelativeTo(owner);
    }

    /** Opens the window. Returns the adjusted picture, or null if the user cancelled. */
    public static BufferedImage showDialog(Component parent, BufferedImage src) {
        Window owner = SwingUtilities.getWindowAncestor(parent);
        ImageAdjustDialog dialog = new ImageAdjustDialog(owner, src);
        dialog.setVisible(true);   // blocks until the window is closed
        return dialog.result;
    }

    // ---------- zoom math ----------

    private double scaleFromSlider(int t) {
        return minScale * Math.pow(maxScale / minScale, t / 100.0);
    }

    private int sliderFromScale(double s) {
        double ratio = Math.log(s / minScale) / Math.log(maxScale / minScale);
        return (int) Math.round(Math.max(0, Math.min(1, ratio)) * 100);
    }

    private void setZoom(double s) {
        updatingSlider = true;
        zoomSlider.setValue(sliderFromScale(s));
        updatingSlider = false;
        applyZoom(s);
    }

    /** Zooms around the center of the box so the picture doesn't jump. */
    private void applyZoom(double newScale) {
        double cx = (BOX_W / 2.0 - offX) / scale;
        double cy = (BOX_H / 2.0 - offY) / scale;
        scale = newScale;
        offX = BOX_W / 2.0 - cx * scale;
        offY = BOX_H / 2.0 - cy * scale;
        clamp();
        preview.repaint();
    }

    /** Keeps the picture from being dragged away from the box (no empty edges when zoomed in). */
    private void clamp() {
        double sw = source.getWidth() * scale;
        double sh = source.getHeight() * scale;
        offX = (sw <= BOX_W) ? (BOX_W - sw) / 2 : Math.max(BOX_W - sw, Math.min(0, offX));
        offY = (sh <= BOX_H) ? (BOX_H - sh) / 2 : Math.max(BOX_H - sh, Math.min(0, offY));
    }

    // ---------- drawing ----------

    private void paintPicture(Graphics2D g2) {
        g2.setColor(new Color(248, 248, 248));
        g2.fillRect(0, 0, BOX_W, BOX_H);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.drawImage(source,
                (int) Math.round(offX), (int) Math.round(offY),
                (int) Math.round(source.getWidth() * scale),
                (int) Math.round(source.getHeight() * scale), null);
    }

    /** The saved picture is drawn exactly like the preview, so what you see is what you get. */
    private BufferedImage render() {
        BufferedImage out = new BufferedImage(BOX_W, BOX_H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = out.createGraphics();
        paintPicture(g2);
        g2.dispose();
        return out;
    }

    /** Shrinks very large photos once so dragging stays smooth. */
    private static BufferedImage limitSize(BufferedImage src) {
        int w = src.getWidth();
        int h = src.getHeight();
        int longest = Math.max(w, h);
        if (longest <= MAX_SOURCE) {
            return src;
        }
        double f = (double) MAX_SOURCE / longest;
        int nw = Math.max(1, (int) Math.round(w * f));
        int nh = Math.max(1, (int) Math.round(h * f));
        BufferedImage out = new BufferedImage(nw, nh, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = out.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.drawImage(src, 0, 0, nw, nh, null);
        g2.dispose();
        return out;
    }

    private class PreviewPanel extends JPanel {
        private Point last;

        PreviewPanel() {
            setPreferredSize(new Dimension(BOX_W, BOX_H));
            setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));

            MouseAdapter mouse = new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    last = e.getPoint();
                }

                @Override
                public void mouseDragged(MouseEvent e) {
                    offX += e.getX() - last.x;
                    offY += e.getY() - last.y;
                    last = e.getPoint();
                    clamp();
                    repaint();
                }

                @Override
                public void mouseWheelMoved(MouseWheelEvent e) {
                    zoomSlider.setValue(zoomSlider.getValue() - e.getWheelRotation() * 3);
                }
            };
            addMouseListener(mouse);
            addMouseMotionListener(mouse);
            addMouseWheelListener(mouse);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            paintPicture(g2);
            g2.dispose();
        }
    }
}