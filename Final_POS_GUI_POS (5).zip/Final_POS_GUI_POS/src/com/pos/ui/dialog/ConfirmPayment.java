    package com.pos.ui.dialog;

    import java.awt.BorderLayout;
    import java.awt.Color;
    import java.awt.Dimension;
    import java.awt.FlowLayout;
    import java.awt.Font;
    import java.awt.GridBagConstraints;
    import java.awt.GridBagLayout;
    import java.awt.GridLayout;
    import java.awt.Insets;
    import javax.swing.BorderFactory;
    import javax.swing.JButton;
    import javax.swing.JComboBox;
    import javax.swing.JDialog;
    import javax.swing.JLabel;
    import javax.swing.JPanel;
    import javax.swing.JTextField;
    import javax.swing.JOptionPane;
    import javax.swing.SwingConstants;
    import javax.swing.event.DocumentEvent;
    import javax.swing.event.DocumentListener;

    /**
     *
     * @author ramel
     */
    public class ConfirmPayment extends JDialog {

        // =====================================================
        // PAYMENT DATA
        // =====================================================
        private JLabel lblChangeText;

        private final double totalDue;

        private boolean confirmed = false;

        private String paymentMethod = "";

        private String referenceNumber = "";

        private String bank = "";

        private double cashReceived = 0;

        private double change = 0;


        // =====================================================
        // UI COMPONENTS
        // =====================================================

        private JLabel lblTotalAmount;
        private JLabel lblChange;

        private JComboBox<String> cmbPaymentMethod;
        private JComboBox<String> cmbBank;

        private JTextField txtCashReceived;
        private JTextField txtReferenceNumber;

        private JLabel lblCashReceived;
        private JLabel lblReferenceNumber;
        private JLabel lblBank;

        private JButton btnConfirm;
        private JButton btnCancel;


        // =====================================================
        // CONSTRUCTOR
        // =====================================================

        public ConfirmPayment(
                java.awt.Frame parent,
                boolean modal,
                double totalDue) {

            super(parent, "Confirm Payment", modal);

            this.totalDue = totalDue;
      
    



            initializeUI();

            setSize(520, 520);

            setResizable(false);

            setLocationRelativeTo(parent);
        }


        // =====================================================
        // INITIALIZE UI
        // =====================================================

        private void initializeUI() {

            setDefaultCloseOperation(
                    JDialog.DISPOSE_ON_CLOSE
            );


            // =================================================
            // MAIN PANEL
            // =================================================

            JPanel mainPanel = new JPanel(
                    new BorderLayout()
            );

            mainPanel.setBackground(
                    new Color(245, 247, 250)
            );

            mainPanel.setBorder(
                    BorderFactory.createEmptyBorder(
                            20,
                            25,
                            20,
                            25
                    )
            );


            // =================================================
            // HEADER
            // =================================================

            JPanel headerPanel = new JPanel(
                    new BorderLayout()
            );

            headerPanel.setBackground(
                    new Color(27, 31, 92)
            );

            headerPanel.setBorder(
                    BorderFactory.createEmptyBorder(
                            15,
                            18,
                            15,
                            18
                    )
            );


            JLabel lblTitle = new JLabel(
                    "CONFIRM PAYMENT"
            );

            lblTitle.setForeground(Color.WHITE);

            lblTitle.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            20
                    )
            );


            JLabel lblSubtitle = new JLabel(
                    "Review payment details before completing the sale"
            );

            lblSubtitle.setForeground(
                    new Color(220, 225, 240)
            );

            lblSubtitle.setFont(
                    new Font(
                            "Segoe UI",
                            Font.PLAIN,
                            11
                    )
            );


            JPanel titlePanel = new JPanel(
                    new GridLayout(
                            2,
                            1
                    )
            );

            titlePanel.setOpaque(false);

            titlePanel.add(lblTitle);
            titlePanel.add(lblSubtitle);

            headerPanel.add(
                    titlePanel,
                    BorderLayout.WEST
            );


            mainPanel.add(
                    headerPanel,
                    BorderLayout.NORTH
            );


            // =================================================
            // CENTER CONTENT
            // =================================================

            JPanel contentPanel = new JPanel(
                    new GridBagLayout()
            );

            contentPanel.setBackground(
                    new Color(245, 247, 250)
            );

            contentPanel.setBorder(
                    BorderFactory.createEmptyBorder(
                            20,
                            5,
                            10,
                            5
                    )
            );


            GridBagConstraints gbc =
                    new GridBagConstraints();

            gbc.insets =
                    new Insets(
                            7,
                            5,
                            7,
                            5
                    );

            gbc.fill =
                    GridBagConstraints.HORIZONTAL;


            // =================================================
            // TOTAL DUE
            // =================================================

            JLabel lblTotalText =
                    new JLabel(
                            "TOTAL DUE"
                    );

            lblTotalText.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            13
                    )
            );

            lblTotalText.setForeground(
                    new Color(80, 80, 80)
            );


            lblTotalAmount =
                    new JLabel(
                            String.format(
                                    "₱%,.2f",
                                    totalDue
                            )
                    );

            lblTotalAmount.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            25
                    )
            );

            lblTotalAmount.setForeground(
                    new Color(0, 82, 204)
            );

            lblTotalAmount.setHorizontalAlignment(
                    SwingConstants.RIGHT
            );


            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.weightx = 0.4;

            contentPanel.add(
                    lblTotalText,
                    gbc
            );


            gbc.gridx = 1;
            gbc.weightx = 0.6;

            contentPanel.add(
                    lblTotalAmount,
                    gbc
            );


            // =================================================
            // SEPARATOR
            // =================================================

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 2;

            javax.swing.JSeparator separator =
                    new javax.swing.JSeparator();

            contentPanel.add(
                    separator,
                    gbc
            );


            // =================================================
            // PAYMENT METHOD
            // =================================================

            JLabel lblPaymentMethod =
                    createLabel(
                            "Payment Method"
                    );


            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 1;

            contentPanel.add(
                    lblPaymentMethod,
                    gbc
            );


            cmbPaymentMethod =
                    new JComboBox<>(
                            new String[]{
                                "Cash",
                                "GCash",
                                "Maya",
                                "Bank Transfer",
                                "Credit / Debit Card"
                            }
                    );

            cmbPaymentMethod.setFont(
                    new Font(
                            "Segoe UI",
                            Font.PLAIN,
                            13
                    )
            );

            cmbPaymentMethod.setPreferredSize(
                    new Dimension(
                            250,
                            35
                    )
            );


            gbc.gridx = 1;

            contentPanel.add(
                    cmbPaymentMethod,
                    gbc
            );


            // =================================================
            // CASH RECEIVED
            // =================================================

            lblCashReceived =
                    createLabel(
                            "Cash Received"
                    );


            gbc.gridx = 0;
            gbc.gridy = 3;

            contentPanel.add(
                    lblCashReceived,
                    gbc
            );


            txtCashReceived =
                    new JTextField();

            txtCashReceived.setFont(
                    new Font(
                            "Segoe UI",
                            Font.PLAIN,
                            13
                    )
            );

            txtCashReceived.setPreferredSize(
                    new Dimension(
                            250,
                            35
                    )
            );


            gbc.gridx = 1;

            contentPanel.add(
                    txtCashReceived,
                    gbc
            );


            // =================================================
            // CHANGE
            // =================================================

          lblChangeText = createLabel("Change");


            gbc.gridx = 0;
            gbc.gridy = 4;

            contentPanel.add(
                    lblChangeText,
                    gbc
            );


            lblChange =
                    new JLabel(
                            "₱0.00"
                    );

            lblChange.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            15
                    )
            );

            lblChange.setForeground(
                    new Color(0, 140, 70)
            );

            lblChange.setHorizontalAlignment(
                    SwingConstants.RIGHT
            );


            gbc.gridx = 1;

            contentPanel.add(
                    lblChange,
                    gbc
            );


            // =================================================
            // REFERENCE NUMBER
            // =================================================

            lblReferenceNumber =
                    createLabel(
                            "Reference Number"
                    );


            gbc.gridx = 0;
            gbc.gridy = 5;

            contentPanel.add(
                    lblReferenceNumber,
                    gbc
            );


            txtReferenceNumber =
                    new JTextField();

            txtReferenceNumber.setFont(
                    new Font(
                            "Segoe UI",
                            Font.PLAIN,
                            13
                    )
            );

            txtReferenceNumber.setPreferredSize(
                    new Dimension(
                            250,
                            35
                    )
            );


            gbc.gridx = 1;

            contentPanel.add(
                    txtReferenceNumber,
                    gbc
            );


            // =================================================
            // BANK
            // =================================================

            lblBank =
                    createLabel(
                            "Bank"
                    );


            gbc.gridx = 0;
            gbc.gridy = 6;

            contentPanel.add(
                    lblBank,
                    gbc
            );


            cmbBank =
                    new JComboBox<>(
                            new String[]{
                                "BDO",
                                "BPI",
                                "Metrobank",
                                "LandBank",
                                "PNB",
                                "UnionBank",
                                "Security Bank",
                                "Other"
                            }
                    );

            cmbBank.setFont(
                    new Font(
                            "Segoe UI",
                            Font.PLAIN,
                            13
                    )
            );

            cmbBank.setPreferredSize(
                    new Dimension(
                            250,
                            35
                    )
            );


            gbc.gridx = 1;
    contentPanel.add(cmbBank, gbc);

    // filler para dikit sa taas ang fields
    gbc.gridx = 0;
    gbc.gridy = 7;
    gbc.gridwidth = 2;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.VERTICAL;
    JPanel filler = new JPanel();
    filler.setOpaque(false);
    contentPanel.add(filler, gbc);


           mainPanel.add(contentPanel, BorderLayout.CENTER);


            // =================================================
            // BUTTON PANEL
            // =================================================

            JPanel buttonPanel =
                    new JPanel(
                            new FlowLayout(
                                    FlowLayout.RIGHT,
                                    10,
                                    0
                            )
                    );

            buttonPanel.setBackground(
                    new Color(245, 247, 250)
            );


            btnCancel =
                    new JButton(
                            "Cancel"
                    );

            btnCancel.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            13
                    )
            );

            btnCancel.setPreferredSize(
                    new Dimension(
                            120,
                            40
                    )
            );

            btnCancel.setBackground(
                    Color.WHITE
            );

            btnCancel.setForeground(
                    new Color(70, 70, 70)
            );


            btnConfirm =
                    new JButton(
                            "Confirm Payment"
                    );

            btnConfirm.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            13
                    )
            );

            btnConfirm.setPreferredSize(
                    new Dimension(
                            160,
                            40
                    )
            );

            btnConfirm.setBackground(
                    new Color(0, 153, 76)
            );

            btnConfirm.setForeground(
                    Color.WHITE
            );


            buttonPanel.add(btnCancel);
            buttonPanel.add(btnConfirm);


            mainPanel.add(
                    buttonPanel,
                    BorderLayout.SOUTH
            );


            // =================================================
            // PAYMENT METHOD LISTENER
            // =================================================

            cmbPaymentMethod.addActionListener(
                    e -> updatePaymentFields()
            );


            // =================================================
            // CASH RECEIVED LISTENER
            // =================================================

            txtCashReceived
                    .getDocument()
                    .addDocumentListener(
                            new DocumentListener() {

                @Override
                public void insertUpdate(
                        DocumentEvent e) {

                    calculateChange();
                }

                @Override
                public void removeUpdate(
                        DocumentEvent e) {

                    calculateChange();
                }

                @Override
                public void changedUpdate(
                        DocumentEvent e) {

                    calculateChange();
                }
            });


            // =================================================
            // CONFIRM BUTTON
            // =================================================

            btnConfirm.addActionListener(
                    e -> confirmPayment()
            );


            // =================================================
            // CANCEL BUTTON
            // =================================================

            btnCancel.addActionListener(
                    e -> {

                        confirmed = false;

                        dispose();
                    }
            );


            add(mainPanel);
   
         getRootPane().setDefaultButton(btnConfirm);
        getRootPane().registerKeyboardAction(
                e -> { confirmed = false; dispose(); },
                javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0),
                javax.swing.JComponent.WHEN_IN_FOCUSED_WINDOW
        );
            // =================================================
            // INITIAL STATE
            // =================================================

            updatePaymentFields();
        }


        // =====================================================
        // CREATE LABEL
        // =====================================================

        private JLabel createLabel(
                String text) {

            JLabel label =
                    new JLabel(text);

            label.setFont(
                    new Font(
                            "Segoe UI",
                            Font.BOLD,
                            12
                    )
            );

            label.setForeground(
                    new Color(
                            60,
                            60,
                            60
                    )
            );

            return label;
        }


        // =====================================================
        // UPDATE PAYMENT FIELDS
        // =====================================================

        private void updatePaymentFields() {

            String method =
                    cmbPaymentMethod
                            .getSelectedItem()
                            .toString();


            boolean isCash =
                    method.equalsIgnoreCase("Cash");


            boolean isBank =
                    method.equalsIgnoreCase("Bank Transfer");


            boolean isDigital =
                    method.equalsIgnoreCase("GCash")
                    ||
                    method.equalsIgnoreCase("Maya");


            boolean isCard =
                    method.equalsIgnoreCase(
                            "Credit / Debit Card"
                    );


            // =================================================
            // CASH
            // =================================================

            lblCashReceived.setVisible(isCash);

            txtCashReceived.setVisible(isCash);

           lblChangeText.setVisible(isCash);
           lblChange.setVisible(isCash);


            // =================================================
            // REFERENCE NUMBER
            // =================================================

            boolean needsReference =
                    isDigital
                    ||
                    isBank
                    ||
                    isCard;


            lblReferenceNumber.setVisible(
                    needsReference
            );

            txtReferenceNumber.setVisible(
                    needsReference
            );


            // =================================================
            // BANK
            // =================================================

            lblBank.setVisible(isBank);

            cmbBank.setVisible(isBank);


            // =================================================
            // REFERENCE LABEL
            // =================================================

            if (isDigital) {

                if (method.equalsIgnoreCase("GCash")) {

                    lblReferenceNumber.setText(
                            "GCash Reference No."
                    );

                } else {

                    lblReferenceNumber.setText(
                            "Maya Reference No."
                    );
                }

            } else if (isBank) {

                lblReferenceNumber.setText(
                        "Bank Reference No."
                );

            } else if (isCard) {

                lblReferenceNumber.setText(
                        "Authorization No."
                );

            } else {

                lblReferenceNumber.setText(
                        "Reference Number"
                );
            }


            // =================================================
            // RESET UNUSED VALUES
            // =================================================
            txtReferenceNumber.setText("");

            if (!isCash) {

                txtCashReceived.setText("");

                cashReceived = 0;

                change = 0;

                lblChange.setText("₱0.00");
            }


            if (!needsReference) {

                txtReferenceNumber.setText("");

                referenceNumber = "";
            }


            if (!isBank) {

                bank = "";
            }

           if (isCash) txtCashReceived.requestFocusInWindow();
        else if (needsReference) txtReferenceNumber.requestFocusInWindow();
            revalidate();

            repaint();
        }


        // =====================================================
        // CALCULATE CHANGE
        // =====================================================

        private void calculateChange() {

           String text = txtCashReceived.getText().trim().replace(",", "");


            if (text.isEmpty()) {

                lblChange.setForeground(
                        new Color(0, 140, 70)
                );

                lblChange.setText(
                        "₱0.00"
                );

                return;
            }
    if (!text.matches("\\d+(\\.\\d{0,2})?")) {
        lblChange.setForeground(new Color(200, 50, 50));
        lblChange.setText("Invalid Amount");
        return;
    }

            try {

                 double cash = round2(Double.parseDouble(text));


                if (cash < 0) {

                    lblChange.setForeground(
                            new Color(200, 50, 50)
                    );

                    lblChange.setText(
                            "Invalid Amount"
                    );

                    return;
                }


               double calculatedChange = round2(cash - totalDue);


                if (calculatedChange >= 0) {

                    lblChange.setForeground(
                            new Color(0, 140, 70)
                    );

                    lblChange.setText(
                            String.format(
                                    "₱%,.2f",
                                    calculatedChange
                            )
                    );

                } else {

                    lblChange.setForeground(
                            new Color(200, 50, 50)
                    );

                    lblChange.setText(
                            "Insufficient Cash"
                    );
                }


            } catch (NumberFormatException e) {

                lblChange.setForeground(
                        new Color(200, 50, 50)
                );

                lblChange.setText(
                        "Invalid Amount"
                );
            }
        }


        // =====================================================
        // CONFIRM PAYMENT
        // =====================================================

        private void confirmPayment() {

            paymentMethod =
                    cmbPaymentMethod
                            .getSelectedItem()
                            .toString();


            // =================================================
            // CASH
            // =================================================

            if (paymentMethod.equalsIgnoreCase("Cash")) {

            String cashText = txtCashReceived.getText().trim().replace(",", "");

                if (cashText.isEmpty()) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please enter the cash received.",
                            "Cash Required",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtCashReceived.requestFocus();

                    return;
                }
    if (!cashText.matches("\\d+(\\.\\d{0,2})?")) {
        JOptionPane.showMessageDialog(this, "Please enter a valid cash amount.",
                "Invalid Cash", JOptionPane.WARNING_MESSAGE);
        txtCashReceived.requestFocus();
        return;
    }

                try {

                  cashReceived = round2(Double.parseDouble(cashText));

                } catch (NumberFormatException e) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please enter a valid cash amount.",
                            "Invalid Cash",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtCashReceived.requestFocus();

                    return;
                }


                if (cashReceived < 0) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Cash received cannot be negative.",
                            "Invalid Cash",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtCashReceived.requestFocus();

                    return;
                }


                if (cashReceived < round2(totalDue)) {

                    JOptionPane.showMessageDialog(
                            this,
                            String.format(
                                    "Insufficient cash.\n\n"
                                    + "Total Due: ₱%,.2f\n"
                                    + "Cash Received: ₱%,.2f\n"
                                    + "Remaining: ₱%,.2f",
                                    totalDue,
                                    cashReceived,
                                    totalDue - cashReceived
                            ),
                            "Insufficient Payment",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtCashReceived.requestFocus();

                    return;
                }


                // Calculate final change
                change = round2(cashReceived - totalDue);


                referenceNumber = "";

                bank = "";
            }


            // =================================================
            // GCASH / MAYA
            // =================================================

            else if (
                    paymentMethod.equalsIgnoreCase("GCash")
                    ||
                    paymentMethod.equalsIgnoreCase("Maya")
            ) {

                referenceNumber =
                        txtReferenceNumber
                                .getText()
                                .trim();


                if (referenceNumber.isEmpty()) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please enter the reference number.",
                            "Reference Number Required",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtReferenceNumber.requestFocus();

                    return;
                }


                cashReceived = 0;

                change = 0;

                bank = "";
            }


            // =================================================
            // BANK TRANSFER
            // =================================================

            else if (
                    paymentMethod.equalsIgnoreCase(
                            "Bank Transfer"
                    )
            ) {

                bank =
                        cmbBank
                                .getSelectedItem()
                                .toString();


                referenceNumber =
                        txtReferenceNumber
                                .getText()
                                .trim();


                if (referenceNumber.isEmpty()) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please enter the bank reference number.",
                            "Reference Number Required",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtReferenceNumber.requestFocus();

                    return;
                }


                cashReceived = 0;

                change = 0;
            }


            // =================================================
            // CREDIT / DEBIT CARD
            // =================================================

            else if (
                    paymentMethod.equalsIgnoreCase(
                            "Credit / Debit Card"
                    )
            ) {

                referenceNumber =
                        txtReferenceNumber
                                .getText()
                                .trim();


                if (referenceNumber.isEmpty()) {

                    JOptionPane.showMessageDialog(
                            this,
                            "Please enter the card authorization number.",
                            "Authorization Number Required",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtReferenceNumber.requestFocus();

                    return;
                }


                cashReceived = 0;

                change = 0;

                bank = "";
            }


            // =================================================
            // PAYMENT CONFIRMED
            // =================================================

            confirmed = true;

            dispose();
        }
    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

        // =====================================================
        // GETTERS
        // =====================================================

        public boolean isConfirmed() {

            return confirmed;
        }


        public String getPaymentMethod() {

            return paymentMethod;
        }


        public String getReferenceNumber() {

            return referenceNumber;
        }


        public String getBank() {

            return bank;
        }


        public double getCashReceived() {

            return cashReceived;
        }


        public double getChange() {

            return change;
        }
    }