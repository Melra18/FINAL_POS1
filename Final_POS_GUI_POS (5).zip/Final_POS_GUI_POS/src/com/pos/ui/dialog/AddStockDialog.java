/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.pos.ui.dialog;
import com.pos.ui.panel.InventoryPanel;
import com.pos.config.ConnectDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class AddStockDialog extends javax.swing.JDialog {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AddStockDialog.class.getName());
  
    
    private int productId;
    private String productName;
    private int piecesPerBulk;
    private InventoryPanel inventoryPanel; 
    
    public AddStockDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
       txtPiecesPerBulk.setEditable(false);
       setLocationRelativeTo(null);
        
        
        txtBulkQuantity.getDocument().addDocumentListener(
        new javax.swing.event.DocumentListener() {

            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                calculateTotalPieces();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                calculateTotalPieces();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                calculateTotalPieces();
            }
        }
    );
    }
    
    
    
    
    public AddStockDialog(java.awt.Frame parent, boolean modal,
                      int productId, String productName,
                      int piecesPerBulk, InventoryPanel inventoryPanel) {
    this(parent, modal);

    this.productId = productId;
    this.productName = productName;
    this.piecesPerBulk = piecesPerBulk;
    this.inventoryPanel = inventoryPanel;

    lblProductName.setText(productName);
    txtPiecesPerBulk.setText(String.valueOf(piecesPerBulk));
    txtPiecesPerBulk.setEditable(false);

    txtBulkQuantity.setText("");
    lblTotalPieces.setText("0 pieces");

    jDateChooser1.setDateFormatString("yyyy-MM-dd");

    // Automatically calculate when bulk quantity changes.
    jButton4.addActionListener(e -> saveStock());
    jButton5.addActionListener(e -> dispose());

    setLocationRelativeTo(parent);
 }
 
 private void calculateTotalPieces() {
     try {
        int bulkQuantity = Integer.parseInt(
            txtBulkQuantity.getText().trim()
        );

        if (bulkQuantity < 0 || piecesPerBulk <= 0) {
            lblTotalPieces.setText("0 pieces");
            return;
        }

        long totalPieces = (long) bulkQuantity * piecesPerBulk;

        lblTotalPieces.setText(totalPieces + " pieces");

    } catch (NumberFormatException e) {
        lblTotalPieces.setText("0 pieces");
    }
 }
 private void saveStock() {

    if (productId <= 0 || piecesPerBulk <= 0) {
        JOptionPane.showMessageDialog(this,
            "Invalid product information. Please open Add Stock from Inventory.");
        return;
    }

    int bulkQuantity;

    try {
        bulkQuantity = Integer.parseInt(
            txtBulkQuantity.getText().trim()
        );

        if (bulkQuantity <= 0) {
            JOptionPane.showMessageDialog(this,
                "Bulk quantity must be greater than zero.");
            return;
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this,
            "Please enter a valid bulk quantity.");
        return;
    }

    java.util.Date selectedDate = jDateChooser1.getDate();

    if (selectedDate == null) {
        JOptionPane.showMessageDialog(this,
            "Please select an expiration date.");
        return;
    }

    java.sql.Date expirationDate =
        new java.sql.Date(selectedDate.getTime());

    if (expirationDate.toLocalDate().isBefore(
            java.time.LocalDate.now())) {

        JOptionPane.showMessageDialog(this,
            "Expiration date cannot be in the past.");
        return;
    }

    long totalPieces;

    try {
        totalPieces = Math.multiplyExact(
            (long) bulkQuantity,
            (long) piecesPerBulk
        );

        if (totalPieces > Integer.MAX_VALUE) {
            JOptionPane.showMessageDialog(this,
                "The calculated stock quantity is too large.");
            return;
        }

    } catch (ArithmeticException e) {
        JOptionPane.showMessageDialog(this,
            "The calculated quantity is too large.");
        return;
    }

    String batchNumber = "ADD-" + System.currentTimeMillis();

    String insertBatchSQL =
        "INSERT INTO inventory_batches "
        + "(product_id, batch_number, date_received, expiration_date, "
        + "bulk_added, initial_pieces, remaining_pieces, status) "
        + "VALUES (?, ?, CURRENT_DATE(), ?, ?, ?, ?, 'Available')";

    String updateStockSQL =
    "UPDATE products "
    + "SET stock_quantity = stock_quantity + ? "
    + "WHERE product_id = ? AND status = 'Active'";

    try (Connection conn = ConnectDb.getConnection()) {

        boolean originalAutoCommit = conn.getAutoCommit();

        try {
            conn.setAutoCommit(false);

            // 1. Insert the new delivery batch.
            try (PreparedStatement ps =
                    conn.prepareStatement(insertBatchSQL)) {

                ps.setInt(1, productId);
                ps.setString(2, batchNumber);
                ps.setDate(3, expirationDate);
                ps.setInt(4, bulkQuantity);
                ps.setInt(5, (int) totalPieces);
                ps.setInt(6, (int) totalPieces);

                ps.executeUpdate();
            }

            // 2. Increase the product's total stock.
            try (PreparedStatement ps =
                    conn.prepareStatement(updateStockSQL)) {

                ps.setInt(1, (int) totalPieces);
                ps.setInt(2, productId);

                int updatedRows = ps.executeUpdate();

                if (updatedRows != 1) {
                    throw new SQLException(
                        "Product not found or already archived."
                    );
                }
            }

            // Both database operations succeeded.
            conn.commit();

        } catch (SQLException | RuntimeException e) {
            conn.rollback();
            throw e;

        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }

        JOptionPane.showMessageDialog(this,
            "Stock added successfully!\n\n"
            + "Product: " + productName + "\n"
            + "Bulk Quantity: " + bulkQuantity + "\n"
            + "Pieces per Bulk: " + piecesPerBulk + "\n"
            + "Additional Pieces: " + totalPieces);

        // Refresh the Inventory table and POS products.
        if (inventoryPanel != null) {
            inventoryPanel.refreshProductList();
        }

        dispose();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(this,
            "Database Error:\n" + e.getMessage(),
            "Add Stock Error",
            JOptionPane.ERROR_MESSAGE);
    }
}
 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        lblProductName = new javax.swing.JLabel();
        lblTotalPieces = new javax.swing.JLabel();
        txtBulkQuantity = new javax.swing.JTextField();
        txtPiecesPerBulk = new javax.swing.JTextField();

        jLabel1.setText("jLabel1");

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("ADD NEW STOCK");

        jLabel5.setText("Bulk Quantity");

        jLabel6.setText("Pieces per Bulk");

        jLabel7.setText("Total Pieces:");

        jLabel8.setText("Expiration Date");

        jButton4.setBackground(new java.awt.Color(0, 128, 0));
        jButton4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Save Stock");

        jButton5.setBackground(new java.awt.Color(153, 153, 153));
        jButton5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Cancel");
        jButton5.addActionListener(this::jButton5ActionPerformed);

        lblProductName.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblProductName.setForeground(new java.awt.Color(0, 153, 153));

        lblTotalPieces.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblTotalPieces.setForeground(new java.awt.Color(0, 0, 255));
        lblTotalPieces.setText("0");

        txtBulkQuantity.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtBulkQuantity.addActionListener(this::txtBulkQuantityActionPerformed);

        txtPiecesPerBulk.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtPiecesPerBulk.addActionListener(this::txtPiecesPerBulkActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(191, 191, 191))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtPiecesPerBulk, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtBulkQuantity, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblTotalPieces)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(93, 93, 93))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(lblProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtBulkQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtPiecesPerBulk, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(lblTotalPieces))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(77, 77, 77))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void txtBulkQuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBulkQuantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBulkQuantityActionPerformed

    private void txtPiecesPerBulkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPiecesPerBulkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPiecesPerBulkActionPerformed

   
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                AddStockDialog dialog = new AddStockDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblProductName;
    private javax.swing.JLabel lblTotalPieces;
    private javax.swing.JTextField txtBulkQuantity;
    private javax.swing.JTextField txtPiecesPerBulk;
    // End of variables declaration//GEN-END:variables
}
