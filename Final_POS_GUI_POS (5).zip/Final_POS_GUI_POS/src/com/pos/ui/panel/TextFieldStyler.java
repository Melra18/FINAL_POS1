package com.pos.ui.panel;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.BorderFactory;
import javax.swing.JTextField;
import javax.swing.border.AbstractBorder;

public final class TextFieldStyler {

    private static final Color NORMAL_BORDER = new Color(210, 218, 228);
    private static final Color FOCUS_BORDER = new Color(59, 130, 246);
    private static final Color NORMAL_BACKGROUND = Color.WHITE;
    private static final Color TEXT_COLOR = new Color(35, 45, 60);
    private static final Color PLACEHOLDER_COLOR = new Color(145, 155, 170);

    private TextFieldStyler() {
    }

    public static void style(JTextField field) {
        if (field == null) {
            return;
        }

        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(TEXT_COLOR);
        field.setBackground(NORMAL_BACKGROUND);
        field.setCaretColor(FOCUS_BORDER);
        field.setSelectionColor(new Color(210, 228, 255));
        field.setSelectedTextColor(TEXT_COLOR);
        field.setOpaque(false);
        field.setMargin(new Insets(0, 0, 0, 0));
        field.setBorder(new RoundedBorder(NORMAL_BORDER, 10, 1));
        field.setCursor(new Cursor(Cursor.TEXT_CURSOR));

        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(new RoundedBorder(FOCUS_BORDER, 10, 2));
                field.repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(new RoundedBorder(NORMAL_BORDER, 10, 1));
                field.repaint();
            }
        });
    }

    public static void styleAll(JTextField... fields) {
        if (fields == null) {
            return;
        }

        for (JTextField field : fields) {
            style(field);
        }
    }

    public static void setPlaceholder(JTextField field, String placeholder) {
        if (field == null) {
            return;
        }

        field.setToolTipText(placeholder);

        field.putClientProperty("placeholder", placeholder);

        field.setUI(new javax.swing.plaf.basic.BasicTextFieldUI() {
            @Override
            protected void paintSafely(Graphics g) {
                super.paintSafely(g);

                if (field.getText().isEmpty() && !field.hasFocus()) {
                    Object value = field.getClientProperty("placeholder");

                    if (value instanceof String) {
                        Graphics2D g2 = (Graphics2D) g.create();

                        g2.setRenderingHint(
                            RenderingHints.KEY_TEXT_ANTIALIASING,
                            RenderingHints.VALUE_TEXT_ANTIALIAS_ON
                        );

                        g2.setColor(PLACEHOLDER_COLOR);
                        g2.setFont(field.getFont());

                        Insets insets = field.getInsets();

                        g2.drawString(
                            (String) value,
                            insets.left + 2,
                            (field.getHeight()
                                - g2.getFontMetrics().getHeight()) / 2
                                + g2.getFontMetrics().getAscent()
                        );

                        g2.dispose();
                    }
                }
            }
        });
    }

    private static class RoundedBorder extends AbstractBorder {

        private final Color color;
        private final int radius;
        private final int thickness;

        RoundedBorder(Color color, int radius, int thickness) {
            this.color = color;
            this.radius = radius;
            this.thickness = thickness;
        }

        @Override
        public void paintBorder(
                java.awt.Component component,
                Graphics graphics,
                int x,
                int y,
                int width,
                int height) {

            Graphics2D g2 = (Graphics2D) graphics.create();

            g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(color);
            g2.setStroke(new java.awt.BasicStroke(thickness));

            int offset = thickness / 2;

            g2.drawRoundRect(
                x + offset,
                y + offset,
                width - thickness,
                height - thickness,
                radius,
                radius
            );

            g2.dispose();
        }

       @Override
public Insets getBorderInsets(java.awt.Component component) {
    return new Insets(3, 8, 3, 8);
}

@Override
public Insets getBorderInsets(
        java.awt.Component component,
        Insets insets) {

    insets.top = 3;
    insets.left = 8;
    insets.bottom = 3;
    insets.right = 8;

    return insets;
}
    }
}