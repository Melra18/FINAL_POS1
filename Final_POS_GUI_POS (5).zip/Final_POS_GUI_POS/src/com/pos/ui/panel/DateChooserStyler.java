
package com.pos.ui.panel;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.border.Border;

public final class DateChooserStyler {

    private static final Color BACKGROUND = Color.WHITE;
    private static final Color FOREGROUND = new Color(45, 55, 72);
    private static final Color BORDER = new Color(203, 213, 225);
    private static final Color FOCUS = new Color(51, 105, 170);

    private DateChooserStyler() {
    }

    public static void style(JDateChooser chooser) {
        if (chooser == null) {
            return;
        }

        Font font = new Font("Segoe UI", Font.PLAIN, 12);

        Border normalBorder = BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER, 1, true),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        );

        Border focusBorder = BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(FOCUS, 1, true),
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        );

        chooser.setFont(font);
        chooser.setBackground(BACKGROUND);
        chooser.setForeground(FOREGROUND);
        chooser.setBorder(normalBorder);

        // Keep the original layout dimensions.
        Dimension originalSize = chooser.getPreferredSize();

        // Style the date text field.
        Component editor = chooser.getDateEditor().getUiComponent();

        if (editor instanceof JTextField) {
            JTextField field = (JTextField) editor;

            field.setFont(font);
            field.setForeground(FOREGROUND);
            field.setBackground(BACKGROUND);
            field.setCaretColor(FOCUS);
            field.setMargin(new java.awt.Insets(0, 0, 0, 0));
            field.setBorder(BorderFactory.createEmptyBorder(2, 4, 2, 4));

            field.addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    chooser.setBorder(focusBorder);
                }

                @Override
                public void focusLost(FocusEvent e) {
                    chooser.setBorder(normalBorder);
                }
            });
        }

        // Style the calendar button without changing its icon.
        JButton calendarButton = chooser.getCalendarButton();

        if (calendarButton != null) {
            calendarButton.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
            );
            calendarButton.setFocusable(false);
            calendarButton.setBackground(new Color(245, 247, 250));
            calendarButton.setToolTipText("Select date");
            calendarButton.setMargin(new java.awt.Insets(0, 3, 0, 3));
            calendarButton.setPreferredSize(new Dimension(28, 24));
        }

        // Preserve the chooser's existing preferred dimensions.
        chooser.setPreferredSize(originalSize);
    }
}
