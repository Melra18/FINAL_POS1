/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.pos.ui.panel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.pos.config.ConnectDb;
import com.pos.ui.Dashboard;
import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import com.pos.model.Expense;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import com.pos.service.ActionHistoryService;
import java.sql.Types;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.SwingConstants;
import java.text.NumberFormat;
import java.util.Locale;

public class ExpensesPanel extends javax.swing.JPanel {

        private Dashboard parentDashboard;
        
         


// Stores all currently loaded expense records
private final ArrayList<Expense> expenseList = new ArrayList<>();

// Stores total expenses grouped by category
private final HashMap<String, Double> expenseTotalsByCategory = new HashMap<>();

// Stores unique expense categories
private final HashSet<String> expenseCategories = new HashSet<>();
        
private boolean loadingCategories = false;       
        
        
        
  private void loadExpenses() {

    DefaultTableModel model =
            (DefaultTableModel) jTable1.getModel();

    model.setRowCount(0);

    // Clear old data before reloading.
    expenseList.clear();
    expenseTotalsByCategory.clear();
    expenseCategories.clear();

    String sql =
            "SELECT expense_id, title, category, amount, "
            + "expense_date, recorded_by "
            + "FROM expenses "
            + "WHERE is_archived = 0 "
            + "ORDER BY expense_date DESC, expense_id DESC";

    try (Connection conn = ConnectDb.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Expense expense = new Expense(
                        rs.getInt("expense_id"),
                        rs.getString("title"),
                        rs.getString("category"),
                        rs.getDouble("amount"),
                        rs.getDate("expense_date"),
                        rs.getString("recorded_by")
                );

                // ArrayList: store expense records.
                expenseList.add(expense);

                // HashSet: store unique categories.
                if (expense.getCategory() != null
                        && !expense.getCategory().trim().isEmpty()) {
                    expenseCategories.add(expense.getCategory());
                }

                // HashMap: calculate totals per category.
                String category = expense.getCategory();

                if (category != null && !category.trim().isEmpty()) {
                    expenseTotalsByCategory.merge(
                            category,
                            expense.getAmount(),
                            Double::sum
                    );
                }

                model.addRow(new Object[]{
                    expense.getExpenseId(),
                    expense.getTitle(),
                    expense.getCategory(),
                    expense.getAmount(),
                    expense.getExpenseDate(),
                    expense.getRecordedBy()
                });
            }
        }

        // Refresh the category dropdown.
        loadExpenseCategories();

        // Reapply active filters and update the displayed total.
        applyExpenseFilter();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading expenses: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
  
  private double getTotalExpenses() {

    double total = 0;

    for (Expense expense : expenseList) {
        total += expense.getAmount();
    }

    return total;
}
  
  private double getCategoryTotal(String category) {

    return expenseTotalsByCategory.getOrDefault(category, 0.0);
}
  
  private Set<String> getExpenseCategories() {

    return new HashSet<>(expenseCategories);
}
  
  private void updateExpenseSummary() {

    double total = getTotalExpenses();

    lblTotalExpenses.setText(
            String.format("Total Expenses: ₱%,.2f", total)
    );
}
 
  private void applyExpenseFilter() {

    String searchText = txtSearchExpense.getText()
            .trim().toLowerCase();

    String selectedCategory =
            cmbExpenseCategory.getSelectedItem() == null
            ? "All Categories"
            : cmbExpenseCategory.getSelectedItem().toString();

    java.util.Date fromDate = jDateChooser2.getDate();
    java.util.Date toDate = jDateChooser1.getDate();

    DefaultTableModel model =
            (DefaultTableModel) jTable1.getModel();

    model.setRowCount(0);

    // Validate date range
    if (fromDate != null && toDate != null
            && fromDate.after(toDate)) {

        lblTotalExpenses.setText("Invalid date range");
        return;
    }

    double filteredTotal = 0;

    SimpleDateFormat dateFormat =
            new SimpleDateFormat("yyyy-MM-dd");

    for (Expense expense : expenseList) {

        String title = expense.getTitle() == null
                ? ""
                : expense.getTitle().toLowerCase();

        String category = expense.getCategory() == null
                ? ""
                : expense.getCategory().toLowerCase();

        String recordedBy = expense.getRecordedBy() == null
                ? ""
                : expense.getRecordedBy().toLowerCase();

        boolean matchesSearch =
                title.contains(searchText)
                || category.contains(searchText)
                || recordedBy.contains(searchText);

        boolean matchesCategory =
                selectedCategory.equalsIgnoreCase("All Categories")
                || category.equalsIgnoreCase(selectedCategory);

        // Match the expense date inclusively
        java.util.Date expenseDate = expense.getExpenseDate();

        boolean matchesDate = true;

        if (expenseDate == null) {
            matchesDate = fromDate == null && toDate == null;
        } else {
            String expenseDateText =
                    dateFormat.format(expenseDate);

            if (fromDate != null) {
                String fromDateText = dateFormat.format(fromDate);

                if (expenseDateText.compareTo(fromDateText) < 0) {
                    matchesDate = false;
                }
            }

            if (toDate != null) {
                String toDateText = dateFormat.format(toDate);

                if (expenseDateText.compareTo(toDateText) > 0) {
                    matchesDate = false;
                }
            }
        }

        if (matchesSearch && matchesCategory && matchesDate) {

            model.addRow(new Object[]{
                expense.getExpenseId(),
                expense.getTitle(),
                expense.getCategory(),
                expense.getAmount(),
                expense.getExpenseDate(),
                expense.getRecordedBy()
            });

            filteredTotal += expense.getAmount();
        }
    }

    lblTotalExpenses.setText(
            String.format("Total Expenses: ₱%,.2f", filteredTotal)
    );
  }
  
  private void loadExpenseCategories() {
      
    String previousEntryCategory =
            jComboBox1.getSelectedItem() == null
            ? null
            : jComboBox1.getSelectedItem().toString();

    String previousFilterCategory =
            cmbExpenseCategory.getSelectedItem() == null
            ? "All Categories"
            : cmbExpenseCategory.getSelectedItem().toString();

    loadingCategories = true;

    try {
        ArrayList<String> databaseCategories = new ArrayList<>();

        String sql =
                "SELECT category_name FROM categories "
                + "WHERE category_type = 'EXPENSE' "
                + "ORDER BY category_name ASC";

        try (Connection conn = ConnectDb.getConnection()) {

            if (conn == null) {
                throw new SQLException("Database connection failed.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    String category = rs.getString("category_name");

                    if (category != null && !category.trim().isEmpty()) {
                        databaseCategories.add(category);
                    }
                }
            }
        }

        // Dropdown used when recording a NEW expense.
        jComboBox1.removeAllItems();

        for (String category : databaseCategories) {
            jComboBox1.addItem(category);
        }

        if (previousEntryCategory != null
                && databaseCategories.contains(previousEntryCategory)) {
            jComboBox1.setSelectedItem(previousEntryCategory);
        } else if (jComboBox1.getItemCount() > 0) {
            jComboBox1.setSelectedIndex(0);
        }

        // Filter dropdown: include database categories and historical labels.
        HashSet<String> filterCategories = new HashSet<>(databaseCategories);
        filterCategories.addAll(expenseCategories);

        ArrayList<String> sortedCategories =
                new ArrayList<>(filterCategories);

        java.util.Collections.sort(
                sortedCategories,
                String.CASE_INSENSITIVE_ORDER
        );

        cmbExpenseCategory.removeAllItems();
        cmbExpenseCategory.addItem("All Categories");

        for (String category : sortedCategories) {
            cmbExpenseCategory.addItem(category);
        }

        if (filterCategories.contains(previousFilterCategory)) {
            cmbExpenseCategory.setSelectedItem(previousFilterCategory);
        } else {
            cmbExpenseCategory.setSelectedItem("All Categories");
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading expense categories: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );

    } finally {
        loadingCategories = false;
    }
}
  
    private void archiveSelectedExpense() {

        int row = jTable1.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(
                this,
                "Please select an expense to archive.",
                "Archive",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    // Convert the selected view row to the actual table row.
    row = jTable1.convertRowIndexToModel(row);

    int id = ((Number) jTable1.getModel().getValueAt(row, 0))
            .intValue();

    String title = String.valueOf(
            jTable1.getModel().getValueAt(row, 1));

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Archive expense \"" + title + "\"?\n\n"
            + "You can restore it later.",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
            "UPDATE expenses "
            + "SET is_archived = 1, archived_at = NOW() "
            + "WHERE expense_id = ? AND is_archived = 0";

    try (Connection conn = ConnectDb.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        boolean originalAutoCommit = conn.getAutoCommit();

        try {
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);

                if (ps.executeUpdate() != 1) {
                    throw new SQLException(
                            "Expense not found or already archived.");
                }
            }

            // Record the history using the SAME transaction.
            ActionHistoryService.recordAction(
                    conn,
                    parentDashboard.getCurrentUser(),
                    "Expenses",
                    "ARCHIVE_EXPENSE",
                    "expenses",
                    (long) id,
                    "Archive expense: " + title,
                    "ACTIVE",
                    "ARCHIVED"
            );

            conn.commit();

        } catch (SQLException | RuntimeException ex) {
            try {
                conn.rollback();
            } catch (SQLException rollbackError) {
                ex.addSuppressed(rollbackError);
            }

            throw ex;

        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }

        loadExpenses();

        JOptionPane.showMessageDialog(
                this,
                "Expense archived and history recorded successfully!"
        );

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Error archiving expense:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}


private void openExpenseVault() {

    JDialog dialog = new JDialog(
            SwingUtilities.getWindowAncestor(this),
            "Expense Archive Vault",
            Dialog.ModalityType.APPLICATION_MODAL);

    DefaultTableModel vaultModel = new DefaultTableModel(
            new String[]{"ID", "Title", "Category", "Amount", "Date", "Archived At"}, 0) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };

    JTable vaultTable = new JTable(vaultModel);
    vaultTable.setRowHeight(28);
    loadExpenseVault(vaultModel);

    JButton btnRestore = new JButton("Restore");
    JButton btnDelete = new JButton("Delete Permanently");
    JButton btnClose = new JButton("Close");

    btnRestore.addActionListener(e -> {
    int row = vaultTable.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(
                dialog,
                "Select an expense first."
        );
        return;
    }

    int id = ((Number) vaultModel.getValueAt(row, 0)).intValue();
    String title = String.valueOf(vaultModel.getValueAt(row, 1));

    int confirm = JOptionPane.showConfirmDialog(
            dialog,
            "Restore expense \"" + title + "\"?",
            "Confirm Restore",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
            "UPDATE expenses "
            + "SET is_archived = 0, archived_at = NULL "
            + "WHERE expense_id = ? AND is_archived = 1";

    try (Connection conn = ConnectDb.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        boolean originalAutoCommit = conn.getAutoCommit();

        try {
            conn.setAutoCommit(false);

            // Restore the expense.
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);

                if (ps.executeUpdate() != 1) {
                    throw new SQLException(
                            "Expense not found or is not archived."
                    );
                }
            }

            // Record the restore action in the same transaction.
            ActionHistoryService.recordAction(
                    conn,
                    parentDashboard.getCurrentUser(),
                    "Expenses",
                    "RESTORE_EXPENSE",
                    "expenses",
                    (long) id,
                    "Restore expense: " + title,
                    "ARCHIVED",
                    "ACTIVE"
            );

            conn.commit();

        } catch (SQLException | RuntimeException ex) {
            try {
                conn.rollback();
            } catch (SQLException rollbackError) {
                ex.addSuppressed(rollbackError);
            }

            throw ex;

        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }

        // Refresh both tables after a successful transaction.
        loadExpenseVault(vaultModel);
        loadExpenses();

        JOptionPane.showMessageDialog(
                dialog,
                "Expense restored and history recorded successfully!"
        );

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(
                dialog,
                "Error restoring expense:\n" + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
});
    btnClose.addActionListener(e -> dialog.dispose());

    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
    buttons.add(btnRestore);
    buttons.add(btnDelete);
    buttons.add(btnClose);

    dialog.setLayout(new BorderLayout());
    dialog.add(new JScrollPane(vaultTable), BorderLayout.CENTER);
    dialog.add(buttons, BorderLayout.SOUTH);
    dialog.setPreferredSize(new Dimension(800, 420));
    dialog.pack();
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);
}


private void loadExpenseVault(DefaultTableModel vaultModel) {

    vaultModel.setRowCount(0);

    String sql = "SELECT expense_id, title, category, amount, expense_date, archived_at "
               + "FROM expenses WHERE is_archived = 1 "
               + "ORDER BY archived_at DESC";

    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm a");

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Timestamp arch = rs.getTimestamp("archived_at");
            vaultModel.addRow(new Object[]{
                rs.getInt("expense_id"),
                rs.getString("title"),
                rs.getString("category"),
                String.format("₱%,.2f", rs.getDouble("amount")),
                rs.getDate("expense_date"),
                arch == null ? "" : fmt.format(arch)
            });
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Error loading vault:\n" + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}
    

private void registerExpenseHistoryHandlers() {

    ActionHistoryService.registerHandler(
        "Expenses",
        "ARCHIVE_EXPENSE",
        new ActionHistoryService.ActionHandler() {

            @Override
            public void undo(Connection connection,
                    ActionHistoryService.HistoryAction action)
                    throws SQLException {

                updateExpenseArchiveStatus(
                    connection, action.getEntityId(), false);
            }

            @Override
            public void redo(Connection connection,
                    ActionHistoryService.HistoryAction action)
                    throws SQLException {

                updateExpenseArchiveStatus(
                    connection, action.getEntityId(), true);
            }
        }
    );

    ActionHistoryService.registerHandler(
        "Expenses",
        "RESTORE_EXPENSE",
        new ActionHistoryService.ActionHandler() {

            @Override
            public void undo(Connection connection,
                    ActionHistoryService.HistoryAction action)
                    throws SQLException {

                updateExpenseArchiveStatus(
                    connection, action.getEntityId(), true);
            }

            @Override
            public void redo(Connection connection,
                    ActionHistoryService.HistoryAction action)
                    throws SQLException {

                updateExpenseArchiveStatus(
                    connection, action.getEntityId(), false);
            }
        }
    );
}

private void updateExpenseArchiveStatus(
        Connection connection, Long expenseId, boolean archived)
        throws SQLException {

    if (expenseId == null) {
        throw new SQLException("Missing expense ID in history.");
    }

    String sql = archived
        ? "UPDATE expenses SET is_archived = 1, archived_at = NOW() "
          + "WHERE expense_id = ?"
        : "UPDATE expenses SET is_archived = 0, archived_at = NULL "
          + "WHERE expense_id = ?";

    try (PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setLong(1, expenseId);

        if (ps.executeUpdate() != 1) {
            throw new SQLException(
                "The expense no longer exists. No change was made.");
        }
    }
}
    
private void styleExpensesTable() {
     // Table appearance
    jTable1.setRowHeight(30);
    jTable1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    jTable1.setForeground(new Color(45, 55, 65));
    jTable1.setBackground(Color.WHITE);

    jTable1.setSelectionBackground(new Color(70, 120, 150));
    jTable1.setSelectionForeground(Color.WHITE);

    jTable1.setShowGrid(true);
    jTable1.setShowHorizontalLines(true);
    jTable1.setShowVerticalLines(true);
    jTable1.setGridColor(new Color(230, 234, 238));
    jTable1.setIntercellSpacing(new Dimension(1, 1));
    jTable1.setDefaultEditor(Object.class, null);

    // Fix gray / vacant area around the table
    jPanel1.setBackground(new Color(245, 247, 250));
    jScrollPane1.setBackground(Color.WHITE);
    jScrollPane1.setOpaque(true);

    jScrollPane1.getViewport().setBackground(Color.WHITE);
    jScrollPane1.getViewport().setOpaque(true);

    jTable1.setOpaque(true);
    jTable1.setFillsViewportHeight(true);

    // Table header
    JTableHeader header = jTable1.getTableHeader();
    header.setBackground(new Color(27, 40, 56));
    header.setForeground(Color.WHITE);
    header.setFont(new Font("Segoe UI", Font.BOLD, 12));
    header.setReorderingAllowed(false);
    header.setOpaque(true);

    // Alternating row colors
    DefaultTableCellRenderer renderer =
            new DefaultTableCellRenderer() {

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            Component component =
                    super.getTableCellRendererComponent(
                            table, value, isSelected,
                            hasFocus, row, column);

            if (isSelected) {
                component.setBackground(
                        new Color(70, 120, 150));
                component.setForeground(Color.WHITE);
            } else {
                component.setBackground(
                        row % 2 == 0
                        ? Color.WHITE
                        : new Color(245, 247, 250));

                component.setForeground(
                        new Color(45, 55, 65));
            }

            if (component instanceof javax.swing.JLabel) {
                ((javax.swing.JLabel) component).setBorder(
                        BorderFactory.createEmptyBorder(0, 8, 0, 8));
            }

            return component;
        }
    };

    jTable1.setDefaultRenderer(Object.class, renderer);

    // Amount column: Philippine peso formatting
    jTable1.getColumnModel().getColumn(3)
            .setCellRenderer(new DefaultTableCellRenderer() {

        {
            setHorizontalAlignment(SwingConstants.RIGHT);
            setBorder(
                    BorderFactory.createEmptyBorder(0, 8, 0, 8));
        }

        @Override
        public Component getTableCellRendererComponent(
                JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            String text = "";

            if (value instanceof Number) {
                text = "₱" + String.format(
                        Locale.US,
                        "%,.2f",
                        ((Number) value).doubleValue());
            } else if (value != null) {
                text = value.toString();
            }

            Component component =
                    super.getTableCellRendererComponent(
                            table, text, isSelected,
                            hasFocus, row, column);

            if (isSelected) {
                component.setBackground(
                        new Color(70, 120, 150));
                component.setForeground(Color.WHITE);
            } else {
                component.setBackground(
                        row % 2 == 0
                        ? Color.WHITE
                        : new Color(245, 247, 250));

                component.setForeground(
                        new Color(45, 55, 65));
            }

            return component;
        }
    });
}

    
    public ExpensesPanel(Dashboard parentDashboard) {
    initComponents();
    
    this.parentDashboard = parentDashboard;
    
    styleExpenseButtons();
    styleExpenseFilters();

    registerExpenseHistoryHandlers();

    jDateChooser2.setDateFormatString("yyyy-MM-dd");
    jDateChooser1.setDateFormatString("yyyy-MM-dd");

    jDateChooser2.addPropertyChangeListener("date", evt -> {
        applyExpenseFilter();
    });

    jDateChooser1.addPropertyChangeListener("date", evt -> {
        applyExpenseFilter();
    });

    TextFieldStyler.styleAll(
        txtSearchExpense,
        jTextField1,
        jTextField2
    );

    TextFieldStyler.setPlaceholder(
        txtSearchExpense,
        "Search expenses..."
    );

    styleExpensesTable();
    loadExpenses();
}
  
    @SuppressWarnings("unchecked")
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        lblTotalExpenses = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtSearchExpense = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cmbExpenseCategory = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel7 = new javax.swing.JLabel();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();

        setPreferredSize(new java.awt.Dimension(1421, 860));

        jPanel1.setBackground(new java.awt.Color(245, 247, 250));
        jPanel1.setPreferredSize(new java.awt.Dimension(1421, 729));

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Title", "Category", "Amount", "Date", "Recorded By"
            }
        ));
        jTable1.setSelectionBackground(new java.awt.Color(70, 120, 150));
        jTable1.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(jTable1);

        jButton2.setBackground(new java.awt.Color(255, 0, 0));
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Archive");
        jButton2.setMinimumSize(new java.awt.Dimension(72, 25));
        jButton2.setPreferredSize(new java.awt.Dimension(72, 25));
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setText("Archive Vault");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setText("Title:");

        jLabel2.setText("Category:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Rent", "Utilities", "Restocking", "Maintenance", "Misc" }));

        jLabel3.setText("Amount: (₱)");

        jButton1.setBackground(new java.awt.Color(0, 153, 0));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Record Expenses");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        lblTotalExpenses.setText("Total Expenses: ₱0.00");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTotalExpenses)
                .addGap(16, 16, 16))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblTotalExpenses)))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        jLabel4.setText("Search:");

        txtSearchExpense.addActionListener(this::txtSearchExpenseActionPerformed);
        txtSearchExpense.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchExpenseKeyReleased(evt);
            }
        });

        jLabel5.setText("Category:");

        cmbExpenseCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All Categories", "Maintenance", "Misc", "Rent", "Restocking", "Utilities", " " }));
        cmbExpenseCategory.addActionListener(this::cmbExpenseCategoryActionPerformed);

        jLabel6.setText("To:");

        jLabel7.setText("From:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(57, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txtSearchExpense, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(cmbExpenseCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 1275, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(83, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(37, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel4)
                                .addComponent(txtSearchExpense, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5)
                                .addComponent(cmbExpenseCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7))
                            .addComponent(jDateChooser2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 604, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1415, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 854, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void styleExpenseFilters() {
    // Style the category filter
    ComboBoxStyler.style(cmbExpenseCategory);

    // Style both date filters
    DateChooserStyler.style(jDateChooser1);
    DateChooserStyler.style(jDateChooser2);

    // Style the category dropdown used when recording expenses
    ComboBoxStyler.style(jComboBox1);
}
    private void styleExpenseButtons() {
    ButtonStyler.style(jButton1, new java.awt.Color(22, 163, 74));  // Green: Record
    ButtonStyler.style(jButton2, new java.awt.Color(220, 38, 38)); // Red: Archive
    ButtonStyler.style(jButton3, new java.awt.Color(51, 65, 85));  // Slate: Archive Vault
}
    
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    String title = jTextField1.getText().trim();
    String category = jComboBox1.getSelectedItem().toString();
    String amountText = jTextField2.getText().trim();

    // Check required fields
    if (title.isEmpty() || amountText.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please enter the expense title and amount."
        );
        return;
    }

    double amount;

    try {
        amount = Double.parseDouble(amountText);

        if (amount <= 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Amount must be greater than 0."
            );
            return;
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
                this,
                "Amount must be a valid number."
        );
        return;
    }

    String sql = "INSERT INTO expenses " +
             "(title, category, amount, expense_date, recorded_by, user_id) " +
             "VALUES (?, ?, ?, CURDATE(), ?, ?)";

    
try (Connection conn = ConnectDb.getConnection()) {

    if (conn == null) {
        throw new SQLException("Database connection failed.");
    }

    try (PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, title);
        ps.setString(2, category);
        ps.setDouble(3, amount);

        String username =
                parentDashboard.getCurrentUser().getUsername();

        int userId =
                parentDashboard.getCurrentUser().getUserId();

        ps.setString(4, username);
        ps.setInt(5, userId);

        ps.executeUpdate();
    }

    loadExpenses();

    jTextField1.setText("");
    jTextField2.setText("");

    JOptionPane.showMessageDialog(
            this,
            "Expense recorded successfully!"
    );

} catch (SQLException e) {

    JOptionPane.showMessageDialog(
            this,
            "Error recording expense: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
    );
}

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
archiveSelectedExpense();

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
 openExpenseVault();

    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtSearchExpenseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchExpenseActionPerformed
    applyExpenseFilter();
    }//GEN-LAST:event_txtSearchExpenseActionPerformed

    private void txtSearchExpenseKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchExpenseKeyReleased
applyExpenseFilter();

    }//GEN-LAST:event_txtSearchExpenseKeyReleased

    private void cmbExpenseCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbExpenseCategoryActionPerformed
   if (loadingCategories) {
        return;
    }

    applyExpenseFilter();
    }//GEN-LAST:event_cmbExpenseCategoryActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbExpenseCategory;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JLabel lblTotalExpenses;
    private javax.swing.JTextField txtSearchExpense;
    // End of variables declaration//GEN-END:variables
}
