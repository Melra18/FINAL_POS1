
package com.pos.ui.panel;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.JButton;

public final class ScrollBarStyler {

    private ScrollBarStyler() {
    }

    public static void style(JScrollPane scrollPane) {

        styleBar(scrollPane.getVerticalScrollBar());
        styleBar(scrollPane.getHorizontalScrollBar());

        scrollPane.getVerticalScrollBar()
            .setUnitIncrement(16);

        scrollPane.getHorizontalScrollBar()
            .setUnitIncrement(16);

        scrollPane.setBorder(
            UIManager.getBorder("ScrollPane.border")
        );
    }

    private static void styleBar(JScrollBar bar) {

        bar.setPreferredSize(
            new Dimension(
                bar.getOrientation() == JScrollBar.VERTICAL ? 10 : 0,
                bar.getOrientation() == JScrollBar.HORIZONTAL ? 10 : 0
            )
        );

        bar.setBackground(new Color(245, 247, 250));
        bar.setForeground(new Color(180, 185, 195));

        bar.setUI(new BasicScrollBarUI() {

            @Override
            protected void configureScrollBarColors() {
                thumbColor = new Color(180, 185, 195);
                trackColor = new Color(245, 247, 250);
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createZeroButton();
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createZeroButton();
            }

            private JButton createZeroButton() {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(0, 0));
                button.setMinimumSize(new Dimension(0, 0));
                button.setMaximumSize(new Dimension(0, 0));
                button.setFocusable(false);
                button.setBorderPainted(false);
                button.setVisible(false);
                return button;
            }

            @Override
            protected void paintThumb(
                    java.awt.Graphics g,
                    javax.swing.JComponent c,
                    java.awt.Rectangle bounds) {

                if (!bounds.isEmpty() && scrollbar.isEnabled()) {
                    java.awt.Graphics2D g2 =
                        (java.awt.Graphics2D) g.create();

                    g2.setRenderingHint(
                        java.awt.RenderingHints.KEY_ANTIALIASING,
                        java.awt.RenderingHints.VALUE_ANTIALIAS_ON
                    );

                    g2.setColor(thumbColor);
                    g2.fillRoundRect(
                        bounds.x + 2,
                        bounds.y + 2,
                        bounds.width - 4,
                        bounds.height - 4,
                        8,
                        8
                    );

                    g2.dispose();
                }
            }
        });
    }
}
