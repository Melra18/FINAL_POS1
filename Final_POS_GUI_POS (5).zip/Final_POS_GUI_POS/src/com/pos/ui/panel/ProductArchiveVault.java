/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.pos.ui.panel;

/**
 *
 * @author ramel
 */
import com.pos.ui.panel.InventoryPanel;
import com.pos.config.ConnectDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ProductArchiveVault extends javax.swing.JDialog {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ProductArchiveVault.class.getName());
     private InventoryPanel inventoryPanel;

    public ProductArchiveVault(InventoryPanel inventoryPanel) {
        super((java.awt.Frame) null, true);
        this.inventoryPanel = inventoryPanel;
        initComponents();
        setLocationRelativeTo(inventoryPanel);
        loadArchivedProducts();
    }
     private void loadArchivedProducts() {
        DefaultTableModel model = (DefaultTableModel) tblArchivedProducts.getModel();
        model.setRowCount(0);

      String sql = "SELECT p.product_id, p.product_name, c.category_name, s.supplier_name, "
           + "p.price_per_piece, p.stock_quantity "
           + "FROM products p "
           + "LEFT JOIN categories c ON p.category_id = c.category_id "
           + "LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id "
           + "WHERE p.status = 'Archived'";
      
        try (Connection conn = ConnectDb.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category_name"),
                    rs.getString("supplier_name"),
                    rs.getDouble("price_per_piece"),
                    rs.getInt("stock_quantity")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading archived products: " + e.getMessage());
        }
     }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblArchivedProducts = new javax.swing.JTable();
        btnRestore1 = new javax.swing.JButton();
        btnDelete1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        tblArchivedProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Product Name", "Category", "Supplier", "Price", "Stock"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblArchivedProducts.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(tblArchivedProducts);

        btnRestore1.setText("Restore Selected");
        btnRestore1.addActionListener(this::btnRestore1ActionPerformed);

        btnDelete1.setBackground(new java.awt.Color(255, 0, 0));
        btnDelete1.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete1.setText("Delete Permanently");
        btnDelete1.addActionListener(this::btnDelete1ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRestore1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDelete1)
                        .addGap(4, 4, 4))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 642, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnDelete1)
                    .addComponent(btnRestore1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRestore1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRestore1ActionPerformed
    int[] rows = tblArchivedProducts.getSelectedRows();
    if (rows.length == 0) {
        JOptionPane.showMessageDialog(this, "Pumili muna ng product na ibabalik.");
        return;
    }

    String sql = "UPDATE products SET status = 'Active' "
           + "WHERE product_id = ? AND status = 'Archived'";
    
    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        for (int row : rows) {
            ps.setInt(1, (int) tblArchivedProducts.getValueAt(row, 0));
            ps.addBatch();
        }
        ps.executeBatch();

        loadArchivedProducts();
        inventoryPanel.refreshProductList();
        JOptionPane.showMessageDialog(this, "Product(s) restored.");
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }

    }//GEN-LAST:event_btnRestore1ActionPerformed

    private void btnDelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete1ActionPerformed
    int[] rows = tblArchivedProducts.getSelectedRows();

    if (rows.length == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a product to delete."
        );
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "The selected product(s) will be permanently deleted.\n\n"
        + "Products with sales history cannot be deleted.\n"
        + "Are you sure you want to continue?",
        "Confirm Permanent Delete",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.WARNING_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    int deleted = 0;
    int skippedSales = 0;
    int failed = 0;

    String checkSalesSql =
        "SELECT COUNT(*) FROM transaction_details "
        + "WHERE product_id = ?";

    String deleteBatchesSql =
        "DELETE FROM inventory_batches "
        + "WHERE product_id = ?";

    String deleteProductSql =
        "DELETE FROM products "
        + "WHERE product_id = ? AND status = 'Archived'";

    try (Connection conn = ConnectDb.getConnection()) {

        conn.setAutoCommit(false);

        try (
            PreparedStatement checkSales =
                conn.prepareStatement(checkSalesSql);

            PreparedStatement deleteBatches =
                conn.prepareStatement(deleteBatchesSql);

            PreparedStatement deleteProduct =
                conn.prepareStatement(deleteProductSql)
        ) {

            for (int row : rows) {

                int productId =
                    (int) tblArchivedProducts.getValueAt(row, 0);

                // ==========================================
                // 1. CHECK FOR SALES HISTORY
                // ==========================================

                checkSales.setInt(1, productId);

                int salesCount = 0;

                try (ResultSet rs = checkSales.executeQuery()) {
                    if (rs.next()) {
                        salesCount = rs.getInt(1);
                    }
                }

                // ==========================================
                // 2. DO NOT DELETE PRODUCTS WITH SALES
                // ==========================================

                if (salesCount > 0) {
                    skippedSales++;
                    continue;
                }

                // ==========================================
                // 3. DELETE INVENTORY BATCHES FIRST
                // ==========================================

                deleteBatches.setInt(1, productId);
                deleteBatches.executeUpdate();

                // ==========================================
                // 4. DELETE THE PRODUCT
                // ==========================================

                deleteProduct.setInt(1, productId);

                int result = deleteProduct.executeUpdate();

                if (result > 0) {
                    deleted++;
                } else {
                    failed++;
                }
            }

            conn.commit();

        } catch (SQLException e) {

            conn.rollback();

            JOptionPane.showMessageDialog(
                this,
                "Delete failed:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );

            return;
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Database connection error:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );

        return;
    }

    // ==========================================
    // REFRESH TABLES
    // ==========================================

    loadArchivedProducts();
    inventoryPanel.refreshProductList();

    // ==========================================
    // DISPLAY RESULT
    // ==========================================

    StringBuilder msg = new StringBuilder();

    msg.append(deleted)
       .append(" product(s) deleted.");

    if (skippedSales > 0) {
        msg.append("\n")
           .append(skippedSales)
           .append(" product(s) were not deleted because they have sales records.");
    }

    if (failed > 0) {
        msg.append("\n")
           .append(failed)
           .append(" product(s) could not be deleted.");
    }

    JOptionPane.showMessageDialog(
        this,
        msg.toString(),
        "Delete Result",
        JOptionPane.INFORMATION_MESSAGE
    );
    }//GEN-LAST:event_btnDelete1ActionPerformed
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete1;
    private javax.swing.JButton btnRestore1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblArchivedProducts;
    // End of variables declaration//GEN-END:variables
}
