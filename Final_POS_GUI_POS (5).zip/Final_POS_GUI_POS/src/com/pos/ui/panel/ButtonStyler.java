package com.pos.ui.panel;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;

public final class ButtonStyler {

    private ButtonStyler() {
    }

    // Standard POS green colors
    private static final Color GREEN =
            new Color(40, 167, 69);       // #28A745

    private static final Color GREEN_HOVER =
            new Color(33, 136, 56);       // #218838

    public static void style(JButton button, Color background) {

        if (button == null) {
            return;
        }

        Color normalColor = background;
        Color hoverColor;

        // Use the standard green hover for green buttons.
        if (GREEN.equals(background)) {
            hoverColor = GREEN_HOVER;
        } else {
            hoverColor = background.darker();
        }

        button.setBackground(normalColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setCursor(
                new java.awt.Cursor(
                        java.awt.Cursor.HAND_CURSOR
                )
        );

        // Prevent duplicate hover listeners.
        for (java.awt.event.MouseListener listener
                : button.getMouseListeners()) {

            if (listener instanceof ButtonHoverListener) {
                button.removeMouseListener(listener);
            }
        }

        button.addMouseListener(
                new ButtonHoverListener(
                        button,
                        normalColor,
                        hoverColor
                )
        );
    }

    // Convenient method for standard green buttons.
    public static void styleGreen(JButton button) {
        style(button, GREEN);
    }

    private static class ButtonHoverListener extends MouseAdapter {

        private final JButton button;
        private final Color normal;
        private final Color hover;

        ButtonHoverListener(
                JButton button,
                Color normal,
                Color hover
        ) {
            this.button = button;
            this.normal = normal;
            this.hover = hover;
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            if (button.isEnabled()) {
                button.setBackground(hover);
            }
        }

        @Override
        public void mouseExited(MouseEvent e) {
            button.setBackground(normal);
        }
    }
}
