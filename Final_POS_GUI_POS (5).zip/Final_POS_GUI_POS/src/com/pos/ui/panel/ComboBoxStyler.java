
package com.pos.ui.panel;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicComboBoxRenderer;

public final class ComboBoxStyler {

    private static final Color BACKGROUND = Color.WHITE;
    private static final Color FOREGROUND = new Color(45, 55, 72);
    private static final Color BORDER = new Color(203, 213, 225);
    private static final Color SELECTED = new Color(225, 238, 252);

    private static final Font COMBO_FONT =
            new Font("Segoe UI", Font.PLAIN, 12);

    private ComboBoxStyler() {
        // Utility class
    }

    public static void style(JComboBox<?> comboBox) {
        if (comboBox == null) {
            return;
        }

        comboBox.setFont(COMBO_FONT);
        comboBox.setForeground(FOREGROUND);
        comboBox.setBackground(BACKGROUND);
        comboBox.setFocusable(true);
        comboBox.setOpaque(true);

        // Compact border and padding
        comboBox.setBorder(new CompoundBorder(
                new LineBorder(BORDER, 1, true),
                new EmptyBorder(1, 5, 1, 5)
        ));

        // Style dropdown items
        comboBox.setRenderer(new BasicComboBoxRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list,
                    Object value,
                    int index,
                    boolean isSelected,
                    boolean cellHasFocus) {

                super.getListCellRendererComponent(
                        list,
                        value,
                        index,
                        isSelected,
                        cellHasFocus
                );

                setFont(COMBO_FONT);
                setBorder(new EmptyBorder(4, 7, 4, 7));
                setOpaque(true);

                if (isSelected) {
                    setBackground(SELECTED);
                    setForeground(FOREGROUND);
                } else {
                    setBackground(BACKGROUND);
                    setForeground(FOREGROUND);
                }

                return this;
            }
        });

        // Show up to 10 options in the dropdown
        comboBox.setMaximumRowCount(10);
    }
}
