package com.pos.ui.panel;

import com.pos.config.ConnectDb;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductPanel extends JPanel {

    public interface FilterListener {
        void onFilterChanged(int categoryId, String searchText);
    }

    private final JComboBox<CategoryItem> cbCategory;
    private final JTextField txtSearch;
    private FilterListener listener;
    private boolean loading = false;   // blocks filter events while categories reload

    public ProductPanel() {
        setBackground(Color.WHITE);
        setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        JLabel lblCategory = new JLabel("Category:");
        lblCategory.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCategory.setAlignmentY(Component.CENTER_ALIGNMENT);

        cbCategory = new JComboBox<>();
        fixSize(cbCategory, 160, 28);
        cbCategory.addActionListener(e -> fireFilterChanged());

        JLabel lblSearch = new JLabel("Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblSearch.setAlignmentY(Component.CENTER_ALIGNMENT);

        txtSearch = new JTextField();
        fixSize(txtSearch, 150, 28);
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { fireFilterChanged(); }
            public void removeUpdate(DocumentEvent e) { fireFilterChanged(); }
            public void changedUpdate(DocumentEvent e) { fireFilterChanged(); }
        });

        add(lblCategory);
        add(Box.createHorizontalStrut(6));
        add(cbCategory);
        add(Box.createHorizontalStrut(16));
        add(lblSearch);
        add(Box.createHorizontalStrut(6));
        add(txtSearch);

        loadCategories();

        // Lock the whole panel to its natural size so a parent can never stretch it
        setMaximumSize(getPreferredSize());
    }

    private void fixSize(JComponent c, int w, int h) {
        Dimension d = new Dimension(w, h);
        c.setPreferredSize(d);
        c.setMinimumSize(d);
        c.setMaximumSize(d);
        c.setAlignmentY(Component.CENTER_ALIGNMENT);
    }

    public void setFilterListener(FilterListener listener) {
        this.listener = listener;
    }

    public void reloadCategories() {
        loadCategories();
    }

    private void loadCategories() {
        // remember the current selection so a reload doesn't reset the filter
        int keepId = 0;
        Object current = cbCategory.getSelectedItem();
        if (current instanceof CategoryItem) {
            keepId = ((CategoryItem) current).getId();
        }

        loading = true;
        try {
            cbCategory.removeAllItems();
            cbCategory.addItem(new CategoryItem(0, "All Categories"));

            String sql = "SELECT category_id, category_name FROM categories";
            try (Connection conn = ConnectDb.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cbCategory.addItem(new CategoryItem(
                            rs.getInt("category_id"), rs.getString("category_name")));
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error loading categories: " + e.getMessage());
            }

            for (int i = 0; i < cbCategory.getItemCount(); i++) {
                if (cbCategory.getItemAt(i).getId() == keepId) {
                    cbCategory.setSelectedIndex(i);
                    break;
                }
            }
        } finally {
            loading = false;
        }
    }

    private void fireFilterChanged() {
        if (loading || listener == null) {
            return;
        }
        CategoryItem selected = (CategoryItem) cbCategory.getSelectedItem();
        int categoryId = (selected != null) ? selected.getId() : 0;
        String searchText = txtSearch.getText() == null ? "" : txtSearch.getText().trim();
        listener.onFilterChanged(categoryId, searchText);
    }

    private static class CategoryItem {
        private final int id;
        private final String name;
        CategoryItem(int id, String name) { this.id = id; this.name = name; }
        int getId() { return id; }
        @Override public String toString() { return name; }
    }
}