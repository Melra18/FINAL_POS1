/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.pos.ui.panel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.pos.config.ConnectDb;
import com.pos.ui.Dashboard;
import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import java.awt.Color;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

public class SalesSummary extends javax.swing.JPanel {
private Dashboard parentDashboard;



private String selectedDate;

/**
 * Creates new form SalesSummary
 */
public SalesSummary() {
     initComponents();

   selectedDate = new SimpleDateFormat("yyyy-MM-dd")
            .format(new java.util.Date());

    jDateChooser1.setDate(new java.util.Date());
    jDateChooser1.setDateFormatString("yyyy-MM-dd");

    setupTable();
    applyAlternatingRowColors();
    ScrollBarStyler.style(jScrollPane1);
    
    // Apply only your existing button and date chooser styles.
    applyExistingStyles();

    loadSalesSummary();

    jDateChooser1.addPropertyChangeListener("date", evt -> {
        if (jDateChooser1.getDate() != null) {
            selectedDate = new SimpleDateFormat("yyyy-MM-dd")
                    .format(jDateChooser1.getDate());

            loadSalesSummary();
        }
    });
}





/**
 * Setup table appearance
 */
private void setupTable() {
    tblSales.setRowHeight(30);
    tblSales.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);

    int[] widths = {60, 170, 150, 100, 60, 100, 130};

    for (int i = 0;
            i < tblSales.getColumnModel().getColumnCount();
            i++) {

        tblSales.getColumnModel().getColumn(i)
                .setPreferredWidth(widths[i]);

        tblSales.getColumnModel().getColumn(i)
                .setResizable(false);
    }

    tblSales.addMouseListener(
            new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
            if (e.getClickCount() == 2
                    && e.getButton()
                    == java.awt.event.MouseEvent.BUTTON1) {
                showTransactionDetails();
            }
        }
    });
}


private void applyAlternatingRowColors() {

    // Table body
    tblSales.setFont(
        new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12)
    );

    tblSales.setRowHeight(30);
    tblSales.setShowGrid(true);
    tblSales.setShowHorizontalLines(true);
    tblSales.setShowVerticalLines(true);

    tblSales.setGridColor(
        new java.awt.Color(225, 228, 233)
    );

    tblSales.setIntercellSpacing(
        new java.awt.Dimension(1, 1)
    );

    tblSales.setBackground(java.awt.Color.WHITE);
    tblSales.setForeground(
        new java.awt.Color(40, 40, 40)
    );

    tblSales.setSelectionBackground(
        new java.awt.Color(220, 230, 245)
    );

    tblSales.setSelectionForeground(
        new java.awt.Color(27, 40, 56)
    );

    tblSales.setFillsViewportHeight(true);

    // Table header — match Inventory
    javax.swing.table.JTableHeader header =
        tblSales.getTableHeader();

    header.setFont(
        new java.awt.Font(
            "Segoe UI",
            java.awt.Font.BOLD,
            12
        )
    );

    header.setBackground(
        new java.awt.Color(235, 238, 242)
    );

    header.setForeground(
        new java.awt.Color(35, 35, 35)
    );

    header.setPreferredSize(
        new java.awt.Dimension(0, 34)
    );

    header.setReorderingAllowed(false);

    // Alternating row colors
    javax.swing.table.DefaultTableCellRenderer renderer =
        new javax.swing.table.DefaultTableCellRenderer() {

    @Override
    public java.awt.Component getTableCellRendererComponent(
            javax.swing.JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column) {

        java.awt.Component component =
            super.getTableCellRendererComponent(
                table,
                value,
                isSelected,
                hasFocus,
                row,
                column
            );

        if (isSelected) {
            component.setBackground(
                new java.awt.Color(220, 230, 245)
            );

            component.setForeground(
                new java.awt.Color(27, 40, 56)
            );

        } else {
            component.setBackground(
                row % 2 == 0
                    ? java.awt.Color.WHITE
                    : new java.awt.Color(247, 248, 250)
            );

            component.setForeground(
                new java.awt.Color(40, 40, 40)
            );
        }

        setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                0, 7, 0, 7
            )
        );

        return component;
    }
    };

    // Apply renderer to every column
    for (int i = 0; i < tblSales.getColumnCount(); i++) {
        tblSales.getColumnModel()
            .getColumn(i)
            .setCellRenderer(renderer);
    }

    // Keep columns automatically resized
    tblSales.setAutoResizeMode(
        javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS
    );
}




/**
 * Load daily sales summary
 */
private void loadSalesSummary() {

    // ==========================================
    // SUMMARY CARDS
    // ==========================================

    String sqlStats =
        "SELECT " +
        "COALESCE(SUM(final_amount), 0) AS gross_sale, " +
        "COUNT(transaction_id) AS transaction_count, " +
        "COALESCE(AVG(final_amount), 0) AS average_sale " +
        "FROM transactions " +
        "WHERE DATE(transaction_date) = ? AND is_archived = 0";


    try (Connection conn =
                ConnectDb.getConnection();
         PreparedStatement ps =
                conn.prepareStatement(sqlStats)) {

        ps.setString(1, selectedDate);

        try (ResultSet rs =
                ps.executeQuery()) {

            if (rs.next()) {

                double grossSale =
                        rs.getDouble("gross_sale");

                int transactionCount =
                        rs.getInt("transaction_count");

                double averageSale =
                        rs.getDouble("average_sale");


                jLabel3.setText(
                        formatPeso(grossSale)
                );

                jLabel5.setText(
                        String.valueOf(transactionCount)
                );

                jLabel7.setText(
                        formatPeso(averageSale)
                );
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading sales summary:\n"
                        + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }


    // ==========================================
    // SALES TABLE
    // ==========================================

   String sqlTable =
    "SELECT " +
    "t.transaction_id, " +
    "t.transaction_date, " +
    "COALESCE(" +
    "u.full_name, " +
    "CONCAT('User #', t.user_id)" +
    ") AS cashier, " +
    "t.payment_method, " +
    "(SELECT COUNT(*) " +
    " FROM transaction_details d " +
    " WHERE d.transaction_id = t.transaction_id" +
    ") AS item_count, " +
    "(t.subtotal_amount - (t.subtotal_amount / 1.12)) AS vat, " +
    "t.final_amount " +
    "FROM transactions t " +
    "LEFT JOIN users u " +
    "ON t.user_id = u.user_id " +
    "WHERE DATE(t.transaction_date) = ? AND t.is_archived = 0 " +
    "ORDER BY t.transaction_date DESC";


    DefaultTableModel model =
            (DefaultTableModel) tblSales.getModel();

    model.setRowCount(0);


    try (Connection conn =
                ConnectDb.getConnection();
         PreparedStatement ps =
                conn.prepareStatement(sqlTable)) {

        ps.setString(1, selectedDate);

        try (ResultSet rs =
                ps.executeQuery()) {

            while (rs.next()) {

                Timestamp timestamp =
                        rs.getTimestamp(
                                "transaction_date"
                        );

                String time =
                        timestamp == null
                        ? ""
                        : new SimpleDateFormat(
                                "yyyy-MM-dd hh:mm:ss a"
                          ).format(timestamp);


               model.addRow(new Object[] {
               rs.getInt("transaction_id"),
               time,
               rs.getString("cashier"),
               rs.getString("payment_method"),
               rs.getInt("item_count"),
               formatPeso(rs.getDouble("vat")),
               formatPeso(rs.getDouble("final_amount"))
               });
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading sales records:\n"
                        + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}


/**
 * Show transaction details
 */
    private void showTransactionDetails() {

    int selectedRow =
            tblSales.getSelectedRow();

    if (selectedRow == -1) {

        JOptionPane.showMessageDialog(
                this,
                "Please select a transaction first.",
                "Transaction Details",
                JOptionPane.WARNING_MESSAGE
        );

        return;
    }


    int transactionId =
            ((Number) tblSales
                    .getValueAt(
                            selectedRow,
                            0
                    ))
                    .intValue();


    String cashier =
            String.valueOf(
                    tblSales.getValueAt(
                            selectedRow,
                            2
                    )
            );

    String payment =
            String.valueOf(
                    tblSales.getValueAt(
                            selectedRow,
                            3
                    )
            );

   double vat = Double.parseDouble(
        tblSales.getValueAt(selectedRow, 5)
                .toString()
                .replace("₱", "")
                .replace(",", "")
                .trim()
);

double total = Double.parseDouble(
        tblSales.getValueAt(selectedRow, 6)
                .toString()
                .replace("₱", "")
                .replace(",", "")
                .trim()
);


    String sql =
       "SELECT " +
    "d.quantity_sold, " +
    "d.unit_price, " +
    "d.subtotal, " +
    "p.product_name " +
    "FROM transaction_details d " +
    "LEFT JOIN products p " +
    "ON d.product_id = p.product_id " +
    "WHERE d.transaction_id = ?";

    StringBuilder details =
            new StringBuilder();

    details.append(
            "Transaction ID: "
            + transactionId
            + "\n"
    );

    details.append(
            "Cashier: "
            + cashier
            + "\n"
    );

    details.append(
            "Payment: "
            + payment
            + "\n\n"
    );

    details.append(
            "ITEMS\n"
    );

    details.append(
            "--------------------------------\n"
    );


    try (Connection conn =
                ConnectDb.getConnection();
         PreparedStatement ps =
                conn.prepareStatement(sql)) {

        ps.setInt(1, transactionId);

        try (ResultSet rs =
                ps.executeQuery()) {

            while (rs.next()) {

                String product =
                        rs.getString(
                                "product_name"
                        );

                int qty = rs.getInt("quantity_sold");
                        

                double unitPrice =
                        rs.getDouble(
                                "unit_price"
                        );

                double subtotal =
                        rs.getDouble(
                                "subtotal"
                        );


                details.append(
                        product
                        + " x"
                        + qty
                        + " @ "
                        + formatPeso(unitPrice)
                        + " = "
                        + formatPeso(subtotal)
                        + "\n"
                );
            }
        }


        details.append(
                "\nVAT: "
                + formatPeso(vat)
        );

        details.append(
                "\nTOTAL: "
                + formatPeso(total)
        );


        JOptionPane.showMessageDialog(
                this,
                details.toString(),
                "Transaction #"
                        + transactionId
                        + " Details",
                JOptionPane.INFORMATION_MESSAGE
        );


    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading transaction details:\n"
                        + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}


/**
 * Format Philippine Peso
 */
private String formatPeso(double amount) {

    return String.format(
            "₱%,.2f",
            amount
    );
}


private void applyExistingStyles() {

     ButtonStyler.style(
            btnView,
            new java.awt.Color(37, 99, 235)
    );

    ButtonStyler.style(
            btnRefresh,
            new java.awt.Color(18, 18, 58)
    );

    ButtonStyler.style(
            btnArchive,
            new java.awt.Color(220, 38, 38)
    );

    ButtonStyler.style(
            btnVault,
            new java.awt.Color(71, 85, 105)
    );

    jDateChooser1.setDateFormatString("yyyy-MM-dd");
    DateChooserStyler.style(jDateChooser1);
}




private void archiveSelectedTransaction() {

    int row = tblSales.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(this,
                "Please select a transaction to archive.",
                "Archive", JOptionPane.WARNING_MESSAGE);
        return;
    }

    int id = ((Number) tblSales.getValueAt(row, 0)).intValue();

    int confirm = JOptionPane.showConfirmDialog(this,
            "Archive Transaction #" + id + "?\n\n"
            + "It will be removed from the sales summary and moved to the Archive Vault.\n"
            + "You can restore it later.",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

    if (confirm != JOptionPane.YES_OPTION) return;

    String sql = "UPDATE transactions "
               + "SET is_archived = 1, archived_at = NOW() "
               + "WHERE transaction_id = ?";

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, id);
        ps.executeUpdate();
        loadSalesSummary();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Error archiving transaction:\n" + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}


private void openArchiveVault() {

    JDialog dialog = new JDialog(
            SwingUtilities.getWindowAncestor(this),
            "Archive Vault",
            Dialog.ModalityType.APPLICATION_MODAL);

    DefaultTableModel vaultModel = new DefaultTableModel(
            new String[]{"Tx ID", "Date", "Payment", "Total", "Archived At"}, 0) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };

    JTable vaultTable = new JTable(vaultModel);
    vaultTable.setRowHeight(28);

    loadVault(vaultModel);

    JButton btnRestore = new JButton("Restore");
    JButton btnDelete = new JButton("Delete Permanently");
    JButton btnClose = new JButton("Close");

    btnRestore.addActionListener(e -> {
        int row = vaultTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(dialog, "Select a transaction first.");
            return;
        }
        int id = ((Number) vaultModel.getValueAt(row, 0)).intValue();

        String sql = "UPDATE transactions "
                   + "SET is_archived = 0, archived_at = NULL "
                   + "WHERE transaction_id = ?";

        try (Connection conn = ConnectDb.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            loadVault(vaultModel);
            loadSalesSummary();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog,
                    "Error restoring:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnDelete.addActionListener(e -> {
        int row = vaultTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(dialog, "Select a transaction first.");
            return;
        }
        int id = ((Number) vaultModel.getValueAt(row, 0)).intValue();

        int confirm = JOptionPane.showConfirmDialog(dialog,
                "PERMANENTLY delete Transaction #" + id + "?\n"
                + "This cannot be undone.",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.ERROR_MESSAGE);

        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = ConnectDb.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps1 = conn.prepareStatement(
                        "DELETE FROM transaction_details WHERE transaction_id = ?");
                 PreparedStatement ps2 = conn.prepareStatement(
                        "DELETE FROM transactions WHERE transaction_id = ? AND is_archived = 1")) {

                ps1.setInt(1, id);
                ps1.executeUpdate();
                ps2.setInt(1, id);
                ps2.executeUpdate();
                conn.commit();

            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
            loadVault(vaultModel);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog,
                    "Error deleting:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnClose.addActionListener(e -> dialog.dispose());

    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
    buttons.add(btnRestore);
    buttons.add(btnDelete);
    buttons.add(btnClose);

    dialog.setLayout(new BorderLayout());
    dialog.add(new JScrollPane(vaultTable), BorderLayout.CENTER);
    dialog.add(buttons, BorderLayout.SOUTH);
    dialog.setPreferredSize(new Dimension(750, 420));
    dialog.pack();
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);
}



private void loadVault(DefaultTableModel vaultModel) {

    vaultModel.setRowCount(0);

    String sql = "SELECT transaction_id, transaction_date, payment_method, "
               + "final_amount, archived_at "
               + "FROM transactions WHERE is_archived = 1 "
               + "ORDER BY archived_at DESC";

    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm a");

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Timestamp date = rs.getTimestamp("transaction_date");
            Timestamp arch = rs.getTimestamp("archived_at");

            vaultModel.addRow(new Object[]{
                rs.getInt("transaction_id"),
                date == null ? "" : fmt.format(date),
                rs.getString("payment_method"),
                formatPeso(rs.getDouble("final_amount")),
                arch == null ? "" : fmt.format(arch)
            });
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Error loading vault:\n" + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}

public void refreshSummary() {

    loadSalesSummary();
}

    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSales = new javax.swing.JTable();
        btnArchive = new javax.swing.JButton();
        btnVault = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnView = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();

        setLayout(new java.awt.GridBagLayout());

        jPanel1.setBackground(new java.awt.Color(245, 247, 250));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Gross Daily Sale");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 255));
        jLabel3.setText("₱20,000,000");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addContainerGap(183, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jLabel2))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Transaction Count");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 204, 0));
        jLabel5.setText("13");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addContainerGap(193, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Average Transaction Value");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 153, 0));
        jLabel7.setText("₱20,000,000");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel7)))
                .addContainerGap(176, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        tblSales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Tx ID", "Time", "Cashier", "Payment", "Items", "VAT", "Total Amount"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblSales.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblSales.setFillsViewportHeight(true);
        tblSales.setPreferredSize(new java.awt.Dimension(2000, 2000));
        jScrollPane1.setViewportView(tblSales);

        btnArchive.setText("Archive");
        btnArchive.addActionListener(this::btnArchiveActionPerformed);

        btnVault.setText("Archive Vault");
        btnVault.addActionListener(this::btnVaultActionPerformed);

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(this::btnRefreshActionPerformed);

        btnView.setText("View Details");
        btnView.addActionListener(this::btnViewActionPerformed);

        jDateChooser1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnView)
                        .addGap(18, 18, 18)
                        .addComponent(btnRefresh)
                        .addGap(18, 18, 18)
                        .addComponent(btnArchive)
                        .addGap(18, 18, 18)
                        .addComponent(btnVault))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1237, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnVault, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnArchive)
                        .addComponent(btnRefresh)
                        .addComponent(btnView))
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(115, 115, 115)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(132, Short.MAX_VALUE))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 30;
        gridBagConstraints.ipady = 126;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(6, 0, 6, 6);
        add(jPanel1, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
    showTransactionDetails();
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
    loadSalesSummary();
        // TODO add your handling code here:
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchiveActionPerformed
    archiveSelectedTransaction();
    }//GEN-LAST:event_btnArchiveActionPerformed

    private void btnVaultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVaultActionPerformed
    openArchiveVault();
    }//GEN-LAST:event_btnVaultActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnArchive;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnVault;
    private javax.swing.JButton btnView;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblSales;
    // End of variables declaration//GEN-END:variables
}