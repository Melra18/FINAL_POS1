
package com.pos.ui.panel;

import com.pos.config.ConnectDb;
import com.pos.model.Product;
import com.pos.model.ProductSorter;
import com.pos.ui.Dashboard;
import com.pos.ui.UiUtil;
import com.pos.ui.WrapLayout;
import javax.swing.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import javax.imageio.ImageIO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SalesPanel extends JPanel {

    private static final String[] SORT_OPTIONS = {
        "Default",
        "Price: Low to High",
        "Price: High to Low",
        "Name: A-Z",
        "Stock: Low to High"
    };

    private static final int CARD_W = 220;
    private static final int CARD_H = 310;

    private static final Color SUCCESS_GREEN = new Color(40, 167, 69);
    private static final Color DISABLED_GRAY = new Color(210, 210, 210);

    private Dashboard parentDashboard;
    private ProductPanel filterPanel;
    private JComboBox<String> cbSort;

    private final List<Product> allProducts = new ArrayList<>();

    private int lastCategoryId = 0;
    private String lastSearch = "";

    public SalesPanel(Dashboard parentDashboard) {
        initComponents();
        this.parentDashboard = parentDashboard;

        pnlProductList = new ScrollablePanel();
        pnlProductList.setBackground(Color.WHITE);
        pnlProductList.setLayout(
            new WrapLayout(WrapLayout.CENTER, 14, 14)
        );

        jScrollPane1.setViewportView(pnlProductList);
        jScrollPane1.setHorizontalScrollBarPolicy(
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER
        );
        jScrollPane1.setVerticalScrollBarPolicy(
            ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED
        );
        jScrollPane1.setBorder(BorderFactory.createEmptyBorder());
        jScrollPane1.setBackground(Color.WHITE);
        jScrollPane1.getViewport().setBackground(Color.WHITE);

        styleProductScrollBar();

        filterPanel = new ProductPanel();
        filterPanel.setFilterListener((categoryId, searchText) -> {
            lastCategoryId = categoryId;
            lastSearch = searchText == null ? "" : searchText;
            applyFilters();
        });

        cbSort = new JComboBox<>(SORT_OPTIONS);
        cbSort.setPreferredSize(new Dimension(150, 28));
        cbSort.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cbSort.setBackground(Color.WHITE);
        cbSort.addActionListener(e -> applyFilters());

        JLabel lblSort = new JLabel("Sort:");
        lblSort.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblSort.setForeground(new Color(45, 55, 72));

        JPanel sortPanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 8, 8)
        );
        sortPanel.setBackground(Color.WHITE);
        sortPanel.add(lblSort);
        sortPanel.add(cbSort);

        filterPanel.setMaximumSize(filterPanel.getPreferredSize());
        sortPanel.setMaximumSize(sortPanel.getPreferredSize());

        pnlFilterHost.removeAll();
        pnlFilterHost.setLayout(
            new BoxLayout(pnlFilterHost, BoxLayout.X_AXIS)
        );
        pnlFilterHost.add(Box.createHorizontalGlue());
        pnlFilterHost.add(filterPanel);
        pnlFilterHost.add(sortPanel);

        pnlFilterHost.revalidate();
        pnlFilterHost.repaint();

        loadFromDatabase();
        applyFilters();
    }

    private void addFormRow(
            JPanel form,
            GridBagConstraints gbc,
            int row,
            String labelText,
            JComponent input) {

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 10));
        label.setForeground(new Color(107, 114, 128));

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.insets = new Insets(7, 0, 7, 12);
        form.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.insets = new Insets(7, 0, 7, 0);
        form.add(input, gbc);
    }

    private void styleDialogButton(
            JButton button,
            Color background,
            Color foreground) {

        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(background);
        button.setForeground(foreground);

        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI());

        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(
            BorderFactory.createEmptyBorder(9, 16, 9, 16)
        );

        if (background.equals(SUCCESS_GREEN)) {
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    if (button.isEnabled()) {
                        button.setBackground(new Color(33, 136, 56));
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    button.setBackground(background);
                }
            });
        }
    }

    // =========================================================
    // CUSTOM SCROLLBAR
    // =========================================================

    private void styleProductScrollBar() {
        JScrollBar bar = jScrollPane1.getVerticalScrollBar();

        bar.setPreferredSize(new Dimension(10, 0));
        bar.setUnitIncrement(20);
        bar.setBlockIncrement(80);
        bar.setBackground(new Color(245, 247, 250));
        bar.setBorder(null);
        bar.setOpaque(true);

        bar.setUI(new BasicScrollBarUI() {

            @Override
            protected void configureScrollBarColors() {
                thumbColor = new Color(180, 190, 203);
                trackColor = new Color(245, 247, 250);
            }

            private JButton createHiddenButton() {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(0, 0));
                button.setMinimumSize(new Dimension(0, 0));
                button.setMaximumSize(new Dimension(0, 0));
                button.setVisible(false);
                return button;
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createHiddenButton();
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createHiddenButton();
            }

            @Override
            protected void paintTrack(
                    Graphics g,
                    JComponent component,
                    Rectangle bounds) {

                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(245, 247, 250));
                g2.fillRect(
                    bounds.x,
                    bounds.y,
                    bounds.width,
                    bounds.height
                );
                g2.dispose();
            }

            @Override
            protected void paintThumb(
                    Graphics g,
                    JComponent component,
                    Rectangle bounds) {

                if (bounds.isEmpty() || !scrollbar.isEnabled()) {
                    return;
                }

                Graphics2D g2 = (Graphics2D) g.create();

                g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                );

                g2.setColor(
                    isDragging
                        ? new Color(100, 116, 139)
                        : isThumbRollover()
                            ? new Color(148, 163, 184)
                            : new Color(180, 190, 203)
                );

                g2.fillRoundRect(
                    bounds.x + 2,
                    bounds.y + 2,
                    Math.max(1, bounds.width - 4),
                    Math.max(1, bounds.height - 4),
                    8,
                    8
                );

                g2.dispose();
            }
        });
    }

    public void refreshProducts() {
        loadFromDatabase();

        if (filterPanel != null) {
            filterPanel.reloadCategories();
        }

        applyFilters();
    }

    // =========================================================
    // LOAD PRODUCTS
    // =========================================================

    private void loadFromDatabase() {
        allProducts.clear();

        String sql =
            "SELECT p.product_id, p.product_name, "
          + "p.price_per_piece, p.price_per_bulk, "
          + "p.pieces_per_bulk, p.category_id, "
          + "p.supplier_id, p.image_path, "
          + "COALESCE(("
          + " SELECT SUM(b.remaining_pieces) "
          + " FROM inventory_batches b "
          + " WHERE b.product_id = p.product_id "
          + " AND b.remaining_pieces > 0 "
          + " AND b.status = 'Available'"
          + "), 0) AS stock_quantity "
          + "FROM products p "
          + "WHERE p.status = 'Active'";

        try (Connection conn = ConnectDb.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Product product = new Product(
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getDouble("price_per_piece"),
                    rs.getInt("stock_quantity"),
                    rs.getInt("category_id"),
                    rs.getInt("supplier_id"),
                    rs.getString("image_path")
                );

                product.setPiecesPerBulk(
                    rs.getInt("pieces_per_bulk")
                );

                product.setPricePerBulk(
                    rs.getDouble("price_per_bulk")
                );

                allProducts.add(product);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                this,
                "Error loading products: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void checkNearExpiryWarning() {
        String sql =
            "SELECT p.product_name, b.expiration_date, "
          + "b.remaining_pieces "
          + "FROM inventory_batches b "
          + "JOIN products p ON b.product_id = p.product_id "
          + "WHERE b.status = 'Available' "
          + "AND b.remaining_pieces > 0 "
          + "AND b.expiration_date BETWEEN CURDATE() "
          + "AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";

        try (Connection conn = ConnectDb.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            StringBuilder warningList = new StringBuilder();
            boolean hasNearExpiry = false;

            while (rs.next()) {
                hasNearExpiry = true;

                warningList.append("• ")
                    .append(rs.getString("product_name"))
                    .append(" (")
                    .append(rs.getInt("remaining_pieces"))
                    .append(" pcs)")
                    .append(" - Expiration: ")
                    .append(rs.getString("expiration_date"))
                    .append("\n");
            }

            if (hasNearExpiry) {
                JOptionPane.showMessageDialog(
                    this,
                    "WARNING: The following products are nearing "
                    + "their expiration dates within the next 30 days:\n\n"
                    + warningList,
                    "Near Expiration Alert",
                    JOptionPane.WARNING_MESSAGE
                );
            }

        } catch (SQLException e) {
            System.out.println(
                "Error checking expiration: " + e.getMessage()
            );
        }
    }

    // =========================================================
    // FILTER AND SORT
    // =========================================================

    private void applyFilters() {
        if (pnlProductList == null || cbSort == null) {
            return;
        }

        List<Product> view = new ArrayList<>();
        String keyword = lastSearch.trim().toLowerCase();

        for (Product product : allProducts) {
            boolean categoryOk =
                lastCategoryId == 0
                || product.getCategoryId() == lastCategoryId;

            boolean nameOk =
                keyword.isEmpty()
                || product.getProductName()
                    .toLowerCase()
                    .contains(keyword);

            if (categoryOk && nameOk) {
                view.add(product);
            }
        }

        sortView(view);

        pnlProductList.removeAll();

        for (Product product : view) {
            pnlProductList.add(createProductCard(product));
        }

        pnlProductList.revalidate();
        pnlProductList.repaint();
    }

    private void sortView(List<Product> view) {
        if (cbSort == null) {
            return;
        }

        switch (cbSort.getSelectedIndex()) {
            case 1:
                ProductSorter.insertionSort(
                    view,
                    Comparator.comparingDouble(Product::getUnitPrice)
                );
                break;

            case 2:
                ProductSorter.insertionSort(
                    view,
                    Comparator.comparingDouble(Product::getUnitPrice)
                        .reversed()
                );
                break;

            case 3:
                ProductSorter.insertionSort(
                    view,
                    (a, b) -> a.getProductName()
                        .compareToIgnoreCase(b.getProductName())
                );
                break;

            case 4:
                ProductSorter.insertionSort(
                    view,
                    Comparator.comparingInt(Product::getStockQuantity)
                );
                break;

            default:
                break;
        }
    }

    private static class ScrollablePanel
            extends JPanel implements Scrollable {

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(
                Rectangle visibleRect,
                int orientation,
                int direction) {
            return 20;
        }

        @Override
        public int getScrollableBlockIncrement(
                Rectangle visibleRect,
                int orientation,
                int direction) {
            return 80;
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }
    }

    // =========================================================
    // PRODUCT CARD
    // =========================================================

    private JPanel createProductCard(Product product) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);

        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(225, 229, 235), 1
            ),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));

        card.setPreferredSize(new Dimension(CARD_W, CARD_H));
        card.setMinimumSize(new Dimension(CARD_W, CARD_H));
        card.setMaximumSize(new Dimension(CARD_W, CARD_H));

        JLabel imageLabel = new JLabel();
        imageLabel.setOpaque(true);
        imageLabel.setBackground(new Color(248, 249, 251));
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        imageLabel.setVerticalAlignment(SwingConstants.CENTER);
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        imageLabel.setPreferredSize(new Dimension(202, 130));
        imageLabel.setMinimumSize(new Dimension(202, 130));
        imageLabel.setMaximumSize(new Dimension(202, 130));

        setProductImage(imageLabel, product.getImagePath());

        JTextPane nameLabel = UiUtil.wrappedText(
            product.getProductName(),
            new Font("Segoe UI", Font.BOLD, 14),
            new Color(35, 35, 35),
            202,
            42,
            true
        );

        DecimalFormat df = new DecimalFormat("#,##0.00");

        JLabel pieceLabel = new JLabel(
            "Piece  •  ₱" + df.format(product.getPricePerPiece()),
            SwingConstants.CENTER
        );
        pieceLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        pieceLabel.setForeground(new Color(0, 102, 204));
        pieceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        String bulkText = product.hasBulkPricing()
            ? "Bulk (" + product.getPiecesPerBulk()
                + " pcs)  •  ₱"
                + df.format(product.getPricePerBulk())
            : "Bulk  •  Not set";

        JLabel bulkLabel = new JLabel(
            bulkText,
            SwingConstants.CENTER
        );
        bulkLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        bulkLabel.setForeground(
            product.hasBulkPricing()
                ? new Color(70, 70, 70)
                : new Color(145, 145, 145)
        );
        bulkLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel stockLabel = new JLabel(
            product.isInStock()
                ? product.getStockQuantity() + " pcs available"
                : "OUT OF STOCK",
            SwingConstants.CENTER
        );
        stockLabel.setFont(new Font("Segoe UI", Font.BOLD, 11));
        stockLabel.setForeground(
            product.isInStock()
                ? new Color(70, 120, 70)
                : new Color(190, 35, 35)
        );
        stockLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add to Order button: one styling block and one action listener
        JButton addButton = new JButton(
            product.isInStock() ? "ADD TO ORDER" : "OUT OF STOCK"
        );

        addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addButton.setEnabled(product.isInStock());

        if (product.isInStock()) {
            styleDialogButton(
                addButton,
                SUCCESS_GREEN,
                Color.WHITE
            );
            addButton.setFont(new Font("Segoe UI", Font.BOLD, 11));
        } else {
            styleDialogButton(
                addButton,
                DISABLED_GRAY,
                new Color(100, 100, 100)
            );
            addButton.setFont(new Font("Segoe UI", Font.BOLD, 11));
            addButton.setCursor(Cursor.getDefaultCursor());
        }

        addButton.addActionListener(
            e -> showAddToOrderDialog(product)
        );

        card.add(imageLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(nameLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(pieceLabel);
        card.add(Box.createVerticalStrut(2));
        card.add(bulkLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(stockLabel);
        card.add(Box.createVerticalGlue());
        card.add(addButton);

        if (product.isInStock()) {
            MouseAdapter hover = new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    card.setBorder(
                        BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(
                                new Color(0, 102, 204), 2
                            ),
                            BorderFactory.createEmptyBorder(7, 7, 7, 7)
                        )
                    );
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    card.setBorder(
                        BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(
                                new Color(225, 229, 235), 1
                            ),
                            BorderFactory.createEmptyBorder(8, 8, 8, 8)
                        )
                    );
                }
            };

            card.addMouseListener(hover);
            imageLabel.addMouseListener(hover);
            nameLabel.addMouseListener(hover);
            pieceLabel.addMouseListener(hover);
            bulkLabel.addMouseListener(hover);
            stockLabel.addMouseListener(hover);
        }

        return card;
    }

    // =========================================================
    // PRODUCT IMAGE
    // =========================================================

    private void setProductImage(JLabel label, String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) {
            setImagePlaceholder(label);
            return;
        }

        try {
            Image image = null;
            File file = new File(imagePath);

            if (file.exists()) {
                image = ImageIO.read(file);
            } else {
                URL url = getClass().getResource(
                    imagePath.startsWith("/")
                        ? imagePath
                        : "/" + imagePath
                );

                if (url != null) {
                    image = ImageIO.read(url);
                }
            }

            if (image == null) {
                setImagePlaceholder(label);
                return;
            }

            int boxW = 202;
            int boxH = 130;
            int imageW = image.getWidth(null);
            int imageH = image.getHeight(null);

            if (imageW <= 0 || imageH <= 0) {
                setImagePlaceholder(label);
                return;
            }

            double scale = Math.max(
                (double) boxW / imageW,
                (double) boxH / imageH
            );

            int scaledW = Math.max(
                1,
                (int) Math.round(imageW * scale)
            );

            int scaledH = Math.max(
                1,
                (int) Math.round(imageH * scale)
            );

            BufferedImage canvas = new BufferedImage(
                boxW,
                boxH,
                BufferedImage.TYPE_INT_ARGB
            );

            Graphics2D g2 = canvas.createGraphics();

            g2.setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC
            );

            g2.setRenderingHint(
                RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY
            );

            g2.setColor(new Color(248, 249, 251));
            g2.fillRect(0, 0, boxW, boxH);

            g2.drawImage(
                image,
                (boxW - scaledW) / 2,
                (boxH - scaledH) / 2,
                scaledW,
                scaledH,
                null
            );

            g2.dispose();

            label.setIcon(new ImageIcon(canvas));
            label.setText("");

        } catch (Exception ex) {
            System.err.println(
                "Could not load product image: " + ex.getMessage()
            );
            setImagePlaceholder(label);
        }
    }

    private void setImagePlaceholder(JLabel label) {
        label.setIcon(null);
        label.setText("NO IMAGE");
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(150, 150, 150));
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;");
    }

    // =========================================================
    // ADD TO ORDER DIALOG
    // =========================================================

    private void showAddToOrderDialog(Product product) {
        if (product == null || !product.isInStock()) {
            JOptionPane.showMessageDialog(
                this,
                "This product is currently out of stock.",
                "Out of Stock",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        final Color darkText = new Color(31, 41, 55);
        final Color mutedText = new Color(107, 114, 128);
        final Color borderColor = new Color(226, 232, 240);
        final Color background = Color.WHITE;

        int stockPieces = product.getStockQuantity();
        int piecesPerBulk = Math.max(1, product.getPiecesPerBulk());

        boolean canBuyBulk =
            product.hasBulkPricing()
            && product.getPiecesPerBulk() > 0
            && stockPieces >= piecesPerBulk;

        JPanel panel = new JPanel(new BorderLayout(0, 18));
        panel.setBackground(background);
        panel.setBorder(
            BorderFactory.createEmptyBorder(20, 22, 18, 22)
        );
        panel.setPreferredSize(new Dimension(520, 440));

        // Product header
        JPanel header = new JPanel();
        header.setBackground(background);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

        JLabel eyebrow = new JLabel("PRODUCT DETAILS");
        eyebrow.setFont(new Font("Segoe UI", Font.BOLD, 10));
        eyebrow.setForeground(mutedText);
        eyebrow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel(
            "<html><div style='width:370px'>"
            + escapeHtml(product.getProductName())
            + "</div></html>"
        );
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(darkText);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel priceInfo = new JLabel(
            String.format(
                java.util.Locale.US,
                "Piece price: ₱%,.2f",
                product.getPricePerPiece()
            )
        );
        priceInfo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        priceInfo.setForeground(mutedText);
        priceInfo.setAlignmentX(Component.LEFT_ALIGNMENT);

        header.add(eyebrow);
        header.add(Box.createVerticalStrut(5));
        header.add(title);
        header.add(Box.createVerticalStrut(7));
        header.add(priceInfo);

        panel.add(header, BorderLayout.NORTH);

        // Input form
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(background);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 0, 7, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        JComboBox<String> unitBox = new JComboBox<>();
        unitBox.addItem("Piece");

        if (canBuyBulk) {
            unitBox.addItem(
                "Bulk (" + piecesPerBulk + " pieces)"
            );
        }

        unitBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        unitBox.setBackground(Color.WHITE);
        unitBox.setPreferredSize(new Dimension(330, 42));
        unitBox.setBorder(
            BorderFactory.createLineBorder(borderColor)
        );

        int initialMax = Math.max(1, stockPieces);

        JSpinner quantitySpinner = new JSpinner(
            new SpinnerNumberModel(1, 1, initialMax, 1)
        );
        quantitySpinner.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        quantitySpinner.setPreferredSize(new Dimension(260, 36));

        JSpinner.NumberEditor editor =
            new JSpinner.NumberEditor(quantitySpinner, "#");

        quantitySpinner.setEditor(editor);

        JFormattedTextField quantityField = editor.getTextField();
        quantityField.setHorizontalAlignment(JTextField.LEFT);
        quantityField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        quantityField.setBorder(
            BorderFactory.createEmptyBorder(0, 10, 0, 5)
        );

        JLabel availableLabel = new JLabel();
        availableLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        availableLabel.setForeground(mutedText);

        JLabel unitPriceLabel = new JLabel();
        unitPriceLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        unitPriceLabel.setForeground(darkText);

        JLabel totalLabel = new JLabel();
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        totalLabel.setForeground(SUCCESS_GREEN);

        addFormRow(form, gbc, 0, "UNIT", unitBox);
        addFormRow(form, gbc, 1, "QUANTITY", quantitySpinner);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        form.add(availableLabel, gbc);

        gbc.gridy = 3;
        form.add(unitPriceLabel, gbc);

        gbc.gridy = 4;
        form.add(totalLabel, gbc);

        panel.add(form, BorderLayout.CENTER);

        // Price and stock update
        Runnable update = () -> {
            boolean bulk =
                canBuyBulk && unitBox.getSelectedIndex() == 1;

            int available = bulk
                ? stockPieces / piecesPerBulk
                : stockPieces;

            double unitPrice = bulk
                ? product.getPricePerBulk()
                : product.getPricePerPiece();

            SpinnerNumberModel model =
                (SpinnerNumberModel) quantitySpinner.getModel();

            int maximum = Math.max(1, available);
            model.setMaximum(maximum);

            int quantity =
                ((Number) model.getValue()).intValue();

            if (quantity > maximum) {
                model.setValue(maximum);
                quantity = maximum;
            }

            quantitySpinner.setEnabled(available > 0);

            availableLabel.setText(
                "Available stock: " + available
                + (bulk ? " bulk(s)" : " piece(s)")
            );

            availableLabel.setForeground(
                available > 0
                    ? new Color(22, 101, 52)
                    : new Color(185, 28, 28)
            );

            unitPriceLabel.setText(
                String.format(
                    java.util.Locale.US,
                    "Unit price: ₱%,.2f",
                    unitPrice
                )
            );

            totalLabel.setText(
                String.format(
                    java.util.Locale.US,
                    "Line total: ₱%,.2f",
                    unitPrice * quantity
                )
            );
        };

        unitBox.addActionListener(e -> update.run());
        quantitySpinner.addChangeListener(e -> update.run());
        update.run();

        // Dialog buttons
        JButton addButton = new JButton("Add to Cart");
        styleDialogButton(
            addButton,
            SUCCESS_GREEN,
            Color.WHITE
        );

        JButton cancelButton = new JButton("Cancel");
        styleDialogButton(
            cancelButton,
            new Color(243, 244, 246),
            darkText
        );

        cancelButton.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderColor),
                BorderFactory.createEmptyBorder(8, 15, 8, 15)
            )
        );

        JPanel buttons = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 8, 0)
        );
        buttons.setBackground(background);
        buttons.add(cancelButton);
        buttons.add(addButton);

        panel.add(buttons, BorderLayout.SOUTH);

        JDialog dialog = new JDialog(
            SwingUtilities.getWindowAncestor(this),
            "Add to Order",
            Dialog.ModalityType.APPLICATION_MODAL
        );

        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setContentPane(panel);
        dialog.getRootPane().setDefaultButton(addButton);
        dialog.pack();
        dialog.setResizable(false);
        dialog.setLocationRelativeTo(parentDashboard);

        addButton.addActionListener(e -> {
            try {
                quantitySpinner.commitEdit();
            } catch (java.text.ParseException ex) {
                JOptionPane.showMessageDialog(
                    dialog,
                    "Please enter a valid quantity.",
                    "Invalid Quantity",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            boolean bulk =
                canBuyBulk && unitBox.getSelectedIndex() == 1;

            int quantity =
                ((Number) quantitySpinner.getValue()).intValue();

            int available = bulk
                ? stockPieces / piecesPerBulk
                : stockPieces;

            if (quantity < 1 || quantity > available) {
                JOptionPane.showMessageDialog(
                    dialog,
                    "The requested quantity exceeds available stock.",
                    "Insufficient Stock",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (parentDashboard == null) {
                JOptionPane.showMessageDialog(
                    dialog,
                    "The dashboard connection is unavailable.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            parentDashboard.addProductToCart(
                product,
                bulk ? "Bulk" : "Piece",
                quantity
            );

            dialog.dispose();
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    // =========================================================
    // INITIALIZE PANEL
    // =========================================================

    private void initComponents() {
        pnlHeader = new JPanel();
        lblProducts = new JLabel();
        pnlFilterHost = new JPanel();
        jScrollPane1 = new JScrollPane();
        pnlProductList = new JPanel();

        setBackground(Color.WHITE);

        pnlHeader.setBackground(Color.WHITE);
        pnlHeader.setLayout(new BorderLayout());

        lblProducts.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblProducts.setForeground(new Color(35, 35, 35));
        lblProducts.setText("Products");
        lblProducts.setBorder(
            BorderFactory.createEmptyBorder(8, 14, 8, 10)
        );

        pnlHeader.add(lblProducts, BorderLayout.WEST);

        pnlFilterHost.setBackground(Color.WHITE);
        pnlFilterHost.setLayout(
            new FlowLayout(FlowLayout.RIGHT, 10, 8)
        );

        pnlHeader.add(pnlFilterHost, BorderLayout.CENTER);

        jScrollPane1.setBackground(Color.WHITE);
        jScrollPane1.setBorder(BorderFactory.createEmptyBorder());

        pnlProductList.setBackground(Color.WHITE);
        pnlProductList.setAutoscrolls(true);

        jScrollPane1.setViewportView(pnlProductList);

        setLayout(new BorderLayout());
        add(pnlHeader, BorderLayout.NORTH);
        add(jScrollPane1, BorderLayout.CENTER);
    }

    // =========================================================
    // VARIABLES
    // =========================================================

    private JScrollPane jScrollPane1;
    private JLabel lblProducts;
    private JPanel pnlFilterHost;
    private JPanel pnlHeader;
    private JPanel pnlProductList;
}
