/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.pos.ui.panel;
import javax.swing.JOptionPane;
import com.pos.config.ConnectDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;   
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.NumberFormat;
import java.util.Locale;


public class ReadReport extends javax.swing.JDialog {
private final int finalizedByUserId;
private LocalDate businessDate;
private int transactionCount = 0; 
private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ReadReport.class.getName());
private double expectedCash = 0.0;
private double actualCash = 0.0;
private double overShort = 0.0;
private double grossSales = 0.0;
private double totalDiscounts = 0.0;
private double vatAmount = 0.0;
private double netSales = 0.0;
    
   public ReadReport(java.awt.Frame parent, boolean modal, int userId) {
    super(parent, modal);

    this.finalizedByUserId = userId;

    initComponents();
    // Reuse existing styling helpers
DateChooserStyler.style(dateChooserBusinessDate);

TextFieldStyler.styleAll(txtActualCash);


 
    
    jButton3.setEnabled(false);

    txtActualCash.setText("");
    txtActualCash.addActionListener(e -> calculateOverShort());

    setLocationRelativeTo(parent);
    dateChooserBusinessDate.setDate(new java.util.Date());

dateChooserBusinessDate.addPropertyChangeListener("date", event -> {
    txtActualCash.setText("");
    loadZReadData();
});

loadZReadData();

}
private void loadZReadData() {
       java.util.Date selectedDate = dateChooserBusinessDate.getDate();

    if (selectedDate == null) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a business date first.",
            "Date Required",
            JOptionPane.WARNING_MESSAGE
        );
        jButton3.setEnabled(false);
        return;
    }

    businessDate = selectedDate.toInstant()
            .atZone(java.time.ZoneId.systemDefault())
            .toLocalDate();

    String sql =
        "SELECT COUNT(*) AS transaction_count, " +
        "COALESCE(SUM(subtotal_amount), 0) AS gross_sales, " +
        "COALESCE(SUM(discount_amount), 0) AS total_discounts, " +
        "COALESCE(SUM(final_amount), 0) AS net_sales, " +
        "COALESCE(SUM(CASE " +
        "WHEN LOWER(TRIM(payment_method)) = 'cash' " +
        "THEN final_amount ELSE 0 END), 0) AS expected_cash " +
        "FROM transactions " +
        "WHERE DATE(transaction_date) = ? " +
        "AND is_archived = 0";

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setDate(1, java.sql.Date.valueOf(businessDate));

        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next()) {
                transactionCount = rs.getInt("transaction_count");
                grossSales = rs.getDouble("gross_sales");
                totalDiscounts = rs.getDouble("total_discounts");
                netSales = rs.getDouble("net_sales");
                vatAmount = netSales * 12.0 / 112.0;
                expectedCash = rs.getDouble("expected_cash");

                lblTransactionCount.setText(
                    String.valueOf(transactionCount)
                );
                lblTransactionCount2.setText(formatPeso(grossSales));
                lblTransactionCount1.setText(formatPeso(totalDiscounts));
                lblTransactionCount4.setText(formatPeso(vatAmount));
                lblTransactionCount5.setText(formatPeso(netSales));
                lblTransactionCount3.setText(formatPeso(expectedCash));

                jLabel4.setText(
                    "Business Date: " + businessDate
                );

                calculateOverShort();
                checkExistingZRead();
            }
        }

    } catch (SQLException e) {
        jButton3.setEnabled(false);

        JOptionPane.showMessageDialog(
            this,
            "Unable to load Z-Read data:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );

        e.printStackTrace();
    }
}


private void checkExistingZRead() {
      if (businessDate == null) {
        jButton3.setEnabled(false);
        return;
    }

    String sql = "SELECT z_read_id FROM z_read_reports "
               + "WHERE business_date = ?";

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setDate(1, java.sql.Date.valueOf(businessDate));

        try (ResultSet rs = pst.executeQuery()) {
            boolean alreadyFinalized = rs.next();

            if (alreadyFinalized) {
                jButton3.setEnabled(false);
                jLabel4.setText(
                    "Business Date: " + businessDate
                    + " (Already Finalized)"
                );
            } else {
                jButton3.setEnabled(transactionCount > 0);
                jLabel4.setText(
                    "Business Date: " + businessDate
                );
            }

            System.out.println("=== Z-READ STATUS ===");
            System.out.println("Selected date: " + businessDate);
            System.out.println("Transactions: " + transactionCount);
            System.out.println("Already finalized: " + alreadyFinalized);
            System.out.println("Finalize enabled: " + jButton3.isEnabled());
            System.out.println("=====================");
        }

    } catch (SQLException e) {
        jButton3.setEnabled(false);
        JOptionPane.showMessageDialog(
            this,
            "Unable to verify the Z-Read status:\n" + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
        e.printStackTrace();
    }
}



    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dateChooserBusinessDate = new com.toedter.calendar.JDateChooser();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel12 = new javax.swing.JLabel();
        lblTransactionCount = new javax.swing.JLabel();
        lblTransactionCount1 = new javax.swing.JLabel();
        lblTransactionCount2 = new javax.swing.JLabel();
        lblTransactionCount4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        lblTransactionCount5 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblTransactionCount3 = new javax.swing.JLabel();
        lblTransactionCount6 = new javax.swing.JLabel();
        txtActualCash = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(678, 740));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(249, 249, 249));

        jPanel2.setBackground(new java.awt.Color(27, 31, 92));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Z-READ REPORT");

        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("POS AND INVENTORY SYSTEM");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Business Date");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap(492, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dateChooserBusinessDate, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(dateChooserBusinessDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(40, 40, 40))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Sales Summary");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setText("Gross Sales");

        jLabel6.setText("Discounts");

        jLabel7.setText("VAT Included");

        jLabel12.setText("Transactions");

        lblTransactionCount.setText("0");

        lblTransactionCount1.setText("₱000,000,000,000");

        lblTransactionCount2.setText("₱000,000,000,000");

        lblTransactionCount4.setText("₱000,000,000,000");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTransactionCount, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTransactionCount2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTransactionCount4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTransactionCount1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(lblTransactionCount))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel12)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(lblTransactionCount2))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(lblTransactionCount1))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(lblTransactionCount4))
                .addGap(14, 14, 14)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(111, 194, 118));

        jLabel8.setText("Net Sales");

        lblTransactionCount5.setForeground(new java.awt.Color(0, 102, 0));
        lblTransactionCount5.setText("₱000,000,000,000");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTransactionCount5, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lblTransactionCount5))
                .addGap(15, 15, 15))
        );

        jPanel5.setBackground(new java.awt.Color(255, 165, 0));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Cash Reconciliation");

        jLabel10.setText("Actual Cash Counted");

        jLabel11.setText("Over / Short");

        lblTransactionCount3.setForeground(new java.awt.Color(0, 51, 255));
        lblTransactionCount3.setText("₱000,000,000,000");

        lblTransactionCount6.setText("₱000,000,000,000");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblTransactionCount3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTransactionCount6, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtActualCash, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(lblTransactionCount3))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtActualCash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(lblTransactionCount6))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setText("Refresh");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(153, 153, 153));
        jButton2.setText("Export PDF");

        jButton3.setBackground(new java.awt.Color(0, 140, 0));
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Finalize Z-Read ");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton4.setBackground(new java.awt.Color(0, 0, 255));
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Print");
        jButton4.addActionListener(this::jButton4ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   private String formatPeso(double amount) {
    return NumberFormat.getCurrencyInstance(
            Locale.forLanguageTag("en-PH")
    ).format(amount);
}
    
    
private void calculateOverShort() {
    String cashText = txtActualCash.getText().trim();

    if (cashText.isEmpty()) {
        lblTransactionCount6.setText("₱0.00");
        actualCash = 0.0;
        overShort = 0.0;
        return;
    }

    try {
        actualCash = Double.parseDouble(
            cashText.replace(",", "").replace("₱", "").trim()
        );

        if (!Double.isFinite(actualCash) || actualCash < 0) {
            JOptionPane.showMessageDialog(
                this,
                "Enter a valid, non-negative cash amount.",
                "Invalid Amount",
                JOptionPane.WARNING_MESSAGE
            );
            txtActualCash.requestFocus();
            return;
        }

        overShort = actualCash - expectedCash;

        lblTransactionCount6.setText(
            String.format("₱%,.2f", overShort)
        );

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
            this,
            "Please enter a valid cash amount.",
            "Invalid Input",
            JOptionPane.WARNING_MESSAGE
        );
        txtActualCash.requestFocus();
    }
}

    
    
    
    
    
    
    
    
  
    
    
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
   
     txtActualCash.setText("");

    loadZReadData();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
 if (businessDate == null || transactionCount == 0) {
        JOptionPane.showMessageDialog(
                this,
                "There are no sales to finalize.",
                "Cannot Finalize",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    // Validate actual cash before saving.
    String cashText = txtActualCash.getText().trim();

    if (cashText.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Please enter the actual cash counted first.",
                "Cash Required",
                JOptionPane.WARNING_MESSAGE
        );
        txtActualCash.requestFocus();
        return;
    }

    try {
       String cleanCash = cashText
        .replace(",", "")
        .replace("₱", "")
        .trim();

System.out.println("Cash text entered: [" + cashText + "]");
System.out.println("Cash text cleaned: [" + cleanCash + "]");

actualCash = Double.parseDouble(cleanCash);

if (!Double.isFinite(actualCash) || actualCash < 0) {
    throw new NumberFormatException();
}
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
                this,
                "Enter a valid, non-negative cash amount.",
                "Invalid Cash Amount",
                JOptionPane.WARNING_MESSAGE
        );
        txtActualCash.requestFocus();
        return;
    }

    overShort = actualCash - expectedCash;

    int choice = JOptionPane.showConfirmDialog(
            this,
            "Business Date: " + businessDate
            + "\nTransactions: " + transactionCount
            + "\nNet Sales: " + formatPeso(netSales)
            + "\nExpected Cash: " + formatPeso(expectedCash)
            + "\nActual Cash: " + formatPeso(actualCash)
            + "\nOver / Short: " + formatPeso(overShort)
            + "\n\nFinalize this Z-Read? This action cannot be undone.",
            "Confirm Z-Read Finalization",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (choice != JOptionPane.YES_OPTION) {
        return;
    }

    String sql = "INSERT INTO z_read_reports "
            + "(business_date, finalized_by, transaction_count, "
            + "gross_sales, total_discounts, vat_amount, net_sales, "
            + "expected_cash, actual_cash, over_short) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try {
        Connection conn = ConnectDb.getConnection();

        if (conn == null) {
            throw new SQLException("Database connection is unavailable.");
        }

        try (Connection connection = conn;
             PreparedStatement pst = connection.prepareStatement(sql)) {

          overShort = actualCash - expectedCash;

    // Set all 10 SQL parameters.
    pst.setDate(1, java.sql.Date.valueOf(businessDate));
    pst.setInt(2, finalizedByUserId);
    pst.setInt(3, transactionCount);
    pst.setBigDecimal(4, java.math.BigDecimal.valueOf(grossSales));
    pst.setBigDecimal(5, java.math.BigDecimal.valueOf(totalDiscounts));
    pst.setBigDecimal(6, java.math.BigDecimal.valueOf(vatAmount));
    pst.setBigDecimal(7, java.math.BigDecimal.valueOf(netSales));
    pst.setBigDecimal(8, java.math.BigDecimal.valueOf(expectedCash));
    pst.setBigDecimal(9, java.math.BigDecimal.valueOf(actualCash));
    pst.setBigDecimal(10, java.math.BigDecimal.valueOf(overShort));

    // Debug information.
    System.out.println("=== Z-READ DEBUG ===");
    System.out.println("Database URL: " + connection.getMetaData().getURL());
    System.out.println("Database: " + connection.getCatalog());
    System.out.println("Business Date: " + businessDate);
    System.out.println("User ID: " + finalizedByUserId);
    System.out.println("Gross Sales: " + grossSales);
    System.out.println("Discounts: " + totalDiscounts);
    System.out.println("VAT: " + vatAmount);
    System.out.println("Net Sales: " + netSales);
    System.out.println("Expected Cash: " + expectedCash);
    System.out.println("Actual Cash: " + actualCash);
    System.out.println("Over/Short: " + overShort);
    System.out.println("====================");

         pst.executeUpdate();
        }
     
        JOptionPane.showMessageDialog(
                this,
                "Z-Read finalized and saved successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );

        jButton3.setEnabled(false);

    } catch (SQLException e) {
        if (e.getErrorCode() == 1062) {
            JOptionPane.showMessageDialog(
                    this,
        "This business date has already been finalized.\n"
        + "No new report was saved.\n\n"
        + "Business Date: " + businessDate
        + "\nPlease check the existing Z-Read record.",
        "Already Finalized",
                    JOptionPane.WARNING_MESSAGE
            );
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to finalize Z-Read:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            e.printStackTrace();
        }
    }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                ReadReport dialog = new ReadReport(
        new javax.swing.JFrame(),
        true,
        1
);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser dateChooserBusinessDate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblTransactionCount;
    private javax.swing.JLabel lblTransactionCount1;
    private javax.swing.JLabel lblTransactionCount2;
    private javax.swing.JLabel lblTransactionCount3;
    private javax.swing.JLabel lblTransactionCount4;
    private javax.swing.JLabel lblTransactionCount5;
    private javax.swing.JLabel lblTransactionCount6;
    private javax.swing.JTextField txtActualCash;
    // End of variables declaration//GEN-END:variables
}
