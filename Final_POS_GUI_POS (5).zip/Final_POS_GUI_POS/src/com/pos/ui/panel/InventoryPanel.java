/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.pos.ui.panel;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.sql.ResultSet;
import com.pos.config.ConnectDb;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import javax.swing.SwingUtilities;
import java.awt.FileDialog;
import java.awt.Frame;
import com.pos.service.SecurityLogService;
import com.pos.ui.dialog.AddStockDialog;
import com.pos.ui.Dashboard;
import com.pos.ui.dialog.ImageAdjustDialog;
import com.pos.model.Product;
import com.pos.model.ProductSorter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import com.pos.service.ProductSortStrategy;

public class InventoryPanel extends javax.swing.JPanel {
private String selectedImagePath = "";
private Dashboard parentDashboard;
private boolean editMode = false;
private int editingProductId = -1;
private final List<Product> allProducts = new ArrayList<>();


  
public InventoryPanel(Dashboard parentDashboard) {
        initComponents();
    this.parentDashboard = parentDashboard;

   // DATE CHOOSER STYLING
   DateChooserStyler.style(dateChooserExpiration);

   // Date format
   dateChooserExpiration.setDateFormatString("yyyy-MM-dd");
    
    
     // ==============================
    // TEXT FIELD STYLING
    // ==============================
    TextFieldStyler.styleAll(
        txtSearchProduct,
        txtProductName,
        txtBarcode,
        txtPiecePrice,
        txtBulkPrice,
        txtPcsPerBulk,
        txtStock1
    );

    // Text field placeholders
    TextFieldStyler.setPlaceholder(
        txtSearchProduct, "Search products...");
    TextFieldStyler.setPlaceholder(
        txtProductName, "Enter product name");
    TextFieldStyler.setPlaceholder(
        txtBarcode, "Enter barcode");
    TextFieldStyler.setPlaceholder(
        txtPiecePrice, "0.00");
    TextFieldStyler.setPlaceholder(
        txtBulkPrice, "0.00");
    TextFieldStyler.setPlaceholder(
        txtPcsPerBulk, "Pieces per bulk");
    TextFieldStyler.setPlaceholder(
        txtStock1, "Enter stock");

    // ==============================
    // COMBO BOX STYLING
    // ==============================
    ComboBoxStyler.style(cbCategory);
    ComboBoxStyler.style(cmbCategoryFilter);
    ComboBoxStyler.style(cmbSortBy);
    ComboBoxStyler.style(cmbSortOrder);

    // ==============================
    // BUTTON STYLING
    // ==============================
   java.awt.Color primary =
        new java.awt.Color(51, 105, 170);

java.awt.Color danger =
        new java.awt.Color(190, 55, 55);

java.awt.Color neutral =
        new java.awt.Color(90, 101, 117);

java.awt.Color dark =
        new java.awt.Color(55, 65, 81);

// Same green used throughout the POS
ButtonStyler.style(btnAddProduct,
        new java.awt.Color(40, 167, 69));

ButtonStyler.style(btnApplySort,
        new java.awt.Color(40, 167, 69));

// Blue buttons
ButtonStyler.style(btnEdit, primary);
ButtonStyler.style(btnEdit1, primary);
ButtonStyler.style(btnNewCategory, primary);

// Red buttons
ButtonStyler.style(btnDelete, danger);
ButtonStyler.style(btnNewCategory1, danger);

// Other buttons
ButtonStyler.style(btnProductArchiveVault, dark);
ButtonStyler.style(btnImage, neutral);
    // =========================
    // INVENTORY TABLE
    // =========================
    styleInventoryTable();

    // =========================
    // LOAD INVENTORY DATA
    // =========================
    loadCategories();
    loadCategoryFilter();
    loadProducts();

    // Expiration date format
    dateChooserExpiration.setDateFormatString("yyyy-MM-dd");

    
    tblProducts.setFillsViewportHeight(true);
    tblProducts.setBackground(java.awt.Color.WHITE);
    tblProducts.setForeground(java.awt.Color.BLACK);

    tblProducts.setSelectionBackground(new java.awt.Color(70, 120, 150));
    tblProducts.setSelectionForeground(java.awt.Color.WHITE);

    tblProducts.setGridColor(new java.awt.Color(210, 210, 210));
    tblProducts.setShowHorizontalLines(true);
    tblProducts.setShowVerticalLines(false);
    
    
    
    
    
    
    javax.swing.table.DefaultTableCellRenderer leftRenderer = new javax.swing.table.DefaultTableCellRenderer();
    leftRenderer.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
   
    
    tblProducts.getColumnModel().getColumn(0).setCellRenderer(leftRenderer); // Product ID
    tblProducts.getColumnModel().getColumn(3).setCellRenderer(leftRenderer); // Pcs/Bulk
    tblProducts.getColumnModel().getColumn(4).setCellRenderer(leftRenderer); // Price (Piece)
    tblProducts.getColumnModel().getColumn(5).setCellRenderer(leftRenderer); // Price (Bulk)
    tblProducts.getColumnModel().getColumn(6).setCellRenderer(leftRenderer); // Total Stock (Pieces)
    
    javax.swing.table.DefaultTableCellRenderer priceRenderer =
        new javax.swing.table.DefaultTableCellRenderer() {
            private final java.text.DecimalFormat df = new java.text.DecimalFormat("#,##0.00");
            @Override
            protected void setValue(Object value) {
                setText(value instanceof Number ? df.format(((Number) value).doubleValue()) : "");
            }
        };
    priceRenderer.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
    tblProducts.getColumnModel().getColumn(4).setCellRenderer(priceRenderer);
    tblProducts.getColumnModel().getColumn(5).setCellRenderer(priceRenderer);
    
       
         
         dateChooserExpiration.setDateFormatString("yyyy-MM-dd");

    }

   private void loadCategories() {
    cbCategory.removeAllItems();
    String sql = "SELECT category_id, category_name FROM categories";

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            int id = rs.getInt("category_id");
            String name = rs.getString("category_name");
            cbCategory.addItem(new CategoryItem(id, name));
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading categories: " + e.getMessage());
    }
    
   }
    
    
    
public void loadProducts() {

   allProducts.clear();

    String sql =
        "SELECT " +
        "p.product_id, " +
        "p.product_name, " +
        "p.barcode, " +
        "c.category_name, " +
        "p.category_id, " +
        "p.supplier_id, " +
        "p.pieces_per_bulk, " +
        "p.price_per_piece, " +
        "p.price_per_bulk, " +

        "COALESCE(SUM(CASE " +
        "WHEN b.status = 'Available' " +
        "AND b.expiration_date >= CURRENT_DATE() " +
        "THEN b.remaining_pieces " +
        "ELSE 0 END), 0) AS total_stock, " +

        "MIN(CASE " +
        "WHEN b.status = 'Available' " +
        "AND b.remaining_pieces > 0 " +
        "AND b.expiration_date >= CURRENT_DATE() " +
        "THEN b.expiration_date " +
        "ELSE NULL END) AS earliest_expiration " +

        "FROM products p " +

        "LEFT JOIN categories c " +
        "ON p.category_id = c.category_id " +

        "LEFT JOIN inventory_batches b " +
        "ON p.product_id = b.product_id " +

        "WHERE p.status = 'Active' " +

        "GROUP BY " +
        "p.product_id, " +
        "p.product_name, " +
        "p.barcode, " +
        "c.category_name, " +
        "p.category_id, " +
        "p.supplier_id, " +
        "p.pieces_per_bulk, " +
        "p.price_per_piece, " +
        "p.price_per_bulk " +

        "ORDER BY p.product_id ASC";

    try (
        Connection conn = ConnectDb.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery()
    ) {

        while (rs.next()) {

            Product product = new Product();

            product.setProductId(
                rs.getInt("product_id")
            );

            product.setProductName(
                rs.getString("product_name")
            );
            product.setBarcode(
            rs.getString("barcode")
            );

            product.setCategoryId(
                rs.getInt("category_id")
            );

            product.setSupplierId(
                rs.getInt("supplier_id")
            );

            product.setPiecesPerBulk(
                rs.getInt("pieces_per_bulk")
            );

            product.setPricePerPiece(
                rs.getDouble("price_per_piece")
            );

            product.setPricePerBulk(
                rs.getDouble("price_per_bulk")
            );

            product.setCategoryName(
                rs.getString("category_name")
            );

            product.setTotalStock(
                rs.getInt("total_stock")
            );

            product.setEarliestExpiration(
                rs.getDate("earliest_expiration")
            );

            allProducts.add(product);
        }

        applyInventorySort();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading products: " + e.getMessage()
        );
    }
}
    private void refreshInventoryTable() {

    DefaultTableModel model =
        (DefaultTableModel) tblProducts.getModel();

    model.setRowCount(0);

    for (Product product : allProducts) {

        String expiration =
            product.getEarliestExpiration() == null
                ? "No Expiry"
                : product.getEarliestExpiration().toString();

        model.addRow(new Object[]{

            product.getProductId(),

            product.getProductName(),
            
            product.getBarcode(),

            product.getCategoryName(),

            product.getPiecesPerBulk(),

            product.getPricePerPiece(),

            product.getPricePerBulk(),

            product.getTotalStock(),

            expiration
        });
    }
}

    
  
   private void searchProducts() {

     String keyword = txtSearchProduct.getText()
            .trim()
            .toLowerCase();

    Object categoryObject = cmbCategoryFilter.getSelectedItem();

    String selectedCategory = "All";

    if (categoryObject != null) {
        selectedCategory = categoryObject.toString();
    }

    List<Product> filteredProducts = new ArrayList<>();

    for (Product product : allProducts) {

        boolean matchesSearch =
                keyword.isEmpty()
                ||
                (product.getProductName() != null
                    && product.getProductName()
                        .toLowerCase()
                        .contains(keyword))
                
                || (product.getBarcode() != null
                && product.getBarcode().contains(keyword))
                
                ||
                String.valueOf(product.getProductId())
                        .contains(keyword);

        boolean matchesCategory =
                selectedCategory.equals("All")
                ||
                (product.getCategoryName() != null
                    && product.getCategoryName()
                        .equalsIgnoreCase(selectedCategory));

        if (matchesSearch && matchesCategory) {
            filteredProducts.add(product);
        }
    }

    displayProducts(filteredProducts);
   }
   
   
   
   
   private void displayProducts(List<Product> products) {

    DefaultTableModel model =
        (DefaultTableModel) tblProducts.getModel();

    model.setRowCount(0);

    for (Product product : products) {

        String expiration =
            product.getEarliestExpiration() == null
                ? "No Expiry"
                : product.getEarliestExpiration().toString();

        model.addRow(new Object[]{

    product.getProductId(),
    product.getProductName(),
    product.getBarcode(),
    product.getCategoryName(),
    product.getPiecesPerBulk(),
    product.getPricePerPiece(),
    product.getPricePerBulk(),
    product.getTotalStock(),
    expiration
        });
    }
   }
   
   
   
private void loadCategoryFilter() {
    cmbCategoryFilter.removeAllItems();
    cmbCategoryFilter.addItem("All");

    String sql =
        "SELECT category_name FROM categories "
        + "ORDER BY category_name ASC";

    try (
        Connection conn = ConnectDb.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery()
    ) {
        while (rs.next()) {
            String categoryName = rs.getString("category_name");

            if (categoryName != null
                    && !categoryName.trim().isEmpty()) {
                cmbCategoryFilter.addItem(categoryName);
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error loading category filter: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }

    cmbCategoryFilter.setSelectedIndex(0);
}

   
   
  private void applyInventorySort() {
     Object sortObject = cmbSortBy.getSelectedItem();
    Object orderObject = cmbSortOrder.getSelectedItem();

    if (sortObject == null || orderObject == null) {
        return;
    }

    String sortBy = sortObject.toString();
    String order = orderObject.toString();

    // Select the sorting strategy.
    ProductSortStrategy strategy =
            ProductSortStrategy.create(sortBy);

    // Get the comparator from the selected strategy.
    Comparator<Product> comparator =
            strategy.getComparator();

    // Apply ascending or descending order.
    if ("Descending".equalsIgnoreCase(order)) {
        comparator = comparator.reversed();
    }

    // Sort the products.
    ProductSorter.insertionSort(
        allProducts,
        comparator
    );

    // Refresh the table.
    searchProducts();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        btnProductArchiveVault = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblProducts = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtProductName = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtBarcode = new javax.swing.JTextField();
        btnAddProduct = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        cbCategory = new javax.swing.JComboBox<>();
        btnNewCategory = new javax.swing.JButton();
        btnNewCategory1 = new javax.swing.JButton();
        btnImage = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtPiecePrice = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtPcsPerBulk = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtBulkPrice = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btnEdit = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        dateChooserExpiration = new com.toedter.calendar.JDateChooser();
        btnEdit1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtSearchProduct = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cmbCategoryFilter = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        cmbSortBy = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        cmbSortOrder = new javax.swing.JComboBox<>();
        btnApplySort = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        txtStock1 = new javax.swing.JTextField();

        jLabel7.setText("jLabel7");

        setLayout(new java.awt.GridBagLayout());

        jPanel1.setBackground(new java.awt.Color(245, 247, 250));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(251, 251, 251));

        btnProductArchiveVault.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnProductArchiveVault.setText("Archive Vault");
        btnProductArchiveVault.addActionListener(this::btnProductArchiveVaultActionPerformed);

        jScrollPane4.setBackground(new java.awt.Color(255, 255, 255));

        tblProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Product ID", "Product Name", "Barcode", "Category ", "Pcs/Bulk", "Price (Piece)", "Price (Bulk)", "Total Stock (Pieces)", "Earliest Expiry"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblProducts.setPreferredSize(new java.awt.Dimension(620, 120));
        tblProducts.setSelectionBackground(new java.awt.Color(70, 120, 150));
        tblProducts.setSelectionForeground(new java.awt.Color(255, 255, 255));
        tblProducts.setShowHorizontalLines(true);
        jScrollPane4.setViewportView(tblProducts);
        if (tblProducts.getColumnModel().getColumnCount() > 0) {
            tblProducts.getColumnModel().getColumn(2).setResizable(false);
            tblProducts.getColumnModel().getColumn(8).setResizable(false);
        }

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel1.setText("ADD NEW INVENTORY PRODUCT");

        jLabel2.setText("Product Name:");

        jLabel4.setText("Stock:");

        btnAddProduct.setBackground(new java.awt.Color(0, 128, 0));
        btnAddProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnAddProduct.setText("+ Add Product ");
        btnAddProduct.addActionListener(this::btnAddProductActionPerformed);

        jLabel5.setText("Category:");

        cbCategory.addActionListener(this::cbCategoryActionPerformed);

        btnNewCategory.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnNewCategory.setText("+");
        btnNewCategory.addActionListener(this::btnNewCategoryActionPerformed);

        btnNewCategory1.setBackground(new java.awt.Color(255, 0, 0));
        btnNewCategory1.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnNewCategory1.setForeground(new java.awt.Color(255, 255, 255));
        btnNewCategory1.setText("-");
        btnNewCategory1.addActionListener(this::btnNewCategory1ActionPerformed);

        btnImage.setText("Choose An Image");
        btnImage.addActionListener(this::btnImageActionPerformed);

        jLabel8.setText("Piece Price:");

        jLabel9.setText("Bulk Price");

        jLabel10.setText("Pcs per Bulk:");

        txtBulkPrice.addActionListener(this::txtBulkPriceActionPerformed);

        jLabel11.setText("Expiration Date:");

        btnEdit.setText("Edit");
        btnEdit.addActionListener(this::btnEditActionPerformed);

        btnDelete.setBackground(new java.awt.Color(255, 0, 0));
        btnDelete.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete.setText("Archive");
        btnDelete.addActionListener(this::btnDeleteActionPerformed);

        dateChooserExpiration.setBackground(new java.awt.Color(255, 255, 255));
        dateChooserExpiration.setDateFormatString("yyyy-MM-dd");

        btnEdit1.setText("Add Stock");
        btnEdit1.addActionListener(this::btnEdit1ActionPerformed);

        jLabel3.setText("Search:");

        txtSearchProduct.addActionListener(this::txtSearchProductActionPerformed);
        txtSearchProduct.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchProductKeyReleased(evt);
            }
        });

        jLabel6.setText("Category:");

        cmbCategoryFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", " " }));
        cmbCategoryFilter.addActionListener(this::cmbCategoryFilterActionPerformed);

        jLabel12.setText("Sort:");

        cmbSortBy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Product Name", "Price (Piece)", "Price (Bulk)", "Total Stock", "Earliest Expiry" }));
        cmbSortBy.addActionListener(this::cmbSortByActionPerformed);

        jLabel13.setText("Order:");

        cmbSortOrder.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ascending", "Descending" }));
        cmbSortOrder.addActionListener(this::cmbSortOrderActionPerformed);

        btnApplySort.setBackground(new java.awt.Color(0, 153, 0));
        btnApplySort.setForeground(new java.awt.Color(255, 255, 255));
        btnApplySort.setText("Apply");
        btnApplySort.addActionListener(this::btnApplySortActionPerformed);

        jLabel14.setText("Barcode:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel12)
                        .addGap(18, 18, 18)
                        .addComponent(cmbSortBy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(cmbSortOrder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnApplySort)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(txtSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbCategoryFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(btnEdit1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEdit)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnProductArchiveVault))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 1276, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(10, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel8))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)
                                .addComponent(jLabel10))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtPiecePrice, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(86, 86, 86)
                                .addComponent(jLabel9)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtBulkPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPcsPerBulk, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(jLabel4))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtBarcode, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtStock1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(35, 35, 35))
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(dateChooserExpiration, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(cbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnNewCategory)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnNewCategory1)))
                        .addGap(61, 61, 61)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnImage, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAddProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(61, 61, 61))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(cmbSortBy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(cmbSortOrder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnApplySort)
                    .addComponent(jLabel3)
                    .addComponent(txtSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(cmbCategoryFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEdit1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProductArchiveVault, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 528, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnImage, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNewCategory1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNewCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 10, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dateChooserExpiration, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel8)
                                        .addComponent(txtPiecePrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel9)
                                        .addComponent(txtBulkPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4)
                                        .addComponent(txtStock1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel11))))
                            .addComponent(btnAddProduct, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE))
                        .addGap(133, 133, 133))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtBarcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel5))
                                .addGap(5, 5, 5))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel2)
                                .addComponent(txtProductName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel10)
                                .addComponent(txtPcsPerBulk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 19;
        gridBagConstraints.ipady = 16;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 6, 6);
        add(jPanel1, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNewCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewCategoryActionPerformed

loadCategoryFilter();
String newCategory = JOptionPane.showInputDialog(this, "Enter new category name:");
if (newCategory == null || newCategory.trim().isEmpty()) return;
newCategory = newCategory.trim();

String checkSql = "SELECT COUNT(*) FROM categories WHERE LOWER(category_name) = LOWER(?)";
String insertSql = "INSERT INTO categories (category_name) VALUES (?)";

try (Connection conn = ConnectDb.getConnection();
     PreparedStatement check = conn.prepareStatement(checkSql)) {

    check.setString(1, newCategory);
    try (ResultSet rs = check.executeQuery()) {
        rs.next();
        if (rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(this, "Existing na ang category na '" + newCategory + "'.");
            return;
        }
    }

    try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
        ps.setString(1, newCategory);
        ps.executeUpdate();
        if (parentDashboard != null
        && parentDashboard.getCurrentUser() != null) {

    SecurityLogService.logAction(
        parentDashboard.getCurrentUser().getUsername(),
        parentDashboard.getCurrentUser().getRole(),
        "ADD_CATEGORY",
        "Added category: " + newCategory
    );
        }
    }

    loadCategories();
    loadCategoryFilter();

    JOptionPane.showMessageDialog(this, "Category added!");
} catch (SQLException e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
}

      
    

// TODO add your handling code here:
    }//GEN-LAST:event_btnNewCategoryActionPerformed

    private void cbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCategoryActionPerformed
    }//GEN-LAST:event_cbCategoryActionPerformed

    private void btnAddProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddProductActionPerformed
 String name = txtProductName.getText().trim();
    String stockStr = txtStock1.getText().trim();
    String barcode = txtBarcode.getText().trim();
    String piecePriceStr = txtPiecePrice.getText().trim();
    String bulkPriceStr = txtBulkPrice.getText().trim();
    String pcsPerBulkStr = txtPcsPerBulk.getText().trim();

    java.util.Date selectedDate = dateChooserExpiration.getDate();

    // =========================
    // VALIDATION
    // =========================

   if (name.isEmpty()
    || piecePriceStr.isEmpty()
    || bulkPriceStr.isEmpty()
    || pcsPerBulkStr.isEmpty()
    || (!editMode && stockStr.isEmpty())) {

    JOptionPane.showMessageDialog(
        this,
        "Please fill in all required fields."
    );
    return;
    }

    if (!editMode && selectedDate == null) {
    JOptionPane.showMessageDialog(
        this,
        "Please select an expiration date."
    );
    return;
    }

    CategoryItem selectedCategory =
            (CategoryItem) cbCategory.getSelectedItem();

    if (selectedCategory == null) {
        JOptionPane.showMessageDialog(
                this,
                "Please select a category."
        );
        return;
    }

    try {

        int stock = 0;

if (!editMode) {
    stock = Integer.parseInt(stockStr);
}

double pricePiece = Double.parseDouble(piecePriceStr);
double priceBulk = Double.parseDouble(bulkPriceStr);
int pcsPerBulk = Integer.parseInt(pcsPerBulkStr);
if (!barcode.isEmpty() && !barcode.matches("\\d{8,14}")) {
    JOptionPane.showMessageDialog(
        this,
        "Barcode must contain 8 to 14 digits."
    );
        return;
}
       if (!editMode && stock <= 0) {
    JOptionPane.showMessageDialog(
            this,
            "Initial stock must be greater than 0."
    );
    return;
        }

        if (pricePiece < 0 || priceBulk < 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Prices cannot be negative."
            );
            return;
        }

        if (pcsPerBulk <= 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Pcs per Bulk must be greater than 0."
            );
            return;
        }

        // Remove time from expiration date
        java.util.Calendar calendar =
                java.util.Calendar.getInstance();

        calendar.set(java.util.Calendar.HOUR_OF_DAY, 0);
        calendar.set(java.util.Calendar.MINUTE, 0);
        calendar.set(java.util.Calendar.SECOND, 0);
        calendar.set(java.util.Calendar.MILLISECOND, 0);

        if (!editMode && selectedDate != null &&
        selectedDate.before(calendar.getTime())) {

            JOptionPane.showMessageDialog(
                    this,
                    "You cannot add stock with an expired date."
            );
            return;
        }

        java.sql.Date expirationDate = null;

    if (selectedDate != null) {
    expirationDate = new java.sql.Date(selectedDate.getTime());
    }
 // =========================
        // CONFIRMATION
        // =========================

        String confirmMessage;

        if (editMode) {

            confirmMessage = String.format(
                "Save changes to this product?\n\n"
                + "Name: %s\n"
                + "Category: %s\n"
                + "Piece Price: ₱%,.2f\n"
                + "Bulk Price: ₱%,.2f\n"
                + "Pcs per Bulk: %d",
                name,
                selectedCategory,
                pricePiece,
                priceBulk,
                pcsPerBulk
            );

        } else {

            confirmMessage = String.format(
                "Add this product?\n\n"
                + "Name: %s\n"
                + "Category: %s\n"
                + "Piece Price: ₱%,.2f\n"
                + "Bulk Price: ₱%,.2f\n"
                + "Pcs per Bulk: %d\n"
                + "Initial Stock: %,d pcs\n"
                + "Expiration: %s",
                name,
                selectedCategory,
                pricePiece,
                priceBulk,
                pcsPerBulk,
                stock,
                expirationDate
            );
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            confirmMessage,
            editMode ? "Confirm Save Changes" : "Confirm Add Product",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }  
    
        // =========================
        // DATABASE TRANSACTION
        // =========================

        try (Connection conn = ConnectDb.getConnection()) {

            conn.setAutoCommit(false);

            try {

                if (editMode) {

                    // =================================
                    // UPDATE EXISTING PRODUCT
                    // =================================

                    String checkSql =
    "SELECT product_name, barcode, category_id, "
    + "pieces_per_bulk, price_per_piece, price_per_bulk, image_path "
    + "FROM products "
    + "WHERE product_id = ? AND status = 'Active'";
   
                    boolean productExists = false;
                    boolean hasChanges = false;
                    
                    
                     try (PreparedStatement ps = conn.prepareStatement(checkSql)) {

                         ps.setInt(1, editingProductId);

             try (ResultSet rs = ps.executeQuery()) {

             if (rs.next()) {

                productExists = true;

              
String existingName = rs.getString("product_name");

String existingBarcode = rs.getString("barcode");
if (existingBarcode == null) {
    existingBarcode = "";
}

String existingImagePath = rs.getString("image_path");
if (existingImagePath == null) {
    existingImagePath = "";
}


hasChanges =
        !name.equals(existingName)
        || !barcode.equals(existingBarcode)
        || selectedCategory.getId() != rs.getInt("category_id")
        || pcsPerBulk != rs.getInt("pieces_per_bulk")
        || Double.compare(
                pricePiece,
                rs.getDouble("price_per_piece")
        ) != 0
        || Double.compare(
                priceBulk,
                rs.getDouble("price_per_bulk")
        ) != 0
        || !selectedImagePath.equals(existingImagePath);
             }
             }
             
                    }
                if (!productExists) {
    conn.rollback();

    cancelEditMode();
    loadProducts();

    JOptionPane.showMessageDialog(
        this,
        "This product is no longer available for editing.\n"
        + "It may have been archived or deleted."
    );

    return;
    }

  
if (hasChanges) {

    String updateSql =
        "UPDATE products SET "
        + "product_name = ?, "
        + "barcode = ?, "
        + "category_id = ?, "
        + "pieces_per_bulk = ?, "
        + "price_per_piece = ?, "
        + "price_per_bulk = ?, "
        + "image_path = ? "
        + "WHERE product_id = ? "
        + "AND status = 'Active'";

    try (PreparedStatement ps = conn.prepareStatement(updateSql)) {

        ps.setString(1, name);
        ps.setString(2, barcode.isEmpty() ? null : barcode);
        ps.setInt(3, selectedCategory.getId());
        ps.setInt(4, pcsPerBulk);
        ps.setDouble(5, pricePiece);
        ps.setDouble(6, priceBulk);
        ps.setString(7, selectedImagePath.isEmpty()
                ? null : selectedImagePath);
        ps.setInt(8, editingProductId);

        int affectedRows = ps.executeUpdate();

        if (affectedRows != 1) {
            conn.rollback();

            JOptionPane.showMessageDialog(
                this,
                "Product update failed. No changes were saved."
            );
            return;
        }
    }

    conn.commit();

    if (parentDashboard != null
            && parentDashboard.getCurrentUser() != null) {

        SecurityLogService.logAction(
            parentDashboard.getCurrentUser().getUsername(),
            parentDashboard.getCurrentUser().getRole(),
            "Edit Product",
            "Updated product ID: " + editingProductId
                + " | Product Name: " + name
        );
    }

    JOptionPane.showMessageDialog(
        this,
        "Product updated successfully!"
    );

} else {

    JOptionPane.showMessageDialog(
        this,
        "No changes detected. Product information remains unchanged."
    );

}

                  
                } else {

                    // =================================
                    // ADD NEW PRODUCT
                    // =================================
    
String insertProductSql =
        "INSERT INTO products "
        + "(barcode, product_name, category_id, "
        + "pieces_per_bulk, price_per_piece, "
        + "price_per_bulk, image_path, status) "
        + "VALUES (?, ?, ?, ?, ?, ?, ?, 'Active')";

int productId;

// Check for duplicate barcode first.
if (!barcode.isEmpty()) {
    String duplicateSql =
            "SELECT COUNT(*) FROM products WHERE barcode = ?";

    try (PreparedStatement duplicatePs =
                 conn.prepareStatement(duplicateSql)) {

        duplicatePs.setString(1, barcode);

        try (ResultSet duplicateRs = duplicatePs.executeQuery()) {
            if (duplicateRs.next() && duplicateRs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "This barcode is already assigned to another product.",
                        "Duplicate Barcode",
                        JOptionPane.WARNING_MESSAGE
                );
                conn.rollback();
                return;
            }
        }
    }
}

// Insert the product once and retrieve its generated ID.
try (PreparedStatement ps = conn.prepareStatement(
        insertProductSql,
        java.sql.Statement.RETURN_GENERATED_KEYS)) {

    if (barcode.isEmpty()) {
        ps.setNull(1, java.sql.Types.VARCHAR);
    } else {
        ps.setString(1, barcode);
    }

    ps.setString(2, name);
    ps.setInt(3, selectedCategory.getId());
    ps.setInt(4, pcsPerBulk);
    ps.setDouble(5, pricePiece);
    ps.setDouble(6, priceBulk);
    ps.setString(
            7,
            selectedImagePath.isEmpty() ? null : selectedImagePath
    );

    int affectedRows = ps.executeUpdate();

    if (affectedRows != 1) {
        conn.rollback();
        JOptionPane.showMessageDialog(this, "Failed to add the product.");
        return;
    }

    try (ResultSet keys = ps.getGeneratedKeys()) {
        if (!keys.next()) {
            conn.rollback();
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to get the new Product ID."
            );
            return;
        }

        productId = keys.getInt(1);
    }
}

            
                    

                    // =================================
                    // CREATE FIRST INVENTORY BATCH
                    // =================================

                   String batchSql =
        "INSERT INTO inventory_batches "
        + "(product_id, date_received, expiration_date, "
        + "initial_pieces, remaining_pieces, status) "
        + "VALUES (?, CURRENT_DATE(), ?, ?, ?, 'Available')";

try (PreparedStatement ps = conn.prepareStatement(batchSql)) {

    ps.setInt(1, productId);
    ps.setDate(2, expirationDate);
    ps.setInt(3, stock);
    ps.setInt(4, stock);

    ps.executeUpdate();                    }

                    conn.commit();

// SECURITY LOG - ADD PRODUCT
if (parentDashboard != null &&
    parentDashboard.getCurrentUser() != null) {

    SecurityLogService.logAction(
        parentDashboard.getCurrentUser().getUsername(),
        parentDashboard.getCurrentUser().getRole(),
        "Add Product",
        "Added product: " + name
        + " | Initial Stock: " + stock
        + " pcs"
        + " | Expiration: " + expirationDate
    );
}

JOptionPane.showMessageDialog(
        this,
        "Product added successfully!"
);
                    
                }

            } catch (SQLException e) {

                conn.rollback();
                throw e;
            }

        }

        // =========================
        // REFRESH UI
        // =========================

        loadProducts();

        if (parentDashboard != null) {
            parentDashboard.refreshSalesPanel();
        }

        // =========================
        // RESET FORM
        // =========================

        editMode = false;
        editingProductId = -1;

        txtProductName.setText("");
        txtBarcode.setText("");
        txtPiecePrice.setText("");
        txtBulkPrice.setText("");
        txtPcsPerBulk.setText("");
        txtStock1.setText("");
        
       dateChooserExpiration.setDate(null);
       dateChooserExpiration.setEnabled(true);
        selectedImagePath = "";

        btnImage.setText("Choose An Image");

        txtBarcode.setEditable(true);

        btnAddProduct.setText("+ Add Product");

        jLabel1.setText("ADD NEW INVENTORY PRODUCT");

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this,
                "Stock, prices, and Pcs per Bulk must contain valid numbers."
        );

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Database Error: " + e.getMessage()
        );
    }
    }//GEN-LAST:event_btnAddProductActionPerformed

    private void btnProductArchiveVaultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductArchiveVaultActionPerformed
    ProductArchiveVault vault = new ProductArchiveVault(this);
    vault.setVisible(true);
    }
  public void refreshProductList() {
    loadProducts();
    if (parentDashboard != null) {
        parentDashboard.refreshSalesPanel();
    }
    }//GEN-LAST:event_btnProductArchiveVaultActionPerformed

    private void btnNewCategory1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewCategory1ActionPerformed
CategoryItem selected = (CategoryItem) cbCategory.getSelectedItem();

if (selected == null) {
    JOptionPane.showMessageDialog(this, "Pumili muna ng category.");
    return;
}

int categoryId = selected.getId();
String name = selected.name;

int confirm = JOptionPane.showConfirmDialog(this,
    "Burahin ang category na '" + name + "'?",
    "Confirm Delete", JOptionPane.YES_NO_OPTION);
if (confirm != JOptionPane.YES_OPTION) return;

String countSql = "SELECT c.category_id, COUNT(p.product_id) AS total "
                + "FROM categories c LEFT JOIN products p ON p.category_id = c.category_id "
                + "WHERE c.category_id = ? GROUP BY c.category_id";
String deleteSql = "DELETE FROM categories WHERE category_id = ?";

try (Connection conn = ConnectDb.getConnection();
     PreparedStatement count = conn.prepareStatement(countSql)) {

    count.setInt(1, categoryId);
    try (ResultSet rs = count.executeQuery()) {
        if (!rs.next()) return;
        int id = rs.getInt("category_id");
        int total = rs.getInt("total");

        if (total > 0) {
            JOptionPane.showMessageDialog(this,
                "May " + total + " product(s) pa sa '" + name + "'.\n"
                + "Ilipat o i-archive muna sila bago burahin ang category.");
            return;
        }

        try (PreparedStatement del = conn.prepareStatement(deleteSql)) {
            del.setInt(1, id);
            del.executeUpdate();
        }
    }

    loadCategories();
    loadCategoryFilter();

    JOptionPane.showMessageDialog(this, "Category deleted!");
} catch (SQLException e) {
    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    if (parentDashboard != null
        && parentDashboard.getCurrentUser() != null) {

    SecurityLogService.logAction(
        parentDashboard.getCurrentUser().getUsername(),
        parentDashboard.getCurrentUser().getRole(),
        "DELETE_CATEGORY",
        "Deleted category ID: " + categoryId
            + " | Category Name: " + name
    );
    }
}        
    }//GEN-LAST:event_btnNewCategory1ActionPerformed

    private void btnImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImageActionPerformed
    FileDialog fileDialog = new FileDialog(
        (Frame) javax.swing.SwingUtilities.getWindowAncestor(this),
        "Select Product Image",
        FileDialog.LOAD
    );
    fileDialog.setFile("*.jpg;*.jpeg;*.png;*.gif");
    fileDialog.setVisible(true);

    String fileName = fileDialog.getFile();
    if (fileName == null) {
        return;   // user cancelled the file chooser
    }

    try {
        BufferedImage original = ImageIO.read(new File(fileDialog.getDirectory(), fileName));
        if (original == null) {
            JOptionPane.showMessageDialog(this, "That file is not a valid image.");
            return;
        }

        // let the user move/zoom the picture inside the card box first
        BufferedImage adjusted = ImageAdjustDialog.showDialog(this, original);
        if (adjusted == null) {
            return;   // cancelled in the adjust window
        }

        File folder = new File("product_images");
        if (!folder.exists() && !folder.mkdirs()) {
            throw new IOException("Cannot create folder: " + folder.getAbsolutePath());
        }
        File saved = new File(folder, "product_" + System.currentTimeMillis() + ".png");
        ImageIO.write(adjusted, "png", saved);

        selectedImagePath = "product_images/" + saved.getName();
        btnImage.setText(fileName);

    } catch (IOException ex) {
        JOptionPane.showMessageDialog(this, "Could not load or save the image: " + ex.getMessage());
    
    }
    }//GEN-LAST:event_btnImageActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
   loadSelectedProductForEdit();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
    int[] selectedRows = tblProducts.getSelectedRows();

    if (selectedRows.length == 0) {
        JOptionPane.showMessageDialog(
            this,
            "Please select at least one product to archive."
        );
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Archive " + selectedRows.length + " selected product(s)?",
        "Confirm Archive",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql =
        "UPDATE products SET status = 'Archived' "
        + "WHERE product_id = ? AND status = 'Active'";

    // Store successful archives so we can log them after commit.
    List<String> archivedProducts = new ArrayList<>();

    try (Connection conn = ConnectDb.getConnection()) {
        conn.setAutoCommit(false);

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int row : selectedRows) {
                int modelRow = tblProducts.convertRowIndexToModel(row);

                int productId = Integer.parseInt(
                    tblProducts.getModel()
                        .getValueAt(modelRow, 0).toString()
                );

                String productName = tblProducts.getModel()
                    .getValueAt(modelRow, 1).toString();

                ps.setInt(1, productId);

                int affectedRows = ps.executeUpdate();

                if (affectedRows > 0) {
                    archivedProducts.add(
                        "Product ID: " + productId
                        + " | Product Name: " + productName
                    );

                    if (editMode && productId == editingProductId) {
                        cancelEditMode();
                    }
                }
            }

            // Commit product changes before creating audit records.
            conn.commit();

        } catch (SQLException e) {
            conn.rollback();
            throw e;
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error archiving products: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
        return;
    }

    // Write Security Logs after the archive transaction succeeds.
    if (parentDashboard != null
            && parentDashboard.getCurrentUser() != null) {

        String username =
            parentDashboard.getCurrentUser().getUsername();

        String role =
            parentDashboard.getCurrentUser().getRole();

        for (String details : archivedProducts) {
            SecurityLogService.logAction(
                username,
                role,
                "ARCHIVE_PRODUCT",
                "Archived " + details
            );
        }
    } else {
        System.err.println(
            "Archive succeeded, but Security Logs were not saved: "
            + "current user or dashboard is null."
        );
    }

    loadProducts();

    if (parentDashboard != null) {
        parentDashboard.refreshSalesPanel();
    }

    JOptionPane.showMessageDialog(
        this,
        archivedProducts.size() + " product(s) archived successfully."
    );
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEdit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEdit1ActionPerformed
   int selectedRow = tblProducts.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this,
            "Please select a product first.");
        return;
    }

    int modelRow = tblProducts.convertRowIndexToModel(selectedRow);

    int productId = Integer.parseInt(
        tblProducts.getModel().getValueAt(modelRow, 0).toString()
    );

    String productName =
        tblProducts.getModel().getValueAt(modelRow, 1).toString();

    int piecesPerBulk = Integer.parseInt(
    tblProducts.getModel().getValueAt(modelRow, 4).toString()
    );

    java.awt.Window window = SwingUtilities.getWindowAncestor(this);

    Frame parentFrame =
        (window instanceof Frame) ? (Frame) window : null;

    AddStockDialog dialog = new AddStockDialog(
        parentFrame,
        true,
        productId,
        productName,
        piecesPerBulk,
        this
    );

    dialog.setLocationRelativeTo(parentFrame);
    dialog.setVisible(true);        
    }//GEN-LAST:event_btnEdit1ActionPerformed

    private void btnApplySortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApplySortActionPerformed
    applyInventorySort();
    }//GEN-LAST:event_btnApplySortActionPerformed

    private void txtSearchProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchProductActionPerformed
    searchProducts();

    }//GEN-LAST:event_txtSearchProductActionPerformed

    private void cmbCategoryFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryFilterActionPerformed
    searchProducts();
    }//GEN-LAST:event_cmbCategoryFilterActionPerformed

    private void txtSearchProductKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchProductKeyReleased
    searchProducts();
    }//GEN-LAST:event_txtSearchProductKeyReleased

    private void cmbSortByActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSortByActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbSortByActionPerformed

    private void cmbSortOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSortOrderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbSortOrderActionPerformed

    private void txtBulkPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBulkPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBulkPriceActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddProduct;
    private javax.swing.JButton btnApplySort;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnEdit1;
    private javax.swing.JButton btnImage;
    private javax.swing.JButton btnNewCategory;
    private javax.swing.JButton btnNewCategory1;
    private javax.swing.JButton btnProductArchiveVault;
    private javax.swing.JComboBox<CategoryItem> cbCategory;
    private javax.swing.JComboBox<String> cmbCategoryFilter;
    private javax.swing.JComboBox<String> cmbSortBy;
    private javax.swing.JComboBox<String> cmbSortOrder;
    private com.toedter.calendar.JDateChooser dateChooserExpiration;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable tblProducts;
    private javax.swing.JTextField txtBarcode;
    private javax.swing.JTextField txtBulkPrice;
    private javax.swing.JTextField txtPcsPerBulk;
    private javax.swing.JTextField txtPiecePrice;
    private javax.swing.JTextField txtProductName;
    private javax.swing.JTextField txtSearchProduct;
    private javax.swing.JTextField txtStock1;
    // End of variables declaration//GEN-END:variables
public void checkExpiringProducts() {

    // Check kung naipakita na ang notification ngayong araw
    String checkSql = "SELECT last_shown_date FROM notification_logs "
                    + "WHERE notification_type = 'NEAR_EXPIRY'";

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement checkPs = conn.prepareStatement(checkSql);
         ResultSet checkRs = checkPs.executeQuery()) {

        if (checkRs.next()) {
            java.sql.Date lastShown = checkRs.getDate("last_shown_date");

            if (lastShown != null &&
                lastShown.toLocalDate().equals(java.time.LocalDate.now())) {
                return; 
            }
        }

        // Kukunin ang mga item na mag-e-expire sa loob ng 30 araw
        String sql =  "SELECT p.product_name, b.expiration_date, b.remaining_pieces "
           + "FROM inventory_batches b "
           + "JOIN products p ON b.product_id = p.product_id "
           + "WHERE p.status = 'Active' "
           + "AND b.expiration_date BETWEEN CURDATE() "
           + "AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) "
           + "AND b.remaining_pieces > 0 "
           + "AND b.status = 'Available'";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            StringBuilder warningList = new StringBuilder();
            boolean mayNearExpiry = false;

            while (rs.next()) {
                mayNearExpiry = true;

                String name = rs.getString("product_name");
                String date = rs.getString("expiration_date");
                int stock = rs.getInt("remaining_pieces");

                warningList.append("• ").append(name)
                           .append(" | Expiration Date: ").append(date)
                           .append(" | Stock: ").append(stock)
                           .append(" pcs\n");
            }

            // Ipakita lamang kung may malapit nang mag-expire
            if (mayNearExpiry) {

                JOptionPane.showMessageDialog(
                this,
                "WARNING: The following products are nearing their expiration dates within the next 30 days:\n\n"
                + warningList,
                "Near Expiration Warning",
                JOptionPane.WARNING_MESSAGE
);

                // I-save ang date pagkatapos ipakita ang notification
                String saveSql =
                    "INSERT INTO notification_logs "
                    + "(notification_type, last_shown_date) "
                    + "VALUES ('NEAR_EXPIRY', CURDATE()) "
                    + "ON DUPLICATE KEY UPDATE last_shown_date = CURDATE()";

                try (PreparedStatement savePs =
                         conn.prepareStatement(saveSql)) {
                    savePs.executeUpdate();
                }
            }
        }

    } catch (SQLException e) {
        System.out.println("Error checking expiration: " + e.getMessage());
        e.printStackTrace();
    }
}   

private static final class CategoryItem {

    private final int id;
    private final String name;

    private CategoryItem(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}




private void loadSelectedProductForEdit() {

    int selectedRow = tblProducts.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(
            this,
            "Please select a product from the table first."
        );
        return;
    }

    int modelRow = tblProducts.convertRowIndexToModel(selectedRow);

    int productId = Integer.parseInt(tblProducts.getModel()
            .getValueAt(modelRow, 0)
            .toString()
    );

  String sql =
    "SELECT product_id, barcode, product_name, category_id, " +
    "pieces_per_bulk, price_per_piece, price_per_bulk, image_path " +
    "FROM products " +
    "WHERE product_id = ? AND status = 'Active'";
    try (
        Connection conn = ConnectDb.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql)
    ) {

        ps.setInt(1, productId);

        try (ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {

                editingProductId = productId;

                // =========================
                // PRODUCT INFORMATION
                // =========================

                txtProductName.setText(
                    rs.getString("product_name")
                );

                txtPiecePrice.setText(
                    String.valueOf(
                        rs.getDouble("price_per_piece")
                    )
                );

                txtBulkPrice.setText(
                    String.valueOf(
                        rs.getDouble("price_per_bulk")
                    )
                );

                txtPcsPerBulk.setText(
                    String.valueOf(
                        rs.getInt("pieces_per_bulk")
                    )
                );

                // =========================
                // CATEGORY
                // =========================

                int categoryId =
                    rs.getInt("category_id");

                for (int i = 0;
                     i < cbCategory.getItemCount();
                     i++) {

                    CategoryItem item =
                        cbCategory.getItemAt(i);

                    if (item.getId() == categoryId) {
                        cbCategory.setSelectedIndex(i);
                        break;
                    }
                }

                // =========================
                // STOCK / EXPIRATION
                // =========================
                //
                // DO NOT load these from products.
                // Stock and expiration are stored
                // in inventory_batches.
                //

               txtBarcode.setText(
    rs.getString("barcode") == null
        ? ""
        : rs.getString("barcode")
);

txtBarcode.setEditable(true);

                dateChooserExpiration.setDate(null);
                dateChooserExpiration.setEnabled(false);

                // =========================
                // IMAGE
                // =========================
               
                selectedImagePath = rs.getString("image_path");

if (selectedImagePath == null || selectedImagePath.trim().isEmpty()) {
    selectedImagePath = "";
    btnImage.setText("Choose An Image");
} else {
    File imageFile = new File(selectedImagePath);
    btnImage.setText(imageFile.getName());
}
                // =========================
                // EDIT MODE
                // =========================

                editMode = true;

                btnAddProduct.setText("Save Changes");

                jLabel1.setText(
                    "EDIT INVENTORY PRODUCT"
                );

                JOptionPane.showMessageDialog(
                    this,
                    "Product loaded! You can now edit its information."
                );

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "Product was not found or is archived."
                );
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading product: " + e.getMessage()
        );
    }
}
private void cancelEditMode() {
    editMode = false;
    editingProductId = -1;

    txtProductName.setText("");
    txtBarcode.setText("");
    txtPiecePrice.setText("");
    txtBulkPrice.setText("");
    txtPcsPerBulk.setText("");
    txtStock1.setText("");
    

    dateChooserExpiration.setDate(null);
    dateChooserExpiration.setEnabled(true);

    selectedImagePath = "";

    btnImage.setText("Choose An Image");

    txtBarcode.setEditable(true);

    btnAddProduct.setText("+ Add Product");

    jLabel1.setText("ADD NEW INVENTORY PRODUCT");
}
private void styleInventoryTable() {
    // Replace tblProducts with your actual JTable variable name
    tblProducts.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12));
    tblProducts.setRowHeight(30);
    tblProducts.setShowGrid(true);
    tblProducts.setGridColor(new java.awt.Color(220, 220, 220));
    tblProducts.setIntercellSpacing(new java.awt.Dimension(1, 1));

    tblProducts.setBackground(java.awt.Color.WHITE);
    tblProducts.setForeground(new java.awt.Color(40, 40, 40));
   tblProducts.setSelectionBackground(new java.awt.Color(70, 120, 150));
   tblProducts.setSelectionForeground(java.awt.Color.WHITE);
    tblProducts.setFillsViewportHeight(true);

    // Header styling
    javax.swing.table.JTableHeader header =
            tblProducts.getTableHeader();

    header.setFont(new java.awt.Font(
            "Segoe UI", java.awt.Font.BOLD, 12));

    header.setBackground(new java.awt.Color(235, 238, 242));
    header.setForeground(new java.awt.Color(35, 35, 35));
    header.setPreferredSize(new java.awt.Dimension(0, 34));
    header.setReorderingAllowed(false);

    // Alternating row colors
    javax.swing.table.DefaultTableCellRenderer renderer =
            new javax.swing.table.DefaultTableCellRenderer() {

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            java.awt.Component component =
                    super.getTableCellRendererComponent(
                            table, value, isSelected,
                            hasFocus, row, column);

            if (isSelected) {
                component.setBackground(
                        new java.awt.Color(220, 235, 252));
                component.setForeground(
                        new java.awt.Color(25, 25, 25));
            } else {
                component.setBackground(
                        row % 2 == 0
                        ? java.awt.Color.WHITE
                        : new java.awt.Color(247, 248, 250));

                component.setForeground(
                        new java.awt.Color(40, 40, 40));
            }

            setBorder(javax.swing.BorderFactory.createEmptyBorder(
                    0, 7, 0, 7));

            return component;
        }
    };

    // Apply the renderer to every column
    for (int i = 0; i < tblProducts.getColumnCount(); i++) {
        tblProducts.getColumnModel()
                .getColumn(i)
                .setCellRenderer(renderer);
    }

    tblProducts.setAutoResizeMode(
            javax.swing.JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
}

}


