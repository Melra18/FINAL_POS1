/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.pos.ui.panel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.pos.config.ConnectDb;
import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import java.awt.Color;

public class SecurityLogs extends javax.swing.JPanel {
private final List<Integer> logIds = new ArrayList<>();
    /**
     * Creates new form SecurityLogs
     */
    public SecurityLogs() {
           initComponents();
           styleSecurityLogsTable();
           ScrollBarStyler.style(jScrollPane1);
    // Search field
    TextFieldStyler.style(txtSearch);
    TextFieldStyler.setPlaceholder(
        txtSearch, "Search security logs..."
    );

    // Dropdown filters
    ComboBoxStyler.style(cbRoleFilter);
    ComboBoxStyler.style(cbActionFilter);

    // Date filters
    DateChooserStyler.style(dateFrom);
    DateChooserStyler.style(dateTo);

    // Action buttons
    ButtonStyler.style(
        btnRefresh,
        new java.awt.Color(51, 65, 85)
    );

    ButtonStyler.style(
        btnRefresh1,
        new java.awt.Color(220, 38, 38)
    );

    ButtonStyler.style(
        btnRefresh2,
        new java.awt.Color(37, 99, 235)
    );

    btnRefresh.setText("Refresh");

    // Search while typing
    txtSearch.getDocument().addDocumentListener(
        new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                loadSecurityLogs();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                loadSecurityLogs();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                loadSecurityLogs();
            }
        }
    );

    // Filters
    cbRoleFilter.addActionListener(e -> loadSecurityLogs());
    cbActionFilter.addActionListener(e -> loadSecurityLogs());

    dateFrom.getDateEditor().addPropertyChangeListener(
        "date", e -> loadSecurityLogs()
    );

    dateTo.getDateEditor().addPropertyChangeListener(
        "date", e -> loadSecurityLogs()
    );

    // Refresh and reset filters
    btnRefresh.addActionListener(e -> {
        txtSearch.setText("");
        cbRoleFilter.setSelectedIndex(0);
        cbActionFilter.setSelectedIndex(0);
        dateFrom.setDate(null);
        dateTo.setDate(null);
        loadSecurityLogs();
    });
    btnRefresh1.addActionListener(e -> archiveSelectedLogs());
    btnRefresh2.addActionListener(e -> openLogVault());
    loadSecurityLogs();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        txtSearch = new javax.swing.JTextField();
        cbRoleFilter = new javax.swing.JComboBox<>();
        cbActionFilter = new javax.swing.JComboBox<>();
        dateFrom = new com.toedter.calendar.JDateChooser();
        dateTo = new com.toedter.calendar.JDateChooser();
        btnRefresh = new javax.swing.JButton();
        pnlHeader3 = new javax.swing.JLabel();
        pnlHeader4 = new javax.swing.JLabel();
        pnlHeader5 = new javax.swing.JLabel();
        pnlHeader6 = new javax.swing.JLabel();
        pnlHeader7 = new javax.swing.JLabel();
        btnRefresh1 = new javax.swing.JButton();
        btnRefresh2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jPanel2.setBackground(new java.awt.Color(245, 247, 250));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtSearch.setToolTipText("Search username, action, or details");

        cbRoleFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All Roles", "Cashier", "Shift Supervisor", "Store Manager" }));

        cbActionFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All Actions", "Login", "Logout", "Add Product", "Edit Product", "Archive Product", "Add Stock", "Process Sale", "Failed Login" }));

        dateFrom.setDateFormatString("yyyy-MM-dd");

        dateTo.setDateFormatString("yyyy-MM-dd");

        btnRefresh.setText("Refresh");

        pnlHeader3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pnlHeader3.setText("Search Activity");

        pnlHeader4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pnlHeader4.setText("Action");

        pnlHeader5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pnlHeader5.setText("Role");

        pnlHeader6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pnlHeader6.setText("From Date");

        pnlHeader7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pnlHeader7.setText("To Date");

        btnRefresh1.setBackground(new java.awt.Color(255, 0, 0));
        btnRefresh1.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh1.setText("Archive/Delete");

        btnRefresh2.setText("Archive Vault");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(pnlHeader3)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(txtSearch)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(dateFrom, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(cbActionFilter, 0, 600, Short.MAX_VALUE))
                                    .addComponent(pnlHeader4)
                                    .addComponent(pnlHeader6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dateTo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cbRoleFilter, 0, 715, Short.MAX_VALUE)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(pnlHeader5)
                                            .addComponent(pnlHeader7, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRefresh1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRefresh2, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(pnlHeader3)
                .addGap(12, 12, 12)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(pnlHeader5))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlHeader4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbActionFilter, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                    .addComponent(cbRoleFilter))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlHeader7)
                    .addComponent(pnlHeader6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dateFrom, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(dateTo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRefresh)
                    .addComponent(btnRefresh1)
                    .addComponent(btnRefresh2))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jScrollPane1.setAutoscrolls(true);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Username", "Role", "Action", "Details", "Date & Time"
            }
        ));
        jTable1.setGridColor(new java.awt.Color(225, 228, 233));
        jTable1.setSelectionBackground(new java.awt.Color(220, 230, 245));
        jTable1.setSelectionForeground(new java.awt.Color(27, 40, 56));
        jTable1.setShowHorizontalLines(true);
        jTable1.setShowVerticalLines(true);
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1312, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 489, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

public void loadSecurityLogs() {

    DefaultTableModel model =
        (DefaultTableModel) jTable1.getModel();

    model.setRowCount(0);
    logIds.clear();

    StringBuilder sql = new StringBuilder(
        "SELECT log_id, username, role, action, details, log_date "
        + "FROM security_logs WHERE is_archived = 0 "
    );

    java.util.List<Object> params = new java.util.ArrayList<>();

    // =========================
    // SEARCH FILTER
    // =========================

    String search = txtSearch.getText().trim();

    if (!search.isEmpty()) {
        sql.append(
            "AND (username LIKE ? OR action LIKE ? OR details LIKE ?) "
        );

        String keyword = "%" + search + "%";

        params.add(keyword);
        params.add(keyword);
        params.add(keyword);
    }

    // =========================
    // ROLE FILTER
    // =========================

    String role = (String) cbRoleFilter.getSelectedItem();

    if (role != null && !role.equals("All Roles")) {
        sql.append("AND role = ? ");
        params.add(role);
    }

    // =========================
    // ACTION FILTER
    // =========================

    String action = (String) cbActionFilter.getSelectedItem();

    if (action != null && !action.equals("All Actions")) {
        sql.append("AND action = ? ");
        params.add(action);
    }

    // =========================
    // DATE FROM FILTER
    // =========================

    java.util.Date fromDate = dateFrom.getDate();

    if (fromDate != null) {
        sql.append("AND log_date >= ? ");
        params.add(new java.sql.Date(fromDate.getTime()));
    }

    // =========================
    // DATE TO FILTER
    // =========================

    java.util.Date toDate = dateTo.getDate();

    if (toDate != null) {

        // Add one day so the entire selected date is included
        java.util.Calendar calendar =
            java.util.Calendar.getInstance();

        calendar.setTime(toDate);
        calendar.add(java.util.Calendar.DAY_OF_MONTH, 1);

        sql.append("AND log_date < ? ");

        params.add(
            new java.sql.Date(calendar.getTimeInMillis())
        );
    }

    // =========================
    // SORTING
    // =========================

    sql.append("ORDER BY log_date DESC");

    // =========================
    // CHECK DATE RANGE
    // =========================

    if (fromDate != null && toDate != null
        && fromDate.after(toDate)) {

        JOptionPane.showMessageDialog(
            this,
            "From Date cannot be later than To Date.",
            "Invalid Date Range",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    // =========================
    // DATABASE
    // =========================

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps =
             conn.prepareStatement(sql.toString())) {

        for (int i = 0; i < params.size(); i++) {
            ps.setObject(i + 1, params.get(i));
        }

        try (ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                logIds.add(rs.getInt("log_id"));
                String username = rs.getString("username");
                String logRole = rs.getString("role");
                String logAction = rs.getString("action");
                String details = rs.getString("details");

                Timestamp logDate =
                    rs.getTimestamp("log_date");

                String formattedDate = (logDate != null)
                    ? new java.text.SimpleDateFormat(
                        "MMM dd, yyyy hh:mm:ss a"
                    ).format(logDate)
                    : "";

                model.addRow(new Object[] {
                    username,
                    logRole,
                    logAction,
                    details,
                    formattedDate
                });
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "Error loading security logs: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );

        e.printStackTrace();
    }
}
private void archiveSelectedLogs() {

    int[] rows = jTable1.getSelectedRows();

    if (rows.length == 0) {
        JOptionPane.showMessageDialog(this,
                "Select one or more log entries to archive.",
                "Archive", JOptionPane.WARNING_MESSAGE);
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this,
            "Archive " + rows.length + " log entr" + (rows.length == 1 ? "y" : "ies") + "?\n\n"
            + "They will be moved to the Archive Vault and can be restored.",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

    if (confirm != JOptionPane.YES_OPTION) return;

    List<Integer> ids = new ArrayList<>();
    for (int r : rows) {
        ids.add(logIds.get(r));
    }

    try {
        runOnLogIds("UPDATE security_logs SET is_archived = 1, archived_at = NOW() "
                  + "WHERE log_id IN ", ids);
        loadSecurityLogs();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Error archiving logs:\n" + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}


/** Runs "<sqlPrefix> (?,?,?)" with the given ids. */
private void runOnLogIds(String sqlPrefix, List<Integer> ids) throws SQLException {

    StringBuilder marks = new StringBuilder("(");
    for (int i = 0; i < ids.size(); i++) {
        marks.append(i == 0 ? "?" : ",?");
    }
    marks.append(")");

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps = conn.prepareStatement(sqlPrefix + marks)) {

        for (int i = 0; i < ids.size(); i++) {
            ps.setInt(i + 1, ids.get(i));
        }
        ps.executeUpdate();
    }
}

private void styleSecurityLogsTable() {

    jTable1.setFont(
        new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12)
    );

    jTable1.setRowHeight(30);
    jTable1.setShowGrid(true);
    jTable1.setShowHorizontalLines(true);
    jTable1.setShowVerticalLines(true);
    jTable1.setGridColor(new java.awt.Color(225, 228, 233));
    jTable1.setIntercellSpacing(new java.awt.Dimension(1, 1));
    jTable1.setFillsViewportHeight(true);
    jTable1.setBackground(Color.WHITE);
    jTable1.setFillsViewportHeight(true);
    jScrollPane1.getViewport().setBackground(Color.WHITE);
    jScrollPane1.setOpaque(true);
    jScrollPane1.getViewport().setOpaque(true);
    jTable1.setBackground(java.awt.Color.WHITE);
    jTable1.setForeground(new java.awt.Color(40, 40, 40));
    jTable1.setSelectionBackground(new java.awt.Color(220, 230, 245));
    jTable1.setSelectionForeground(new java.awt.Color(27, 40, 56));

    // Header
    javax.swing.table.JTableHeader header =
        jTable1.getTableHeader();

    header.setFont(
        new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12)
    );
    header.setBackground(new java.awt.Color(235, 238, 242));
    header.setForeground(new java.awt.Color(35, 35, 35));
    header.setPreferredSize(new java.awt.Dimension(0, 34));
    header.setReorderingAllowed(false);

    // Alternating rows
    javax.swing.table.DefaultTableCellRenderer renderer =
        new javax.swing.table.DefaultTableCellRenderer() {

    @Override
    public java.awt.Component getTableCellRendererComponent(
            javax.swing.JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column) {

        java.awt.Component component =
            super.getTableCellRendererComponent(
                table, value, isSelected, hasFocus, row, column
            );

        if (isSelected) {
            component.setBackground(new java.awt.Color(220, 230, 245));
            component.setForeground(new java.awt.Color(27, 40, 56));
        } else {
            component.setBackground(
                row % 2 == 0
                    ? java.awt.Color.WHITE
                    : new java.awt.Color(247, 248, 250)
            );
            component.setForeground(new java.awt.Color(40, 40, 40));
        }

        setBorder(
            javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 7)
        );

        return component;
    }
    };

    for (int i = 0; i < jTable1.getColumnCount(); i++) {
        jTable1.getColumnModel()
            .getColumn(i)
            .setCellRenderer(renderer);
    }
}


private void openLogVault() {

    JDialog dialog = new JDialog(
            SwingUtilities.getWindowAncestor(this),
            "Security Logs Archive Vault",
            Dialog.ModalityType.APPLICATION_MODAL);

    DefaultTableModel vaultModel = new DefaultTableModel(
            new String[]{"Username", "Role", "Action", "Details", "Date & Time", "Archived At"}, 0) {
        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    };

    List<Integer> vaultIds = new ArrayList<>();

    JTable vaultTable = new JTable(vaultModel);
    vaultTable.setRowHeight(28);
    loadLogVault(vaultModel, vaultIds);

    JButton btnRestore = new JButton("Restore");
    JButton btnDelete = new JButton("Delete Permanently");
    JButton btnClose = new JButton("Close");

    btnRestore.addActionListener(e -> {
        int[] rows = vaultTable.getSelectedRows();
        if (rows.length == 0) {
            JOptionPane.showMessageDialog(dialog, "Select one or more entries first.");
            return;
        }
        List<Integer> ids = new ArrayList<>();
        for (int r : rows) ids.add(vaultIds.get(r));

        try {
            runOnLogIds("UPDATE security_logs SET is_archived = 0, archived_at = NULL "
                      + "WHERE log_id IN ", ids);
            loadLogVault(vaultModel, vaultIds);
            loadSecurityLogs();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog,
                    "Error restoring:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnDelete.addActionListener(e -> {
        int[] rows = vaultTable.getSelectedRows();
        if (rows.length == 0) {
            JOptionPane.showMessageDialog(dialog, "Select one or more entries first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(dialog,
                "PERMANENTLY delete " + rows.length + " log entr"
                + (rows.length == 1 ? "y" : "ies") + "?\n"
                + "Audit records cannot be recovered after this.",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.ERROR_MESSAGE);

        if (confirm != JOptionPane.YES_OPTION) return;

        List<Integer> ids = new ArrayList<>();
        for (int r : rows) ids.add(vaultIds.get(r));

        try {
            runOnLogIds("DELETE FROM security_logs WHERE is_archived = 1 "
                      + "AND log_id IN ", ids);
            loadLogVault(vaultModel, vaultIds);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dialog,
                    "Error deleting:\n" + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    btnClose.addActionListener(e -> dialog.dispose());

    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
    buttons.add(btnRestore);
    buttons.add(btnDelete);
    buttons.add(btnClose);

    dialog.setLayout(new BorderLayout());
    dialog.add(new JScrollPane(vaultTable), BorderLayout.CENTER);
    dialog.add(buttons, BorderLayout.SOUTH);
    dialog.setPreferredSize(new Dimension(1000, 450));
    dialog.pack();
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);
}


private void loadLogVault(DefaultTableModel vaultModel, List<Integer> vaultIds) {

    vaultModel.setRowCount(0);
    vaultIds.clear();

    String sql = "SELECT log_id, username, role, action, details, log_date, archived_at "
               + "FROM security_logs WHERE is_archived = 1 "
               + "ORDER BY archived_at DESC";

    java.text.SimpleDateFormat fmt =
            new java.text.SimpleDateFormat("MMM dd, yyyy hh:mm:ss a");

    try (Connection conn = ConnectDb.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            Timestamp logDate = rs.getTimestamp("log_date");
            Timestamp arch = rs.getTimestamp("archived_at");

            vaultIds.add(rs.getInt("log_id"));
            vaultModel.addRow(new Object[]{
                rs.getString("username"),
                rs.getString("role"),
                rs.getString("action"),
                rs.getString("details"),
                logDate == null ? "" : fmt.format(logDate),
                arch == null ? "" : fmt.format(arch)
            });
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Error loading vault:\n" + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnRefresh1;
    private javax.swing.JButton btnRefresh2;
    private javax.swing.JComboBox<String> cbActionFilter;
    private javax.swing.JComboBox<String> cbRoleFilter;
    private com.toedter.calendar.JDateChooser dateFrom;
    private com.toedter.calendar.JDateChooser dateTo;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel pnlHeader3;
    private javax.swing.JLabel pnlHeader4;
    private javax.swing.JLabel pnlHeader5;
    private javax.swing.JLabel pnlHeader6;
    private javax.swing.JLabel pnlHeader7;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
